import React, { useEffect } from 'react';
import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';

/**
 * Individual Toast item with self-timed auto-dismiss after 4 seconds.
 */
function ToastItem({ toast, onDismiss }) {
  useEffect(() => {
    if (!onDismiss) return;

    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 4000);

    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const renderIcon = () => {
    const type = (toast.type || '').toLowerCase();
    switch (type) {
      case 'success':
        return <CheckCircle size={18} aria-hidden="true" />;
      case 'error':
        return <XCircle size={18} aria-hidden="true" />;
      case 'warning':
        return <AlertTriangle size={18} aria-hidden="true" />;
      case 'info':
      default:
        return <Info size={18} aria-hidden="true" />;
    }
  };

  const typeClass = toast.type ? `toast-${toast.type.toLowerCase()}` : 'toast-info';

  return (
    <div className={`toast ${typeClass}`} role="status">
      {renderIcon()}
      <div style={{ flex: 1, lineHeight: 1.4 }}>{toast.message}</div>
      {onDismiss && (
        <button
          type="button"
          onClick={() => onDismiss(toast.id)}
          style={{
            background: 'none',
            border: 'none',
            color: 'inherit',
            cursor: 'pointer',
            padding: '2px',
            opacity: 0.8,
            display: 'flex',
            alignItems: 'center',
          }}
          aria-label="Dismiss notification"
        >
          <X size={15} />
        </button>
      )}
    </div>
  );
}

/**
 * Toast container rendering a list of transient alert notifications.
 *
 * @param {{
 *   toasts: Array<{ id: string | number, message: string, type?: 'success' | 'error' | 'warning' | 'info' }>,
 *   onDismiss: (id: string | number) => void
 * }} props
 */
export default function Toast({ toasts = [], onDismiss }) {
  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="toast-container" aria-live="polite">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}
