import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { CITIZEN, INITIAL_NOTIFICATIONS, COUNTERS, RECENT_APPLICATIONS } from '../data/mockData';
import { loadState, saveState, clearAllState } from '../utils/helpers';
import { TRANSLATIONS, MOCK_USERS } from './authConstants';
import { playCounterChime, speakAnnouncement } from '../utils/audioAnnouncer';
import { api, setAuthToken, getAuthToken } from '../utils/api';

export { TRANSLATIONS, MOCK_USERS };

const AppContext = createContext(null);

const DEFAULT_STATE = {
  theme: 'light',
  language: 'en',
  user: null,
  citizen: CITIZEN,

  toasts: [],
  audioEnabled: true,

  smsInbox: [
    {
      id: 1,
      sender: 'GOV-SQMS',
      time: '09:15 AM',
      type: 'booking',
      text: 'Govt of Maharashtra: Token A-042 generated for Income Certificate. Counter 3, Tehsildar Complex Pune.',
    },
    {
      id: 2,
      sender: 'GOV-SQMS',
      time: '09:20 AM',
      type: 'checkin',
      text: 'Physical QR check-in recorded at Entry Kiosk. You are queued at Counter 3.',
    },
  ],

  booking: null,
  token: {
    tokenId: 'TK-2026-0042',
    tokenNumber: 'A-042',
    service: 'Income Certificate',
    serviceId: 'income',
    date: '2026-09-25',
    time: '10:30 AM - 11:00 AM',
    counter: 3,
    counterName: 'Counter 3',
    qrString: 'SQMS|A-042|Rahul Patil|Income Certificate|2026-09-25|VERIFIED',
    createdTime: '09:15 AM',
    reminders: {
      reminder30Min: false,
      reminder30MinTime: null,
      reminder15Min: false,
      reminder15MinTime: null,
    },
    lastReminder: null,
  },
  tokenReminders: {
    'A-042': {
      reminder30Min: false,
      reminder30MinTime: null,
      reminder15Min: false,
      reminder15MinTime: null,
    },
    'A-043': {
      reminder30Min: false,
      reminder30MinTime: null,
      reminder15Min: false,
      reminder15MinTime: null,
    },
    'A-044': {
      reminder30Min: false,
      reminder30MinTime: null,
      reminder15Min: false,
      reminder15MinTime: null,
    },
  },
  checkedIn: true,
  applicationStatus: 'under_verification',
  documents: [
    {
      id: 'RES-MH-2025-0812',
      type: 'Residence Certificate',
      name: 'Rahul Patil',
      address: 'Pune, Maharashtra',
      issueDate: '12 October 2025',
      officer: 'Amit Joshi',
      status: 'Valid',
    },
  ],
  grievance: null,
  urgentRequest: null,
  notifications: INITIAL_NOTIFICATIONS,
  docVerification: {
    aadhaar: 'verified',
    addressProof: 'verified',
    incomeProof: 'pending',
    photo: 'verified',
  },
  counters: COUNTERS,
  currentServing: 'A-035',
  queuePosition: 7,
  estimatedWait: 18,
  applicationsList: RECENT_APPLICATIONS,
};

export function AppProvider({ children }) {
  const [state, setState] = useState(() => {
    const saved = loadState('sqms_state', null);
    if (saved && saved.user) {
      return { ...DEFAULT_STATE, ...saved, toasts: [] };
    }
    return { ...DEFAULT_STATE, user: null, toasts: [] };
  });

  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // Persist state to local storage
  useEffect(() => {
    if (state.user) {
      saveState('sqms_state', {
        theme: state.theme,
        language: state.language,
        user: state.user,
        booking: state.booking,
        token: state.token,
        checkedIn: state.checkedIn,
        applicationStatus: state.applicationStatus,
      });
    }
  }, [state.theme, state.language, state.user, state.booking, state.token, state.checkedIn, state.applicationStatus]);

  // Apply data-theme attribute on document root
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', state.theme || 'light');
  }, [state.theme]);

  const addToast = useCallback((message, type = 'info') => {
    const newToast = { id: Date.now() + Math.random(), message, type };
    setState((prev) => ({
      ...prev,
      toasts: [...(prev.toasts || []), newToast],
    }));
  }, []);

  const removeToast = useCallback((id) => {
    setState((prev) => ({
      ...prev,
      toasts: (prev.toasts || []).filter((t) => t.id !== id),
    }));
  }, []);

  const updateState = useCallback((updates) => {
    setState((prev) => ({ ...prev, ...updates }));
  }, []);

  // Sync session with backend on mount
  useEffect(() => {
    const token = getAuthToken();
    if (token) {
      api.getMe()
        .then((res) => {
          if (res.user) {
            setState((prev) => ({ ...prev, user: res.user }));
            // Also fetch notifications
            api.getNotifications()
              .then((nRes) => {
                if (nRes?.notifications) {
                  setState((prev) => ({
                    ...prev,
                    notifications: nRes.notifications.map((n) => ({
                      id: n.id,
                      message: n.message,
                      time: n.time,
                      read: Boolean(n.read),
                      type: n.type,
                    })),
                    smsInbox: nRes.smsInbox || prev.smsInbox,
                  }));
                }
              })
              .catch(() => {});
          }
        })
        .catch(() => {
          // Token expired or invalid
          setAuthToken(null);
        });
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setState((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  }, []);

  const toggleAudio = useCallback(() => {
    setState((prev) => ({
      ...prev,
      audioEnabled: !prev.audioEnabled,
    }));
  }, []);

  const setLanguage = useCallback((lang) => {
    setState((prev) => ({
      ...prev,
      language: lang,
    }));
  }, []);

  const t = useCallback((key) => {
    const langDict = TRANSLATIONS[state.language] || TRANSLATIONS.en;
    return langDict[key] || TRANSLATIONS.en[key] || key;
  }, [state.language]);

  // Real Backend Authentication with local fallback
  const login = useCallback(async (role = 'citizen', customDetails = null) => {
    let identifier = '9876543210';
    let password = 'demo123';

    if (customDetails?.identifier && customDetails?.password) {
      identifier = customDetails.identifier;
      password = customDetails.password;
    } else if (role === 'officer') {
      identifier = 'priya.sharma@gov.in';
      password = 'officer@123';
    } else if (role === 'admin') {
      identifier = 'admin.sqms@gov.in';
      password = 'admin@123';
    }

    try {
      const res = await api.login(identifier, password, role);
      if (res?.user) {
        setState((prev) => ({
          ...prev,
          user: res.user,
        }));
        addToast(`Authenticated as ${res.user.name} (${res.user.role.toUpperCase()})`, 'success');

        // Fetch live bookings if citizen
        if (res.user.role === 'citizen') {
          api.getMyBookings()
            .then((bookings) => {
              if (bookings && bookings.length > 0) {
                const latest = bookings[0];
                setState((prev) => ({
                  ...prev,
                  booking: {
                    serviceId: latest.service_id,
                    serviceName: latest.service_name,
                    date: latest.slot_date,
                    timeSlot: latest.slot_time,
                    office: latest.office_id,
                  },
                  token: {
                    tokenId: latest.token_id || latest.id,
                    tokenNumber: latest.token_number || 'A-042',
                    service: latest.service_name,
                    serviceId: latest.service_id,
                    date: latest.slot_date,
                    time: latest.slot_time,
                    counter: latest.counter_id,
                    counterName: latest.counter_name || `Counter ${latest.counter_id}`,
                    qrString: latest.qr_payload || '',
                    createdTime: '09:15 AM',
                    reminders: {
                      reminder30Min: false,
                      reminder30MinTime: null,
                      reminder15Min: false,
                      reminder15MinTime: null,
                    },
                    lastReminder: null,
                  },
                  checkedIn: Boolean(latest.stage1_verified_at),
                  applicationStatus: latest.application_status || 'submitted',
                }));
              }
            })
            .catch(() => {});
        }
        return res.user;
      }
    } catch {
      // Fallback to local mock if API server is booting
      const fallbackUser = customDetails || MOCK_USERS[role] || MOCK_USERS.citizen;
      setState((prev) => ({
        ...prev,
        user: { ...fallbackUser, role },
      }));
      addToast(`Logged in as ${fallbackUser.name} (${role.toUpperCase()})`, 'success');
      return fallbackUser;
    }
  }, [addToast]);

  const loginWithGoogle = useCallback((role = 'citizen') => {
    const googleUser = {
      role,
      id: `GOOG-${Math.floor(10000 + Math.random() * 90000)}`,
      name: role === 'citizen' ? 'Rahul Patil (Google Verified)' : role === 'officer' ? 'Priya Sharma (Gov Google Auth)' : 'Admin User (Google Auth)',
      email: role === 'citizen' ? 'rahul.patil.google@gmail.com' : role === 'officer' ? 'priya.sharma@gov.in' : 'admin@gov.in',
      avatar: 'https://lh3.googleusercontent.com/a/default-user',
      authProvider: 'google',
    };
    setState((prev) => ({
      ...prev,
      user: googleUser,
    }));
    addToast(`Signed in successfully as ${googleUser.name}`, 'success');
  }, [addToast]);

  const logout = useCallback(() => {
    api.logout();
    clearAllState();
    setState((prev) => ({
      ...prev,
      user: null,
    }));
    addToast('Logged out successfully', 'info');
  }, [addToast]);

  const switchRole = useCallback(async (newRole) => {
    await login(newRole);
  }, [login]);

  const setBooking = useCallback((booking) => {
    updateState({ booking });
    addToast(`Service slot confirmed for ${booking.serviceName}`, 'success');
  }, [updateState, addToast]);

  const setToken = useCallback((token) => {
    updateState({
      token: {
        ...token,
        reminders: {
          reminder30Min: false,
          reminder30MinTime: null,
          reminder15Min: false,
          reminder15MinTime: null,
        },
        lastReminder: null,
      },
      applicationStatus: 'submitted',
      checkedIn: false,
      queuePosition: 7,
      currentServing: 'A-035',
      estimatedWait: 18,
    });
    addToast(`Digital Token ${token.tokenNumber} allocated! Assigned to Counter 3.`, 'success');
  }, [updateState, addToast]);

  const setCheckedIn = useCallback((val) => {
    updateState({ checkedIn: val });
    if (val) {
      const curToken = stateRef.current.token;
      if (curToken?.tokenNumber) {
        api.verifyStage1Arrival(curToken.qrString, curToken.tokenNumber)
          .catch(() => {});
      }
      addToast('Office QR Check-in verified! Assigned to Counter 3 waiting queue.', 'success');
    }
  }, [updateState, addToast]);

  // Turn Reminders action with real backend call
  const sendOfficerReminder = useCallback(async (tokenNum = 'A-042', minutes = 30) => {
    const is30 = Number(minutes) === 30;
    const nowStr = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    const reminderKey = is30 ? 'reminder30Min' : 'reminder15Min';
    const reminderTimeKey = is30 ? 'reminder30MinTime' : 'reminder15MinTime';

    try {
      await api.sendTurnReminder(tokenNum, minutes);
    } catch {
      // Continue locally if offline
    }

    const notificationMessage = is30
      ? `⏰ 30-Minute Turn Reminder: Token #${tokenNum} will be called in approximately 30 minutes! Please proceed to the service complex lounge.`
      : `🚨 15-Minute Final Call: Token #${tokenNum} is next in line at Counter 3! Please be present at the counter with original documents.`;

    const smsText = is30
      ? `Govt SQMS Alert: Token ${tokenNum} for Income Certificate will arrive in ~30 mins at Counter 3, Tehsildar Complex. Please head to waiting lounge.`
      : `URGENT GOVT SQMS: Token ${tokenNum} is next in line! Reach Counter 3 within 15 minutes with original Aadhaar & documents.`;

    const newNotification = {
      id: Date.now(),
      tokenNumber: tokenNum,
      reminderType: is30 ? '30min' : '15min',
      message: notificationMessage,
      time: 'Just now',
      timestamp: nowStr,
      read: false,
      type: is30 ? 'warning' : 'danger',
    };

    const newSms = {
      id: Date.now() + 1,
      sender: 'GOV-SQMS',
      time: nowStr,
      type: is30 ? 'reminder30' : 'reminder15',
      text: smsText,
    };

    if (stateRef.current.audioEnabled) {
      const voiceText = is30
        ? `Attention Token ${tokenNum}, your thirty minute reminder for Counter 3 has been issued.`
        : `Urgent call for Token ${tokenNum}, please report to Counter number 3 within fifteen minutes.`;
      speakAnnouncement(voiceText, stateRef.current.language);
    } else {
      playCounterChime();
    }

    setState((prev) => {
      const isCurrent = prev.token && prev.token.tokenNumber === tokenNum;
      const updatedToken = isCurrent
        ? {
            ...prev.token,
            reminders: {
              ...(prev.token.reminders || {}),
              [reminderKey]: true,
              [reminderTimeKey]: nowStr,
            },
            lastReminder: {
              type: is30 ? '30min' : '15min',
              minutes: is30 ? 30 : 15,
              time: nowStr,
              message: notificationMessage,
            },
          }
        : prev.token;

      const updatedRemindersMap = {
        ...(prev.tokenReminders || {}),
        [tokenNum]: {
          ...(prev.tokenReminders?.[tokenNum] || {}),
          [reminderKey]: true,
          [reminderTimeKey]: nowStr,
        },
      };

      return {
        ...prev,
        token: updatedToken,
        tokenReminders: updatedRemindersMap,
        notifications: [newNotification, ...(prev.notifications || [])],
        smsInbox: [newSms, ...(prev.smsInbox || [])],
        toasts: [
          ...(prev.toasts || []),
          {
            id: Date.now(),
            message: `${is30 ? '⏰ 30-Min' : '🚨 15-Min'} Reminder sent to Token ${tokenNum} via SMS & App Alert`,
            type: is30 ? 'warning' : 'error',
          },
        ],
      };
    });

    return {
      success: true,
      tokenNumber: tokenNum,
      minutes,
      time: nowStr,
      message: notificationMessage,
      sms: smsText,
    };
  }, []);

  const voiceCallToken = useCallback((tokenNum = 'A-042', counterName = 'Counter 3') => {
    const text = `Token number ${tokenNum}, please report to ${counterName}`;
    speakAnnouncement(text, stateRef.current.language);
    addToast(`📢 Audio Announcement triggered for Token ${tokenNum} at ${counterName}`, 'info');
  }, [addToast]);

  // Officer Next Token Call Action connected to backend
  const callNextCitizen = useCallback(async () => {
    let nextServingToken = null;
    try {
      const res = await api.callNext(3);
      if (res?.currentToken) {
        nextServingToken = res.currentToken;
      }
    } catch {
      // Fallback
    }

    setState((prev) => {
      let nextServing = nextServingToken;
      if (!nextServing) {
        const currentNum = parseInt((prev.currentServing || 'A-035').replace(/[^0-9]/g, ''), 10) || 35;
        nextServing = `A-${String(currentNum + 1).padStart(3, '0')}`;
      }

      const newPos = Math.max(0, prev.queuePosition - 1);

      if (prev.audioEnabled) {
        speakAnnouncement(`Now serving, Token number ${nextServing}, at Counter 3`, prev.language);
      }

      return {
        ...prev,
        currentServing: nextServing,
        queuePosition: newPos,
        estimatedWait: newPos * 3,
        toasts: [
          ...(prev.toasts || []),
          {
            id: Date.now(),
            message: `Counter 3 is now serving Token ${nextServing}! Queue advanced.`,
            type: 'info',
          },
        ],
      };
    });
  }, []);

  // Advance application lifecycle state
  const advanceApplication = useCallback(() => {
    setState((prev) => {
      const order = ['none', 'submitted', 'under_verification', 'correction_required', 'resubmitted', 'approved', 'completed'];
      const idx = order.indexOf(prev.applicationStatus);
      const next = idx < order.length - 1 ? order[idx + 1] : prev.applicationStatus;
      let updates = { applicationStatus: next };

      if (next === 'completed' && prev.token) {
        const cert = {
          id: `INC-MH-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          type: prev.token.service || 'Income Certificate',
          name: prev.citizen.name,
          address: prev.citizen.address,
          income: '₹2,50,000',
          issueDate: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }),
          officer: 'Ms. Priya Sharma',
          status: 'Valid',
        };
        updates.documents = [...(prev.documents || []), cert];
        updates.notifications = [
          {
            id: Date.now(),
            message: `🎉 Service Complete! Your ${cert.type} has been issued and added to My Documents.`,
            time: 'Just now',
            read: false,
            type: 'success',
          },
          ...(prev.notifications || []),
        ];
        updates.toasts = [
          ...(prev.toasts || []),
          {
            id: Date.now(),
            message: `🎉 ${cert.type} officially issued! Added to My Documents.`,
            type: 'success',
          },
        ];
      } else {
        updates.toasts = [
          ...(prev.toasts || []),
          {
            id: Date.now(),
            message: `Application status moved to: ${next.toUpperCase()}`,
            type: 'info',
          },
        ];
      }
      return { ...prev, ...updates };
    });
  }, []);

  const setDocVerification = useCallback((doc, status) => {
    setState((prev) => ({
      ...prev,
      docVerification: { ...prev.docVerification, [doc]: status },
      toasts: [
        ...(prev.toasts || []),
        {
          id: Date.now(),
          message: `Document [${doc}] marked as: ${status.toUpperCase()}`,
          type: status === 'verified' ? 'success' : 'error',
        },
      ],
    }));
  }, []);

  const submitGrievance = useCallback((grievance) => {
    api.submitGrievance(grievance).catch(() => {});
    updateState({
      grievance: { ...grievance, status: 'submitted', date: '25 Sep 2026' },
      notifications: [
        {
          id: Date.now(),
          message: 'Grievance ticket submitted successfully. Under review by Tehsildar Office.',
          time: 'Just now',
          read: false,
          type: 'warning',
        },
        ...(state.notifications || []),
      ],
    });
    addToast('Grievance ticket registered! Tracking ID generated.', 'warning');
  }, [updateState, state.notifications, addToast]);

  const submitUrgentRequest = useCallback((request) => {
    api.submitUrgentRequest(request).catch(() => {});
    updateState({
      urgentRequest: { ...request, status: 'pending', date: '25 Sep 2026' },
      notifications: [
        {
          id: Date.now(),
          message: 'Urgent priority request submitted for admin/officer approval.',
          time: 'Just now',
          read: false,
          type: 'info',
        },
        ...(state.notifications || []),
      ],
    });
    addToast('Urgent priority request forwarded to Officer Priya Sharma for express queue upgrade.', 'info');
  }, [updateState, state.notifications, addToast]);

  const handleOfficerGrievanceAction = useCallback((status = 'resolved') => {
    setState((prev) => ({
      ...prev,
      grievance: prev.grievance ? { ...prev.grievance, status } : null,
      notifications: [
        {
          id: Date.now(),
          message: `Your grievance ticket has been marked as ${status.toUpperCase()} by Officer Priya Sharma.`,
          time: 'Just now',
          read: false,
          type: 'success',
        },
        ...(prev.notifications || []),
      ],
      toasts: [
        ...(prev.toasts || []),
        {
          id: Date.now(),
          message: `Grievance ticket marked as ${status.toUpperCase()}`,
          type: status === 'resolved' ? 'success' : 'error',
        },
      ],
    }));
  }, []);

  const handleOfficerUrgentAction = useCallback((status = 'approved') => {
    setState((prev) => ({
      ...prev,
      urgentRequest: prev.urgentRequest ? { ...prev.urgentRequest, status } : null,
      notifications: [
        {
          id: Date.now(),
          message: `Your Urgent Request has been ${status.toUpperCase()}! Your queue priority has been upgraded.`,
          time: 'Just now',
          read: false,
          type: 'success',
        },
        ...(prev.notifications || []),
      ],
      toasts: [
        ...(prev.toasts || []),
        {
          id: Date.now(),
          message: `Express priority request ${status.toUpperCase()}!`,
          type: status === 'approved' ? 'success' : 'error',
        },
      ],
    }));
  }, []);

  const markNotificationRead = useCallback((id) => {
    api.markNotificationRead(id).catch(() => {});
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      ),
    }));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    api.markAllNotificationsRead().catch(() => {});
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => ({ ...n, read: true })),
    }));
  }, []);

  const resetDemo = useCallback(() => {
    clearAllState();
    api.logout();
    setState({ ...DEFAULT_STATE, user: null });
    addToast('Environment reset to initial state', 'info');
  }, [addToast]);

  const value = {
    ...state,
    login,
    logout,
    switchRole,
    toggleTheme,
    toggleAudio,
    setLanguage,
    t,
    loginWithGoogle,
    updateState,
    addToast,
    removeToast,
    setBooking,
    setToken,
    setCheckedIn,
    sendOfficerReminder,
    voiceCallToken,
    callNextCitizen,
    advanceApplication,
    setDocVerification,
    submitGrievance,
    submitUrgentRequest,
    handleOfficerGrievanceAction,
    handleOfficerUrgentAction,
    markNotificationRead,
    markAllNotificationsRead,
    resetDemo,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}
