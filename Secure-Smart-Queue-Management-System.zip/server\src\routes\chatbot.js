// Secure Smart Queue Management System — Bilingual FAQ & Service Assistant (English & Marathi)
import { Router } from 'express';
import { getDb } from '../db.js';
import { optionalAuth } from '../middleware/auth.js';

const router = Router();

const BILINGUAL_KNOWLEDGE = [
  {
    keywords: ['hello', 'hi', 'hey', 'namaste', 'namaskar', 'नमस्कार', 'हॅलो', 'नमस्ते'],
    en: 'Namaste! I am your SQMS Public Service Assistant. You can ask me about government certificate requirements, appointment booking, token status, office hours, or document checklists in English or Marathi.',
    mr: 'नमस्कार! मी आपला SQMS सहाय्यक आहे. आपण मला शासकीय दाखले, अपॉइंटमेंट बुकिंग, टोकन स्थिती, कार्यालयीन वेळा किंवा आवश्यक कागदपत्रांबद्दल मराठी किंवा इंग्रजीत विचारू शकता.',
  },
  {
    keywords: ['income', 'उत्पन्न', 'दाखला', 'salary', 'form 16', 'वार्षिक उत्पन्न'],
    en: 'Income Certificate is issued by the Tehsildar Office (Counter 3). Requirements: Aadhaar card, residence proof, salary slip/Form 16 or self-affidavit, and passport photo. Official fee is ₹25. Processing time: 3-5 working days.',
    mr: 'उत्पन्नाचा दाखला तहसील कार्यालयातून (काउंटर ३) दिला जातो. आवश्यक कागदपत्रे: आधार कार्ड, रहिवासी पुरावा, पगार पावती/फॉर्म १६ किंवा स्वयंघोषणापत्र आणि पासपोर्ट फोटो. अधिकृत शुल्क ₹२५ आहे. कालावधी: ३-५ कामाचे दिवस.',
  },
  {
    keywords: ['caste', 'जात', 'प्रमाणपत्र', 'जातीचा दाखला'],
    en: 'Caste Certificate is handled at Counter 4. Required documents: Aadhaar card, School Leaving Certificate, father\'s or paternal relative\'s caste certificate, and ration card. Official fee: ₹25.',
    mr: 'जातीचा दाखला काउंटर ४ वर हाताळला जातो. आवश्यक कागदपत्रे: आधार कार्ड, शाळा सोडल्याचा दाखला, वडिलांचा किंवा रक्ताच्या नातेवाईकांचा जातीचा दाखला आणि शिधापत्रिका. अधिकृत शुल्क ₹२५ आहे.',
  },
  {
    keywords: ['domicile', 'residence', 'रहिवासी', 'अधिवास', 'डोमिसाईल', '१५ वर्षे'],
    en: 'Domicile Certificate (Counter 4) requires 15 years continuous residence proof in Maharashtra, school leaving certificate, and birth record. Residence Certificate (Counter 2) requires current utility bill and ration card. Fee: ₹25 - ₹50.',
    mr: 'अधिवास (डोमिसाईल) दाखल्यासाठी (काउंटर ४) महाराष्ट्रात १५ वर्षे वास्तव्याचा पुरावा आणि शाळा सोडल्याचा दाखला आवश्यक आहे. स्थानिक रहिवासी दाखल्यासाठी (काउंटर २) चालू वीज बिल आणि शिधापत्रिका लागते.',
  },
  {
    keywords: ['book', 'booking', 'slot', 'appointment', 'बुकिंग', 'वेळ', 'अपॉइंटमेंट कशी करावी'],
    en: 'To book: Log in as a Citizen, click "Services", select your required certificate, choose a weekday (Monday to Friday) and an available time slot, then click "Confirm Appointment". A signed digital token will be generated immediately.',
    mr: 'बुकिंग करण्यासाठी: नागरिक म्हणून लॉग इन करा, "Services" वर जा, दाखला निवडा, सोमवार ते शुक्रवारमधील उपलब्ध तारीख व वेळ निवडा आणि पुष्टी करा. आपल्याला तात्काळ डिजिटल टोकन मिळेल.',
  },
  {
    keywords: ['token', 'queue', 'wait', 'position', 'टोकन', 'रांग', 'नंबर'],
    en: 'Your digital token includes your queue number, assigned counter, and live queue status. Officers trigger 30-minute and 15-minute alerts before your turn. You can also view the live Public Display Board on the Queue page.',
    mr: 'आपल्या डिजिटल टोकनमध्ये रांगेतील क्रमांक, नेमलेला काउंटर आणि प्रतीक्षा स्थिती दिसते. आपली पाळी येण्यापूर्वी ३० मिनिटे व १५ मिनिटे आधी सूचना पाठवली जाते.',
  },
  {
    keywords: ['timing', 'hours', 'office', 'closed', 'holiday', 'शनिवार', 'रविवार', 'सुट्टी', 'वेळ'],
    en: 'Tehsildar Office operates Monday to Friday from 09:00 AM to 05:30 PM. The office is closed on Saturdays, Sundays, and official government gazetted holidays.',
    mr: 'तहसील कार्यालय सोमवार ते शुक्रवार सकाळी ०९:०० ते संध्याकाळी ०५:३० या वेळेत सुरू असते. शनिवार, रविवार आणि शासकीय सुट्ट्यांच्या दिवशी कार्यालय बंद असते.',
  },
  {
    keywords: ['correction', 'grievance', 'तक्रार', 'दुरुस्ती', 'चूक'],
    en: 'If an officer requests document corrections or if there is an error in your certificate, visit the "Grievance" or "Application Status" page to submit corrected files and notes.',
    mr: 'दाखल्यातील माहिती दुरुस्तीसाठी किंवा त्रुटी पूर्ततेसाठी "Grievance" किंवा "Application Status" विभागात जाऊन आवश्यक कागदपत्रे पुन्हा अपलोड करू शकता.',
  },
];

function isMarathi(text) {
  // Check for Devanagari Unicode range (\u0900-\u097F)
  return /[\u0900-\u097F]/.test(text);
}

function matchAnswer(text, preferredLang = null) {
  const t = text.toLowerCase();
  const detectLang = preferredLang || (isMarathi(text) ? 'mr' : 'en');

  for (const item of BILINGUAL_KNOWLEDGE) {
    if (item.keywords.some((kw) => t.includes(kw.toLowerCase()))) {
      return {
        reply: detectLang === 'mr' ? item.mr : item.en,
        language: detectLang,
        matched: true,
      };
    }
  }

  return {
    reply: detectLang === 'mr'
      ? 'माफ करा, या प्रश्नाचे अधिकृत उत्तर माझ्याकडे उपलब्ध नाही. कृपया अधिक माहितीसाठी मुख्य कार्यालयातील मदत केंद्राशी (+९१ २० २६१२ ३४५६) संपर्क साधा.'
      : 'I apologize, I do not have a verified answer for that query. For official government queries, please contact the Pune Tehsildar Help Desk (+91 20 2612 3456) or visit Counter 5.',
    language: detectLang,
    matched: false,
  };
}

function handleChat(req, res) {
  const { message, language } = req.body || {};
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'message string is required' });
  }

  const result = matchAnswer(message.trim(), language);

  // If user is authenticated and asks about "my token" or "my queue", fetch live DB state!
  if (req.user && (message.toLowerCase().includes('my token') || message.includes('माझे टोकन') || message.includes('माझी स्थिती'))) {
    const db = getDb();
    const token = db.prepare(`
      SELECT t.token_number, t.queue_status, c.name AS counter_name, s.name AS service_name
      FROM tokens t
      JOIN counters c ON c.id = t.counter_id
      JOIN services s ON s.id = t.service_id
      WHERE t.citizen_id = ? AND t.queue_status IN ('waiting', 'arrived', 'serving', 'scheduled')
      ORDER BY t.created_at DESC LIMIT 1
    `).get(req.user.id);

    if (token) {
      const liveText = result.language === 'mr'
        ? `आपले सक्रिय टोकन: ${token.token_number} (${token.service_name}), स्थिती: ${token.queue_status.toUpperCase()}, नेमलेला काउंटर: ${token.counter_name}.`
        : `Your active token is ${token.token_number} for ${token.service_name} at ${token.counter_name}. Current status: ${token.queue_status.toUpperCase()}.`;
      return res.json({ reply: liveText, source: 'sqms-live-database', language: result.language });
    }
  }

  res.json({
    reply: result.reply,
    source: 'sqms-bilingual-knowledge-base',
    language: result.language,
  });
}

router.post('/', optionalAuth, handleChat);
router.post('/message', optionalAuth, handleChat);

export default router;