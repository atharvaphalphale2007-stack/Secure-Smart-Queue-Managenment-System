// Secure Smart Queue Management System — Frontend API Client
// Standardized REST client handling JWT headers, error handling, and JSON serialization.

const API_BASE = '/api';

function getAuthHeader() {
  const token = localStorage.getItem('sqms_jwt_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function setAuthToken(token) {
  if (token) {
    localStorage.setItem('sqms_jwt_token', token);
  } else {
    localStorage.removeItem('sqms_jwt_token');
  }
}

export function getAuthToken() {
  return localStorage.getItem('sqms_jwt_token');
}

async function request(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const contentType = response.headers.get('content-type') || '';
  let data;
  if (contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = await response.text();
  }

  if (!response.ok) {
    const errorMsg = data?.error || (typeof data === 'string' ? data : `HTTP ${response.status}`);
    const error = new Error(errorMsg);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

export const api = {
  // Auth
  async login(identifier, password, role) {
    const res = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password, role }),
    });
    if (res.token) setAuthToken(res.token);
    return res;
  },

  async register(userData) {
    const res = await request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    if (res.token) setAuthToken(res.token);
    return res;
  },

  async getMe() {
    return request('/auth/me');
  },

  async updateProfile(updates) {
    return request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  logout() {
    setAuthToken(null);
  },

  // Services
  async getServices() {
    return request('/services');
  },

  async getServiceById(id) {
    return request(`/services/${id}`);
  },

  // Booking & Slots
  async getSlots(date, serviceId) {
    const query = new URLSearchParams({ date });
    if (serviceId) query.append('serviceId', serviceId);
    return request(`/booking/slots?${query.toString()}`);
  },

  async createBooking(bookingData) {
    return request('/booking', {
      method: 'POST',
      body: JSON.stringify(bookingData),
    });
  },

  async getMyBookings() {
    return request('/booking/me');
  },

  async cancelBooking(bookingId, reason) {
    return request(`/booking/${bookingId}/cancel`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  async rescheduleBooking(bookingId, newDate, newSlotTime) {
    return request(`/booking/${bookingId}/reschedule`, {
      method: 'POST',
      body: JSON.stringify({ newDate, newSlotTime }),
    });
  },

  // Queue & Two-Stage QR Verification
  async getCounters() {
    return request('/queue/counters');
  },

  async getLiveQueue(counterId) {
    const query = counterId ? `?counterId=${counterId}` : '';
    return request(`/queue/live${query}`);
  },

  async getTokenDetails(tokenNumber) {
    return request(`/queue/token/${encodeURIComponent(tokenNumber)}`);
  },

  async verifyStage1Arrival(qrString, tokenNumber) {
    return request('/queue/verify-stage1', {
      method: 'POST',
      body: JSON.stringify({ qrString, tokenNumber }),
    });
  },

  async verifyStage2Counter(tokenNumber, counterId) {
    return request('/queue/verify-stage2', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber, counterId }),
    });
  },

  async callNext(counterId) {
    return request('/queue/call-next', {
      method: 'POST',
      body: JSON.stringify({ counterId }),
    });
  },

  async completeServing(tokenNumber, counterId) {
    return request('/queue/complete', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber, counterId }),
    });
  },

  async markAbsent(tokenNumber, reason) {
    return request('/queue/mark-absent', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber, reason }),
    });
  },

  async restoreAbsent(tokenNumber, reason) {
    return request('/queue/restore-absent', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber, reason }),
    });
  },

  async recoverToken(tokenNumber) {
    return request('/queue/recover-token', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber }),
    });
  },

  // Applications Lifecycle
  async getMyApplications() {
    return request('/applications/me');
  },

  async getApplicationById(id) {
    return request(`/applications/${id}`);
  },

  async updateApplicationStatus(id, status, reason, notes) {
    return request(`/applications/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason, notes }),
    });
  },

  async requestCorrection(id, docName, reason) {
    return request(`/applications/${id}/request-correction`, {
      method: 'POST',
      body: JSON.stringify({ docName, reason }),
    });
  },

  async resubmitApplication(id, notes) {
    return request(`/applications/${id}/resubmit`, {
      method: 'POST',
      body: JSON.stringify({ notes }),
    });
  },

  // Documents
  async getMyDocuments() {
    return request('/documents');
  },

  async uploadDocument(docData) {
    return request('/documents/upload', {
      method: 'POST',
      body: JSON.stringify(docData),
    });
  },

  async verifyDocument(docId, status, reason) {
    return request(`/documents/${docId}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason }),
    });
  },

  // Grievances
  async getGrievances() {
    return request('/grievance');
  },

  async submitGrievance(data) {
    return request('/grievance', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateGrievanceStatus(id, status, resolutionNotes) {
    return request(`/grievance/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, resolutionNotes }),
    });
  },

  // Urgent / Tatkal Requests
  async getUrgentRequests() {
    return request('/urgent');
  },

  async submitUrgentRequest(data) {
    return request('/urgent', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async reviewUrgentRequest(id, status, decisionNotes) {
    return request(`/urgent/${id}/review`, {
      method: 'PATCH',
      body: JSON.stringify({ status, decisionNotes }),
    });
  },

  // Notifications & Reminders
  async getNotifications() {
    return request('/notifications');
  },

  async markNotificationRead(id) {
    return request(`/notifications/${id}/read`, { method: 'PATCH' });
  },

  async markAllNotificationsRead() {
    return request('/notifications/mark-all-read', { method: 'POST' });
  },

  async sendTurnReminder(tokenNumber, minutes) {
    return request('/notifications/send-reminder', {
      method: 'POST',
      body: JSON.stringify({ tokenNumber, minutes }),
    });
  },

  // Chatbot
  async sendChatbotMessage(message, language) {
    return request('/chatbot/message', {
      method: 'POST',
      body: JSON.stringify({ message, language }),
    });
  },

  // Admin
  async getAdminStats() {
    return request('/admin/stats');
  },

  async getAuditLogs(params = {}) {
    const query = new URLSearchParams(params).toString();
    return request(`/admin/audit-logs${query ? `?${query}` : ''}`);
  },

  async verifyAuditTrail() {
    return request('/admin/audit-logs/verify');
  },

  async getSecurityAlerts() {
    return request('/admin/security-alerts');
  },

  async resolveSecurityAlert(id) {
    return request(`/admin/security-alerts/${id}/resolve`, { method: 'PATCH' });
  },

  async getAdminUsers(role) {
    const query = role ? `?role=${role}` : '';
    return request(`/admin/users${query}`);
  },

  async getConfigs() {
    return request('/admin/configs');
  },

  async updateConfig(key, value, description) {
    return request(`/admin/configs/${encodeURIComponent(key)}`, {
      method: 'PUT',
      body: JSON.stringify({ value, description }),
    });
  },

  async getHolidays() {
    return request('/admin/holidays');
  },

  async createHoliday(holidayData) {
    return request('/admin/holidays', {
      method: 'POST',
      body: JSON.stringify(holidayData),
    });
  },

  async deleteHoliday(id) {
    return request(`/admin/holidays/${id}`, { method: 'DELETE' });
  },
};

export default api;
