import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  ShieldCheck,
  Landmark,
  Lock,
  Phone,
  Mail,
  LogIn,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  Clock,
  Radio,
  Bell,
  CheckCircle,
  Eye,
  QrCode,
  Zap,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export default function Login() {
  const { login, loginWithGoogle, t } = useAppContext();
  const navigate = useNavigate();

  const [role, setRole] = useState('citizen'); // 'citizen' | 'officer' | 'admin'
  const [identifier, setIdentifier] = useState('9876543210');
  const [password, setPassword] = useState('demo123');
  const [loginError, setLoginError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Preview tab state
  const [previewTab, setPreviewTab] = useState('citizen'); // 'citizen' | 'officer' | 'reminders' | 'admin'

  const handleRoleChange = (newRole) => {
    setRole(newRole);
    setLoginError(null);
    if (newRole === 'citizen') {
      setIdentifier('9876543210');
      setPassword('demo123');
    } else if (newRole === 'officer') {
      setIdentifier('priya.sharma@gov.in');
      setPassword('officer@123');
    } else {
      setIdentifier('admin.sqms@gov.in');
      setPassword('admin@123');
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoginError(null);
    setIsSubmitting(true);
    try {
      const user = await login(role, { identifier, password });
      const targetRole = user?.role || role;
      if (targetRole === 'citizen') navigate('/');
      else if (targetRole === 'officer') navigate('/officer');
      else if (targetRole === 'admin') navigate('/admin');
    } catch (err) {
      setLoginError(err.message || 'Login failed. Please verify credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSSO = () => {
    loginWithGoogle(role);
    if (role === 'citizen') navigate('/');
    else if (role === 'officer') navigate('/officer');
    else if (role === 'admin') navigate('/admin');
  };

  const handlePresetLogin = async (presetRole) => {
    setLoginError(null);
    setIsSubmitting(true);
    try {
      const user = await login(presetRole);
      const targetRole = user?.role || presetRole;
      if (targetRole === 'citizen') navigate('/');
      else if (targetRole === 'officer') navigate('/officer');
      else if (targetRole === 'admin') navigate('/admin');
    } catch (err) {
      setLoginError(err.message || 'Preset authentication failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{ maxWidth: '1080px', margin: '2rem auto', padding: '0 1rem' }}>
      {/* Portal Hero Header */}
      <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '68px',
            height: '68px',
            borderRadius: '50%',
            backgroundColor: '#134074',
            color: 'white',
            marginBottom: '1rem',
            boxShadow: '0 6px 16px rgba(19, 64, 116, 0.28)',
          }}
        >
          <Landmark size={36} />
        </div>
        <h1 className="page-title" style={{ marginBottom: '0.5rem', fontSize: '2rem' }}>
          {t('portalTitle')}
        </h1>
        <p className="page-subtitle" style={{ fontSize: '1.05rem', margin: '0 auto', maxWidth: '640px' }}>
          Government Citizen Service Portal • Multi-Role Secure Access
        </p>

        {/* Security Notice: All routes locked before login */}
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            marginTop: '1rem',
            padding: '6px 16px',
            background: 'rgba(2, 132, 199, 0.1)',
            border: '1px solid rgba(2, 132, 199, 0.3)',
            borderRadius: '20px',
            fontSize: '0.82rem',
            color: 'var(--info)',
            fontWeight: 600,
          }}
        >
          <ShieldAlert size={16} />
          <span>Strict Access Control Active: Authenticate to enter your role-specific dashboard</span>
        </div>
      </div>

      {/* Main Authentication Card */}
      <div
        className="card"
        style={{
          maxWidth: '560px',
          margin: '0 auto 2.5rem',
          borderRadius: '1rem',
          overflow: 'hidden',
          boxShadow: '0 12px 28px -5px rgba(0,0,0,0.12)',
        }}
      >
        {/* Role Selector Header Tabs */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            background: 'var(--gray-100)',
            borderBottom: '1px solid var(--gray-200)',
          }}
        >
          <button
            type="button"
            onClick={() => handleRoleChange('citizen')}
            style={{
              padding: '1rem 0.5rem',
              border: 'none',
              borderBottom: role === 'citizen' ? '3px solid #134074' : '3px solid transparent',
              background: role === 'citizen' ? 'var(--white)' : 'transparent',
              fontWeight: role === 'citizen' ? '700' : '500',
              color: role === 'citizen' ? '#134074' : 'var(--gray-500)',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              transition: 'all 0.2s',
            }}
          >
            <User size={20} />
            <span style={{ fontSize: '0.9rem' }}>{t('citizenRole')}</span>
          </button>

          <button
            type="button"
            onClick={() => handleRoleChange('officer')}
            style={{
              padding: '1rem 0.5rem',
              border: 'none',
              borderBottom: role === 'officer' ? '3px solid #0284c7' : '3px solid transparent',
              background: role === 'officer' ? 'var(--white)' : 'transparent',
              fontWeight: role === 'officer' ? '700' : '500',
              color: role === 'officer' ? '#0284c7' : 'var(--gray-500)',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              transition: 'all 0.2s',
            }}
          >
            <ShieldCheck size={20} />
            <span style={{ fontSize: '0.9rem' }}>{t('officerRole')}</span>
          </button>

          <button
            type="button"
            onClick={() => handleRoleChange('admin')}
            style={{
              padding: '1rem 0.5rem',
              border: 'none',
              borderBottom: role === 'admin' ? '3px solid #7c3aed' : '3px solid transparent',
              background: role === 'admin' ? 'var(--white)' : 'transparent',
              fontWeight: role === 'admin' ? '700' : '500',
              color: role === 'admin' ? '#7c3aed' : 'var(--gray-500)',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              transition: 'all 0.2s',
            }}
          >
            <Landmark size={20} />
            <span style={{ fontSize: '0.9rem' }}>{t('adminRole')}</span>
          </button>
        </div>

        <div className="card-body" style={{ padding: '2rem' }}>
          {/* Active Role Credentials Hint */}
          <div
            style={{
              background: role === 'officer' ? '#f0f9ff' : role === 'admin' ? '#faf5ff' : '#eff6ff',
              border: `1px solid ${role === 'officer' ? '#bae6fd' : role === 'admin' ? '#e9d5ff' : '#bfdbfe'}`,
              padding: '0.75rem 1rem',
              borderRadius: '0.5rem',
              fontSize: '0.82rem',
              color: role === 'officer' ? '#0369a1' : role === 'admin' ? '#6b21a8' : '#1e40af',
              marginBottom: '1.25rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <span>
              <strong>Logging in as:</strong> {role === 'citizen' ? 'Citizen (Rahul Patil)' : role === 'officer' ? 'Service Officer (Priya Sharma - Counter 3)' : 'System Administrator'}
            </span>
            <span style={{ fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: 700 }}>
              {role}
            </span>
          </div>

          {loginError && (
            <div
              style={{
                backgroundColor: '#fef2f2',
                border: '1px solid #fecaca',
                color: '#b91c1c',
                padding: '0.75rem 1rem',
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                marginBottom: '1.25rem',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <ShieldAlert size={18} />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit}>
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.5rem' }}>
                {role === 'citizen' ? 'Mobile Number / Aadhaar ID' : role === 'officer' ? 'Officer Gov Email / Govt ID' : 'Admin Username / Email'}
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }}>
                  {role === 'citizen' ? <Phone size={18} /> : <Mail size={18} />}
                </span>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={role === 'citizen' ? 'Enter 10-digit mobile' : 'name@gov.in'}
                  style={{
                    width: '100%',
                    padding: '0.75rem 0.75rem 0.75rem 2.5rem',
                    borderRadius: '0.5rem',
                    border: '1px solid var(--gray-300)',
                    background: 'var(--white)',
                    color: 'inherit',
                    fontSize: '0.95rem',
                    boxSizing: 'border-box',
                  }}
                  required
                />
              </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.5rem' }}>
                Password / OTP
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }}>
                  <Lock size={18} />
                </span>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password or demo OTP"
                  style={{
                    width: '100%',
                    padding: '0.75rem 0.75rem 0.75rem 2.5rem',
                    borderRadius: '0.5rem',
                    border: '1px solid var(--gray-300)',
                    background: 'var(--white)',
                    color: 'inherit',
                    fontSize: '0.95rem',
                    boxSizing: 'border-box',
                  }}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary btn-block"
              disabled={isSubmitting}
              style={{
                padding: '0.85rem',
                fontSize: '1rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                borderRadius: '0.5rem',
                backgroundColor: role === 'officer' ? '#0284c7' : role === 'admin' ? '#7c3aed' : '#134074',
                borderColor: role === 'officer' ? '#0284c7' : role === 'admin' ? '#7c3aed' : '#134074',
                marginBottom: '1rem',
                cursor: isSubmitting ? 'not-allowed' : 'pointer',
                opacity: isSubmitting ? 0.7 : 1,
              }}
            >
              <LogIn size={20} />
              {isSubmitting ? 'Authenticating...' : `${t('login')} as ${role === 'citizen' ? t('citizenRole') : role === 'officer' ? t('officerRole') : t('adminRole')}`}
            </button>
          </form>

          {/* Google SSO Login Section */}
          <div style={{ position: 'relative', textAlign: 'center', margin: '1.5rem 0 1rem' }}>
            <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: '1px', background: 'var(--gray-200)' }} />
            <span style={{ position: 'relative', background: 'var(--white)', padding: '0 10px', color: 'var(--gray-400)', fontSize: '0.8rem' }}>OR</span>
          </div>

          <button
            type="button"
            onClick={handleGoogleSSO}
            style={{
              width: '100%',
              padding: '0.75rem',
              borderRadius: '0.5rem',
              border: '1px solid var(--gray-300)',
              background: 'var(--white)',
              color: 'inherit',
              fontWeight: 600,
              fontSize: '0.95rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.75rem',
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
              transition: 'background 0.15s',
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
              <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.39 7.37 24 12 24z" />
              <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z" />
              <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.37 0 3.26 2.61 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
            </svg>
            {t('continueGoogle')}
          </button>
        </div>
      </div>

      {/* Fast 1-Click Demo Login Presets */}
      <div style={{ marginBottom: '3.5rem' }}>
        <h3 style={{ textAlign: 'center', fontSize: '1.05rem', color: 'var(--gray-500)', marginBottom: '1.25rem', fontWeight: 700 }}>
          ⚡ Fast 1-Click Demo Logins
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(290px, 1fr))', gap: '1rem' }}>
          <div
            onClick={() => handlePresetLogin('citizen')}
            style={{
              background: 'var(--white)',
              border: '2px solid var(--gray-200)',
              borderRadius: '0.75rem',
              padding: '1.25rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              transition: 'transform 0.15s, border-color 0.15s',
            }}
          >
            <div style={{ background: '#e0f2fe', color: '#0369a1', padding: '0.75rem', borderRadius: '50%' }}>
              <User size={24} />
            </div>
            <div style={{ flexGrow: 1 }}>
              <h4 style={{ margin: 0, fontSize: '0.95rem' }}>Rahul Patil</h4>
              <p style={{ margin: '2px 0 0', fontSize: '0.78rem', color: 'var(--gray-500)' }}>
                Citizen Portal • Token A-042 • Live Queue
              </p>
            </div>
            <ArrowRight size={18} color="var(--gray-400)" />
          </div>

          <div
            onClick={() => handlePresetLogin('officer')}
            style={{
              background: 'var(--white)',
              border: '2px solid var(--gray-200)',
              borderRadius: '0.75rem',
              padding: '1.25rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              transition: 'transform 0.15s, border-color 0.15s',
            }}
          >
            <div style={{ background: '#e0f2fe', color: '#0284c7', padding: '0.75rem', borderRadius: '50%' }}>
              <ShieldCheck size={24} />
            </div>
            <div style={{ flexGrow: 1 }}>
              <h4 style={{ margin: 0, fontSize: '0.95rem' }}>Ms. Priya Sharma</h4>
              <p style={{ margin: '2px 0 0', fontSize: '0.78rem', color: 'var(--gray-500)' }}>
                Service Officer • Counter 3 • 30m/15m Reminders
              </p>
            </div>
            <ArrowRight size={18} color="var(--gray-400)" />
          </div>

          <div
            onClick={() => handlePresetLogin('admin')}
            style={{
              background: 'var(--white)',
              border: '2px solid var(--gray-200)',
              borderRadius: '0.75rem',
              padding: '1.25rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              transition: 'transform 0.15s, border-color 0.15s',
            }}
          >
            <div style={{ background: '#f3e8ff', color: '#7c3aed', padding: '0.75rem', borderRadius: '50%' }}>
              <Landmark size={24} />
            </div>
            <div style={{ flexGrow: 1 }}>
              <h4 style={{ margin: 0, fontSize: '0.95rem' }}>System Admin</h4>
              <p style={{ margin: '2px 0 0', fontSize: '0.78rem', color: 'var(--gray-500)' }}>
                Administrator • Analytics • Real-time Monitoring
              </p>
            </div>
            <ArrowRight size={18} color="var(--gray-400)" />
          </div>
        </div>
      </div>

      {/* SECTION: How to Access the Application & Interactive Feature Preview */}
      <div id="access-preview-section" style={{ borderTop: '2px solid var(--gray-200)', paddingTop: '3rem', marginBottom: '3rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '4px 14px',
              borderRadius: '20px',
              background: 'rgba(2, 132, 199, 0.1)',
              color: '#0284c7',
              fontSize: '0.82rem',
              fontWeight: 700,
              marginBottom: '0.5rem',
            }}
          >
            <HelpCircle size={15} />
            APPLICATION GUIDE & SYSTEM PREVIEW
          </div>
          <h2 style={{ fontSize: '1.75rem', margin: '0 0 0.5rem' }}>How to Access the Application & Feature Preview</h2>
          <p style={{ color: 'var(--gray-500)', fontSize: '0.95rem', maxWidth: '680px', margin: '0 auto' }}>
            Learn how Citizens, Service Officers, and Administrators operate the Smart Queue Management System before logging in.
          </p>
        </div>

        {/* 3-Step Guide Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', marginBottom: '2.5rem' }}>
          <div className="card" style={{ padding: '1.5rem', borderRadius: '0.75rem', borderLeft: '4px solid #134074' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
              <div style={{ background: '#134074', color: '#fff', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>
                1
              </div>
              <h4 style={{ margin: 0, fontSize: '1.05rem' }}>Select User Role</h4>
            </div>
            <p style={{ fontSize: '0.86rem', color: 'var(--gray-500)', lineHeight: '1.5', margin: 0 }}>
              Choose your profile from the tabs above. <strong>Citizen</strong> for booking and tracking, <strong>Service Officer</strong> for verifying documents and queue calls, or <strong>System Admin</strong> for oversight.
            </p>
          </div>

          <div className="card" style={{ padding: '1.5rem', borderRadius: '0.75rem', borderLeft: '4px solid #0284c7' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
              <div style={{ background: '#0284c7', color: '#fff', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>
                2
              </div>
              <h4 style={{ margin: 0, fontSize: '1.05rem' }}>Enter Credentials / 1-Click</h4>
            </div>
            <p style={{ fontSize: '0.86rem', color: 'var(--gray-500)', lineHeight: '1.5', margin: 0 }}>
              Use the pre-filled demo accounts or click any of the <strong>Fast 1-Click Demo Logins</strong>. You can also sign in with Google SSO demo authentication.
            </p>
          </div>

          <div className="card" style={{ padding: '1.5rem', borderRadius: '0.75rem', borderLeft: '4px solid #16a34a' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
              <div style={{ background: '#16a34a', color: '#fff', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>
                3
              </div>
              <h4 style={{ margin: 0, fontSize: '1.05rem' }}>Experience Secure Workflows</h4>
            </div>
            <p style={{ fontSize: '0.86rem', color: 'var(--gray-500)', lineHeight: '1.5', margin: 0 }}>
              Once authenticated, your role-specific dashboard and navigation bar will automatically unlock with strict route isolation and live queue synchronization.
            </p>
          </div>
        </div>

        {/* Interactive Feature Preview Container ("use that preview in which") */}
        <div className="card" style={{ borderRadius: '1rem', overflow: 'hidden', border: '1px solid var(--gray-200)', boxShadow: '0 8px 24px rgba(0,0,0,0.06)' }}>
          <div style={{ padding: '1.25rem 1.5rem', background: 'var(--gray-100)', borderBottom: '1px solid var(--gray-200)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Eye size={20} color="#0284c7" />
              <h3 style={{ margin: 0, fontSize: '1.1rem' }}>Live Feature Preview Showcase</h3>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              <button
                type="button"
                className={`btn btn-sm ${previewTab === 'citizen' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setPreviewTab('citizen')}
              >
                Citizen Portal Preview
              </button>
              <button
                type="button"
                className={`btn btn-sm ${previewTab === 'officer' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setPreviewTab('officer')}
              >
                Officer Workspace Preview
              </button>
              <button
                type="button"
                className={`btn btn-sm ${previewTab === 'reminders' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setPreviewTab('reminders')}
              >
                30m & 15m Reminders Preview
              </button>
              <button
                type="button"
                className={`btn btn-sm ${previewTab === 'admin' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setPreviewTab('admin')}
              >
                Admin Analytics Preview
              </button>
            </div>
          </div>

          <div className="card-body" style={{ padding: '2rem' }}>
            {/* PREVIEW TAB 1: Citizen View */}
            {previewTab === 'citizen' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h4 style={{ margin: 0, fontSize: '1.2rem', color: '#134074' }}>Citizen Workspace Experience</h4>
                    <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: 'var(--gray-500)' }}>
                      What Rahul Patil sees: Digital Token, QR Check-in, and Reminders from Counter 3.
                    </p>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-primary"
                    onClick={() => handlePresetLogin('citizen')}
                    style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                  >
                    <LogIn size={15} /> Launch Citizen Portal Demo
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem' }}>
                  {/* Mock Token Card */}
                  <div style={{ border: '2px dashed #0284c7', borderRadius: '0.75rem', padding: '1.25rem', background: 'rgba(2, 132, 199, 0.03)', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--gray-400)', letterSpacing: '0.05em' }}>DIGITAL TOKEN</div>
                    <div style={{ fontSize: '2.4rem', fontWeight: 800, color: '#0284c7', margin: '4px 0' }}>A-042</div>
                    <div style={{ display: 'inline-block', padding: '2px 10px', background: '#dcfce7', color: '#16a34a', borderRadius: '12px', fontSize: '0.78rem', fontWeight: 700 }}>
                      Checked-In • Counter 3
                    </div>
                    <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--white)', borderRadius: '0.5rem', border: '1px solid var(--gray-200)', fontSize: '0.82rem', textAlign: 'left' }}>
                      <div><strong>Service:</strong> Income Certificate</div>
                      <div><strong>Slot:</strong> 10:30 AM - 11:00 AM</div>
                      <div><strong>Office:</strong> Tehsildar Administrative Complex</div>
                    </div>
                  </div>

                  {/* Mock Reminder Alerts in Citizen View */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                    <div style={{ background: '#fef3c7', border: '1px solid #fde68a', borderRadius: '0.5rem', padding: '1rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, color: '#b45309', fontSize: '0.88rem' }}>
                        <Clock size={16} /> 30-Minute Officer Turn Reminder
                      </div>
                      <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: '#92400e', lineHeight: '1.4' }}>
                        "Your Token A-042 will arrive in approx. 30 minutes! Please proceed to the waiting lounge."
                      </p>
                    </div>

                    <div style={{ background: '#fee2e2', border: '1px solid #fecaca', borderRadius: '0.5rem', padding: '1rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, color: '#b91c1c', fontSize: '0.88rem' }}>
                        <Bell size={16} /> 15-Minute Final Call Alert
                      </div>
                      <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: '#991b1b', lineHeight: '1.4' }}>
                        "Token A-042 is next in line! Expected turn in 15 minutes at Counter 3. Please be present at the desk."
                      </p>
                    </div>

                    <div style={{ background: 'var(--white)', border: '1px solid var(--gray-200)', borderRadius: '0.5rem', padding: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <QrCode size={36} color="#134074" />
                      <div style={{ fontSize: '0.8rem' }}>
                        <div style={{ fontWeight: 700 }}>Encrypted Check-in QR</div>
                        <div style={{ color: 'var(--gray-500)' }}>Scanned by Officer for physical desk verification</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* PREVIEW TAB 2: Officer View */}
            {previewTab === 'officer' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h4 style={{ margin: 0, fontSize: '1.2rem', color: '#0284c7' }}>Service Officer Workspace Experience</h4>
                    <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: 'var(--gray-500)' }}>
                      What Ms. Priya Sharma sees at Counter 3: QR scanner, Document Verification, and Citizen Reminders.
                    </p>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-primary"
                    onClick={() => handlePresetLogin('officer')}
                    style={{ backgroundColor: '#0284c7', borderColor: '#0284c7', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                  >
                    <ShieldCheck size={15} /> Launch Officer Workspace Demo
                  </button>
                </div>

                <div style={{ background: '#f8fafc', border: '1px solid var(--gray-200)', borderRadius: '0.75rem', padding: '1.25rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Radio size={18} color="#0284c7" />
                      <strong>Counter 3 Desk: Income Certificate</strong>
                    </div>
                    <span style={{ fontSize: '0.8rem', padding: '3px 8px', background: '#e0f2fe', color: '#0369a1', borderRadius: '4px', fontWeight: 700 }}>
                      Currently Processing: Token A-042 (Rahul Patil)
                    </span>
                  </div>

                  {/* Officer Reminder Triggers Preview */}
                  <div style={{ background: '#ffffff', border: '1px solid #bae6fd', borderRadius: '0.5rem', padding: '1rem', marginBottom: '1rem' }}>
                    <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: '0.5rem' }}>
                      Officer Turn Reminder Dispatch Controls (SMS & In-App Alert):
                    </div>
                    <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="btn btn-sm"
                        style={{ background: '#fef3c7', color: '#b45309', border: '1px solid #fde68a', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        ⏰ Send 30 Min Reminder to Citizen
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm"
                        style={{ background: '#fee2e2', color: '#dc2626', border: '1px solid #fecaca', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        🚨 Send 15 Min Final Call to Citizen
                      </button>
                    </div>
                  </div>

                  {/* Document Verification Checks */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.5rem', fontSize: '0.82rem' }}>
                    <div style={{ padding: '8px', background: '#fff', borderRadius: '4px', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <CheckCircle size={15} color="#16a34a" /> 1. Aadhaar Card Verified
                    </div>
                    <div style={{ padding: '8px', background: '#fff', borderRadius: '4px', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <CheckCircle size={15} color="#16a34a" /> 2. Address Proof Verified
                    </div>
                    <div style={{ padding: '8px', background: '#fff', borderRadius: '4px', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <CheckCircle size={15} color="#16a34a" /> 3. Income Salary Slip Approved
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* PREVIEW TAB 3: 30m & 15m Reminders Deep Dive */}
            {previewTab === 'reminders' && (
              <div>
                <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
                  <h4 style={{ margin: 0, fontSize: '1.25rem', color: '#0284c7' }}>
                    Smart Turn Reminder Architecture (30 Min & 15 Min)
                  </h4>
                  <p style={{ margin: '4px 0 0', fontSize: '0.88rem', color: 'var(--gray-500)' }}>
                    How Service Officers reduce no-shows and keep counter operations moving without delays.
                  </p>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
                  <div style={{ background: '#fffbeb', border: '2px solid #fcd34d', borderRadius: '0.75rem', padding: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#d97706', fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.75rem' }}>
                      <Clock size={22} /> 30-Minute Turn Reminder
                    </div>
                    <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.86rem', color: '#92400e', lineHeight: '1.6' }}>
                      <li>Triggered by the Service Officer as upcoming tokens move forward in queue.</li>
                      <li>Notifies the citizen on their phone via SMS & portal notification.</li>
                      <li>Prompts the citizen to start traveling towards the Administrative Complex.</li>
                      <li>Ensures citizen arrives with original documents and required photocopies.</li>
                    </ul>
                  </div>

                  <div style={{ background: '#fef2f2', border: '2px solid #fca5a5', borderRadius: '0.75rem', padding: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#dc2626', fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.75rem' }}>
                      <Zap size={22} /> 15-Minute Immediate Call
                    </div>
                    <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.86rem', color: '#991b1b', lineHeight: '1.6' }}>
                      <li>Triggered by Officer when citizen is 1-2 numbers away from active service.</li>
                      <li>Urgent high-priority alert on the Citizen's Token & Queue screens.</li>
                      <li>Guides the citizen to take their seat directly in front of Counter 3.</li>
                      <li>Eliminates idle counter waiting times and speeds up citizen service throughput.</li>
                    </ul>
                  </div>
                </div>

                <div style={{ marginTop: '1.5rem', textAlign: 'center' }}>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handlePresetLogin('officer')}
                    style={{ backgroundColor: '#0284c7', borderColor: '#0284c7' }}
                  >
                    Test Reminder Feature in Officer Dashboard
                  </button>
                </div>
              </div>
            )}

            {/* PREVIEW TAB 4: Admin Analytics View */}
            {previewTab === 'admin' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h4 style={{ margin: 0, fontSize: '1.2rem', color: '#7c3aed' }}>System Administrator Dashboard Experience</h4>
                    <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: 'var(--gray-500)' }}>
                      What System Admins see: Real-time counter metrics, throughput, wait-time charts, and grievance handling.
                    </p>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-primary"
                    onClick={() => handlePresetLogin('admin')}
                    style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                  >
                    <Landmark size={15} /> Launch Admin Dashboard Demo
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid var(--gray-200)', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-500)' }}>Total Bookings</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#134074' }}>248</div>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid var(--gray-200)', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-500)' }}>Active in Queue</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0284c7' }}>42</div>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid var(--gray-200)', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-500)' }}>Active Counters</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#16a34a' }}>5 / 5</div>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid var(--gray-200)', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-500)' }}>Resolved Grievances</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#7c3aed' }}>12</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
