// Secure Smart Queue Management System — Urgent (Tatkal) Emergency Requests
import { Router } from 'express';
import { getDb } from '../db.js';
import { logAuditEvent } from '../utils/auditLogger.js';
import { requireRole } from '../middleware/auth.js';

const router = Router();

function uid() {
  return Math.random().toString(36).slice(2, 6).toUpperCase();
}

// GET /api/urgent — List urgent requests
router.get('/', (req, res) => {
  const db = getDb();
  let rows;
  if (req.user.role === 'citizen') {
    rows = db.prepare(`
      SELECT u.*, s.name AS service_name
      FROM urgent_requests u
      JOIN services s ON s.id = u.service_id
      WHERE u.citizen_id = ?
      ORDER BY u.created_at DESC
    `).all(req.user.id);
  } else {
    rows = db.prepare(`
      SELECT u.*, s.name AS service_name, usr.name AS citizen_name, usr.mobile AS citizen_mobile
      FROM urgent_requests u
      JOIN services s ON s.id = u.service_id
      JOIN users usr ON usr.id = u.citizen_id
      ORDER BY u.created_at DESC
    `).all();
  }
  res.json(rows);
});

// POST /api/urgent — Citizen submits urgent priority request
router.post('/', (req, res) => {
  const { serviceId, urgencyType, reason, date } = req.body || {};
  if (!serviceId || !urgencyType || !reason) {
    return res.status(400).json({ error: 'serviceId, urgencyType, and reason are required' });
  }

  const db = getDb();
  const id = `URG-${new Date().getFullYear()}-${uid()}`;
  const dateStr = date || new Date().toISOString().slice(0, 10);

  db.prepare(`
    INSERT INTO urgent_requests (id, citizen_id, service_id, date, reason, urgency_type, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `).run(id, req.user.id, serviceId, dateStr, reason, urgencyType);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'citizen',
    action: 'URGENT_REQUEST_SUBMITTED',
    resourceType: 'urgent_request',
    resourceId: id,
    details: `Tatkal request for ${serviceId} due to ${urgencyType}: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  const created = db.prepare('SELECT * FROM urgent_requests WHERE id = ?').get(id);
  res.status(201).json(created);
});

// PATCH /api/urgent/:id/review — Officer approves or rejects urgent priority
router.patch('/:id/review', requireRole('officer', 'admin'), (req, res) => {
  const { status, decisionNotes } = req.body || {};
  if (!status || !['approved', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Status must be approved or rejected' });
  }

  const db = getDb();
  const request = db.prepare('SELECT * FROM urgent_requests WHERE id = ?').get(req.params.id);
  if (!request) return res.status(404).json({ error: 'Urgent request not found' });

  db.transaction(() => {
    db.prepare(`
      UPDATE urgent_requests SET
        status = ?,
        decision_notes = ?,
        reviewed_by = ?,
        updated_at = datetime('now')
      WHERE id = ?
    `).run(status, decisionNotes || null, req.user.id, request.id);

    // If approved, elevate active token priority to 'urgent'
    if (status === 'approved') {
      db.prepare(`
        UPDATE tokens SET
          priority_type = 'urgent',
          priority_reason = ?,
          priority_authorized_by = ?
        WHERE citizen_id = ? AND service_id = ? AND queue_status IN ('scheduled', 'waiting', 'arrived')
      `).run(`Urgent approval: ${decisionNotes || request.reason}`, req.user.id, request.citizen_id, request.service_id);
    }

    // Citizen notification
    const msg = status === 'approved'
      ? `🚨 Urgent Tatkal Request APPROVED! Your token has been elevated to Priority Queue.`
      : `Tatkal urgent request declined. Officer note: ${decisionNotes || 'Criteria not met.'}`;

    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, ?)
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      request.citizen_id,
      msg,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      status === 'approved' ? 'success' : 'warning'
    );
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'URGENT_REQUEST_REVIEWED',
    resourceType: 'urgent_request',
    resourceId: request.id,
    details: `Urgent request ${status}. Notes: ${decisionNotes || 'None'}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, request: db.prepare('SELECT * FROM urgent_requests WHERE id = ?').get(request.id) });
});

export default router;
