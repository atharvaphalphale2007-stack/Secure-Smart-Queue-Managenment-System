// Secure Smart Queue Management System (SQMS) — Automated Test Suite
// Executes end-to-end tests across Auth, RBAC, Booking Engine, Two-Stage QR,
// Queue State Transitions, Tamper-Evident Audit Ledger, Document Uploads, and Bilingual Chatbot.

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { unlinkSync, existsSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEST_DB_PATH = join(__dirname, '..', 'data', 'test_sqms.db');

// Set isolated test database
process.env.DB_PATH = TEST_DB_PATH;
process.env.NODE_ENV = 'test';

// Clean existing test DB if any
if (existsSync(TEST_DB_PATH)) {
  try { unlinkSync(TEST_DB_PATH); } catch {}
}

// Import server and database utilities
const { startServer } = await import('../src/index.js');
const { getDb, closeDb } = await import('../src/db.js');

let serverInstance;
let BASE_URL;

// Tokens for role testing
let citizenToken;
let officerToken;
let adminToken;

// Helper to calculate future weekday
function getFutureWeekday(daysAhead = 1) {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  while (d.getDay() === 0 || d.getDay() === 6) {
    d.setDate(d.getDate() + 1);
  }
  return d.toISOString().split('T')[0];
}

// Helper to calculate next weekend
function getNextWeekend() {
  const d = new Date();
  while (d.getDay() !== 6) {
    d.setDate(d.getDate() + 1);
  }
  return d.toISOString().split('T')[0];
}

describe('Secure Smart Queue Management System (SQMS) Test Suite', () => {
  before(async () => {
    // Start server on an ephemeral port
    serverInstance = await startServer(0);
    const port = serverInstance.address().port;
    BASE_URL = `http://127.0.0.1:${port}`;
    console.log(`[TEST-SUITE] Test server running on ${BASE_URL} with DB ${TEST_DB_PATH}`);
  });

  after(async () => {
    if (serverInstance) {
      await new Promise((resolve) => serverInstance.close(resolve));
    }
    closeDb();
    if (existsSync(TEST_DB_PATH)) {
      try { unlinkSync(TEST_DB_PATH); } catch {}
    }
    console.log(`[TEST-SUITE] Test server stopped and test database cleaned.`);
  });

  // -------------------------------------------------------------
  // 1. Health & System Status
  // -------------------------------------------------------------
  describe('1. Health Check Endpoint', () => {
    test('GET /api/health returns 200 and production status', async () => {
      const res = await fetch(`${BASE_URL}/api/health`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.status, 'ok');
      assert.equal(data.service, 'sqms-server');
      assert.equal(data.version, '2.0.0-production');
    });
  });

  // -------------------------------------------------------------
  // 2. Authentication & Role-Based Access Control (RBAC)
  // -------------------------------------------------------------
  describe('2. Authentication & RBAC', () => {
    test('Register new citizen account', async () => {
      const res = await fetch(`${BASE_URL}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Sunita Deshmukh',
          mobile: '9822001122',
          email: 'sunita.deshmukh@example.com',
          password: 'Password@123',
          aadhaar: 'XXXX-XXXX-9900',
          address: 'Kothrud, Pune',
        }),
      });
      assert.equal(res.status, 201);
      const data = await res.json();
      assert.ok(data.token, 'Should return JWT token');
      assert.equal(data.user.role, 'citizen');
      assert.equal(data.user.name, 'Sunita Deshmukh');
    });

    test('Login with invalid credentials fails', async () => {
      const res = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: '9876543210',
          password: 'wrongpassword',
        }),
      });
      assert.equal(res.status, 401);
      const data = await res.json();
      assert.ok(data.error);
    });

    test('Login as Citizen (Rahul Patil)', async () => {
      const res = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: '9876543210',
          password: 'demo123',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.token);
      assert.equal(data.user.role, 'citizen');
      citizenToken = data.token;
    });

    test('Login as Officer (Priya Sharma)', async () => {
      const res = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: 'priya.sharma@gov.in',
          password: 'officer@123',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.token);
      assert.equal(data.user.role, 'officer');
      assert.equal(data.user.counter, 3);
      officerToken = data.token;
    });

    test('Login as Administrator', async () => {
      const res = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: 'admin.sqms@gov.in',
          password: 'admin@123',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.token);
      assert.equal(data.user.role, 'admin');
      adminToken = data.token;
    });

    test('RBAC: Citizen is forbidden from accessing Admin stats', async () => {
      const res = await fetch(`${BASE_URL}/api/admin/stats`, {
        headers: { Authorization: `Bearer ${citizenToken}` },
      });
      assert.equal(res.status, 403);
      const data = await res.json();
      assert.match(data.error, /admin/i);
    });

    test('RBAC: Admin successfully accesses Admin stats', async () => {
      const res = await fetch(`${BASE_URL}/api/admin/stats`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.totalBookings !== undefined);
      assert.ok(data.totalCitizens !== undefined);
    });
  });

  // -------------------------------------------------------------
  // 3. Government Services Catalog
  // -------------------------------------------------------------
  describe('3. Services Catalog', () => {
    test('GET /api/services lists official government services', async () => {
      const res = await fetch(`${BASE_URL}/api/services`);
      assert.equal(res.status, 200);
      const data = await res.json();
      const services = Array.isArray(data) ? data : data.services;
      assert.ok(Array.isArray(services));
      assert.ok(services.length >= 8);

      const incomeSrv = services.find((s) => s.id === 'income');
      assert.ok(incomeSrv);
      assert.equal(incomeSrv.name, 'Income Certificate');
      assert.ok(Array.isArray(incomeSrv.requiredDocs));
      assert.ok(incomeSrv.requiredDocs.length > 0);
    });

    test('GET /api/services/income returns details and official rules', async () => {
      const res = await fetch(`${BASE_URL}/api/services/income`);
      assert.equal(res.status, 200);
      const service = await res.json();
      assert.equal(service.id, 'income');
      assert.ok(service.eligibility_info);
      assert.ok(service.official_source);
    });
  });

  // -------------------------------------------------------------
  // 4. Booking Engine & Business Constraints
  // -------------------------------------------------------------
  describe('4. Booking Engine & Policy Constraints', () => {
    test('Rejects booking on weekend (Saturday / Sunday)', async () => {
      const weekendDate = getNextWeekend();
      const res = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'income',
          appointment_date: weekendDate,
          time_slot: '10:00 AM - 10:30 AM',
        }),
      });
      assert.equal(res.status, 400);
      const data = await res.json();
      assert.match(data.error, /weekends/i);
    });

    test('Rejects booking on official public holiday', async () => {
      const res = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'income',
          appointment_date: '2026-12-25', // Future holiday in seed data (Christmas)
          time_slot: '10:00 AM - 10:30 AM',
        }),
      });
      assert.equal(res.status, 400);
      const data = await res.json();
      assert.match(data.error, /holiday/i);
    });

    let createdBookingId;
    const validBookingDate = getFutureWeekday(3);

    test('Successfully books an appointment on a valid business day', async () => {
      const res = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'income',
          appointment_date: validBookingDate,
          time_slot: '10:00 AM - 10:30 AM',
        }),
      });
      assert.equal(res.status, 201);
      const data = await res.json();
      assert.ok(data.booking);
      assert.ok(data.booking.id);
      assert.ok(data.booking.token_number);
      assert.ok(data.token);
      createdBookingId = data.booking.id;
    });

    test('Prevents double-booking same service on same date for same citizen', async () => {
      const res = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'income',
          appointment_date: validBookingDate,
          time_slot: '11:00 AM - 11:30 AM', // Different slot, same date & service
        }),
      });
      assert.ok(res.status === 400 || res.status === 409);
      const data = await res.json();
      assert.match(data.error, /already have an active appointment/i);
    });

    test('Slot capacity limit: enforces maximum slot capacity', async () => {
      // Seed allows default_slot_capacity = 3
      // Create 3 temporary citizens to fill slot
      const otherSlot = '02:00 PM - 02:30 PM';
      const fillDate = getFutureWeekday(5);

      for (let i = 1; i <= 3; i++) {
        // Register temp citizen
        const regRes = await fetch(`${BASE_URL}/api/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: `Cap User ${i}`,
            mobile: `980000000${i}`,
            password: 'Password@123',
          }),
        });
        const regData = await regRes.json();
        const tempToken = regData.token;

        const bookRes = await fetch(`${BASE_URL}/api/booking`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${tempToken}`,
          },
          body: JSON.stringify({
            office_id: 'OFFICE-PUNE-01',
            service_id: 'residence',
            appointment_date: fillDate,
            time_slot: otherSlot,
          }),
        });
        assert.equal(bookRes.status, 201);
      }

      // 4th booking on same slot must be rejected
      const overflowRes = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'residence',
          appointment_date: fillDate,
          time_slot: otherSlot,
        }),
      });
      assert.ok(overflowRes.status === 400 || overflowRes.status === 409);
      const overflowData = await overflowRes.json();
      assert.match(overflowData.error, /fully booked/i);
    });

    test('Reschedule appointment updates booking date and time slot', async () => {
      const newDate = getFutureWeekday(7);
      const res = await fetch(`${BASE_URL}/api/booking/${createdBookingId}/reschedule`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          new_date: newDate,
          new_slot: '11:30 AM - 12:00 PM',
          reason: 'Personal work reschedule',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.booking.appointment_date, newDate);
      assert.equal(data.booking.time_slot, '11:30 AM - 12:00 PM');
    });

    test('Cancel appointment marks booking and token as cancelled', async () => {
      const res = await fetch(`${BASE_URL}/api/booking/${createdBookingId}/cancel`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          reason: 'No longer required',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
    });
  });

  // -------------------------------------------------------------
  // 5. Two-Stage QR Cryptographic Verification & Security Gate
  // -------------------------------------------------------------
  describe('5. Cryptographic Two-Stage QR Verification', () => {
    let testTokenNumber;

    before(async () => {
      // Create a fresh token for Stage 1 & Stage 2 verification testing
      const bookDate = getFutureWeekday(2);
      const res = await fetch(`${BASE_URL}/api/booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          office_id: 'OFFICE-PUNE-01',
          service_id: 'income',
          appointment_date: bookDate,
          time_slot: '09:00 AM - 09:30 AM',
        }),
      });
      const data = await res.json();
      testTokenNumber = data.booking.token_number;
    });

    test('Rejects tampered / corrupted QR code signature', async () => {
      const fakeQrString = Buffer.from(JSON.stringify({
        tnum: testTokenNumber,
        off: 'OFFICE-PUNE-01',
        srv: 'income',
        iat: Date.now(),
        sig: '0000000000000000000000000000000000000000000000000000000000000000',
      })).toString('base64');

      const res = await fetch(`${BASE_URL}/api/queue/verify-stage1`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          qrString: fakeQrString,
        }),
      });
      assert.equal(res.status, 400);
      const data = await res.json();
      assert.match(data.error, /invalid or forged/i);
    });

    test('Enforces Stage 2 gate: Cannot serve counter before Stage 1 arrival verification', async () => {
      // Attempt Stage 2 verification directly before Stage 1
      const res = await fetch(`${BASE_URL}/api/queue/verify-stage2`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          tokenNumber: testTokenNumber,
          counter: 3,
        }),
      });
      assert.equal(res.status, 400);
      const data = await res.json();
      assert.match(data.error, /stage 1 physical arrival/i);
    });

    test('Stage 1 Kiosk Arrival: Validates cryptographic QR and records arrival', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/verify-stage1`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          tokenNumber: testTokenNumber,
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
      assert.equal(data.tokenNumber, testTokenNumber);
      assert.ok(data.verifiedAt);
    });

    test('Stage 2 Counter Verification: Authorized officer serves verified citizen', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/verify-stage2`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          tokenNumber: testTokenNumber,
          counter: 3,
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
      assert.equal(data.tokenNumber, testTokenNumber);
      assert.equal(data.status, 'SERVING');
    });
  });

  // -------------------------------------------------------------
  // 6. Queue State Transitions & Turn Management
  // -------------------------------------------------------------
  describe('6. Queue State Management & Transitions', () => {
    test('Mark absent with mandatory reason', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/mark-absent`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          tokenNumber: 'A-042', // Demo seeded active token
          reason: 'Citizen not present after 3 announcements',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
    });

    test('Restore absent citizen when they arrive', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/restore-absent`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          tokenNumber: 'A-042',
          reason: 'Citizen reported at reception with traffic delay proof',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
    });

    test('Call next waiting token to counter', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/call-next`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          counterId: 3,
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
      assert.ok(data.currentToken);
    });

    test('Complete token service at counter', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${officerToken}`,
        },
        body: JSON.stringify({
          tokenNumber: 'A-042',
          remarks: 'Verification completed, application approved',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
    });

    test('Live queue endpoint returns active state and counters', async () => {
      const res = await fetch(`${BASE_URL}/api/queue/live?officeId=OFFICE-PUNE-01`, {
        headers: { Authorization: `Bearer ${citizenToken}` },
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.counters));
      assert.ok(Array.isArray(data.queue));
    });
  });

  // -------------------------------------------------------------
  // 7. Tamper-Evident SHA-256 Audit Trail
  // -------------------------------------------------------------
  describe('7. Tamper-Evident Cryptographic Audit Ledger', () => {
    test('Audit trail verifies successfully when untampered', async () => {
      const res = await fetch(`${BASE_URL}/api/admin/audit-logs/verify`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.valid, true);
      assert.ok(data.totalChecked > 0);
    });

    test('Tamper detection: Detects direct modification in SQLite database', async () => {
      const db = getDb();

      // Retrieve last audit row
      const lastRow = db.prepare('SELECT id, details FROM audit_logs ORDER BY id DESC LIMIT 1').get();
      assert.ok(lastRow);

      const originalDetails = lastRow.details;

      // Illegitimately tamper with the audit record in SQLite
      db.prepare('UPDATE audit_logs SET details = ? WHERE id = ?').run(
        JSON.stringify({ malicious_tamper: true }),
        lastRow.id
      );

      // Verify that audit log verification endpoint detects tampering
      const res = await fetch(`${BASE_URL}/api/admin/audit-logs/verify`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.valid, false);
      assert.equal(data.failedAtId, lastRow.id);

      // Revert the tamper to restore integrity
      db.prepare('UPDATE audit_logs SET details = ? WHERE id = ?').run(originalDetails, lastRow.id);

      // Re-verify that audit trail is valid again
      const restoredRes = await fetch(`${BASE_URL}/api/admin/audit-logs/verify`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      const restoredData = await restoredRes.json();
      assert.equal(restoredData.valid, true);
    });
  });

  // -------------------------------------------------------------
  // 8. Document Uploads & Magic Byte Validation
  // -------------------------------------------------------------
  describe('8. Document Security & Magic Byte Validation', () => {
    test('Rejects spoofed file disguised as PDF (invalid magic bytes)', async () => {
      const fakePdfContent = 'MZ\x90\x00\x03ThisIsAnExecutableDisguisedAsPdf';
      const base64Data = Buffer.from(fakePdfContent).toString('base64');

      const res = await fetch(`${BASE_URL}/api/documents/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          docName: 'Income Proof',
          fileName: 'salary_slip.pdf',
          mimeType: 'application/pdf',
          fileBase64: base64Data,
        }),
      });
      assert.equal(res.status, 400);
      const data = await res.json();
      assert.match(data.error, /binary headers do not match/i);
    });

    test('Accepts authentic PDF with genuine magic bytes (%PDF)', async () => {
      const validPdfHeader = '%PDF-1.4\n%âãÏÓ\n1 0 obj\n<<\n/Type /Catalog\n>>\nendobj\ntrailer\n<<\n/Root 1 0 R\n>>\n%%EOF';
      const base64Data = Buffer.from(validPdfHeader).toString('base64');

      const res = await fetch(`${BASE_URL}/api/documents/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${citizenToken}`,
        },
        body: JSON.stringify({
          docName: 'Income Proof',
          fileName: 'valid_salary_slip.pdf',
          mimeType: 'application/pdf',
          fileBase64: base64Data,
        }),
      });
      assert.equal(res.status, 201);
      const data = await res.json();
      assert.ok(data.document);
      assert.ok(data.document.id);
      assert.equal(data.document.verification_status, 'pending');
    });
  });

  // -------------------------------------------------------------
  // 9. Bilingual Knowledgebase Chatbot
  // -------------------------------------------------------------
  describe('9. Bilingual Chatbot Assistant', () => {
    test('Answers English query regarding Income Certificate requirements', async () => {
      const res = await fetch(`${BASE_URL}/api/chatbot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'What documents are required for income certificate?',
          language: 'en',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.reply);
      assert.match(data.reply, /Aadhaar card/i);
    });

    test('Answers Marathi query regarding documents in Marathi', async () => {
      const res = await fetch(`${BASE_URL}/api/chatbot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'उत्पन्नाच्या दाखल्यासाठी कोणती कागदपत्रे लागतात?',
          language: 'mr',
        }),
      });
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.reply);
      assert.match(data.reply, /कागदपत्रे/i);
    });
  });
});
