param(
  [string]$OutputPath = "Secure-Smart-Queue-Management-System.zip"
)

$ErrorActionPreference = "Stop"
$root = Get-Location
$destZip = Join-Path $root $OutputPath

Write-Host "Packaging Secure Smart Queue Management System (SQMS)..."

$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("sqms_pkg_" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

try {
  $excludeList = @("node_modules", "dist", ".git", "*.zip", ".temp")
  Get-ChildItem -Path $root -Exclude $excludeList | Copy-Item -Destination $tempDir -Recurse -Force

  # Clean server node_modules and test db artifacts
  $serverModules = Join-Path $tempDir "server\node_modules"
  if (Test-Path $serverModules) { Remove-Item -Path $serverModules -Recurse -Force }

  $testDb = Join-Path $tempDir "server\data\test_sqms.db"
  if (Test-Path $testDb) { Remove-Item -Path $testDb -Force }

  if (Test-Path $destZip) {
    Remove-Item -Path $destZip -Force
  }

  Compress-Archive -Path "$tempDir\*" -DestinationPath $destZip -CompressionLevel Optimal
  $fileInfo = Get-Item $destZip
  Write-Host "Package successfully created: $($fileInfo.FullName) ($([math]::Round($fileInfo.Length / 1KB, 2)) KB)"
}
finally {
  if (Test-Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force
  }
}
