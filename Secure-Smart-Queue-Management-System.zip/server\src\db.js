// Secure Smart Queue Management System — Database Layer
// Native SQLite Database via Node 24 node:sqlite (DatabaseSync)
// Provides full persistence, WAL journal mode, foreign key enforcement, and transactions.

import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { readFileSync, mkdirSync, existsSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SCHEMA_PATH = join(__dirname, 'schema.sql');
const DEFAULT_DATA_DIR = join(__dirname, '..', 'data');
const DEFAULT_DB_PATH = join(DEFAULT_DATA_DIR, 'sqms.db');

class StatementWrapper {
  constructor(stmt) {
    this._stmt = stmt;
  }

  _normalize(params) {
    if (params.length === 1 && Array.isArray(params[0])) {
      return params[0];
    }
    return params;
  }

  run(...params) {
    const args = this._normalize(params);
    return this._stmt.run(...args);
  }

  get(...params) {
    const args = this._normalize(params);
    const row = this._stmt.get(...args);
    return row || undefined;
  }

  all(...params) {
    const args = this._normalize(params);
    return this._stmt.all(...args);
  }
}

let _db = null;
let _dbPath = null;

export function initDb(customPath = null) {
  if (_db) return _db;

  const targetPath = customPath || process.env.DB_PATH || DEFAULT_DB_PATH;
  _dbPath = targetPath;

  if (targetPath !== ':memory:') {
    const dir = dirname(targetPath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
  }

  const rawDb = new DatabaseSync(targetPath);

  // Enable foreign keys, WAL mode, and busy timeout
  rawDb.exec('PRAGMA foreign_keys = ON;');
  if (targetPath !== ':memory:') {
    rawDb.exec('PRAGMA journal_mode = WAL;');
  }
  rawDb.exec('PRAGMA busy_timeout = 5000;');

  // Apply schema migrations
  const schemaSql = readFileSync(SCHEMA_PATH, 'utf-8');
  rawDb.exec(schemaSql);

  // Record initial migration
  const checkMigration = rawDb.prepare(
    'SELECT version FROM schema_migrations WHERE version = ?'
  ).get(1);
  if (!checkMigration) {
    rawDb.prepare(
      'INSERT INTO schema_migrations (version, name) VALUES (?, ?)'
    ).run(1, '001_initial_production_schema');
  }

  _db = rawDb;
  return getDb();
}

export function getDb() {
  if (!_db) {
    initDb();
  }

  return {
    raw: _db,
    prepare(sql) {
      return new StatementWrapper(_db.prepare(sql));
    },
    exec(sql) {
      return _db.exec(sql);
    },
    transaction(fn) {
      _db.exec('BEGIN IMMEDIATE;');
      try {
        const result = fn(this);
        _db.exec('COMMIT;');
        return result;
      } catch (err) {
        _db.exec('ROLLBACK;');
        throw err;
      }
    },
    getPath() {
      return _dbPath;
    },
  };
}

export function closeDb() {
  if (_db) {
    try {
      _db.close();
    } catch {
      // Ignore if already closed
    }
    _db = null;
    _dbPath = null;
  }
}

export default { initDb, getDb, closeDb };
