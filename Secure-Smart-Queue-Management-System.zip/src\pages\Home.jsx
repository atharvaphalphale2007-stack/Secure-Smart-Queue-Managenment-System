import React from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Radio,
  Ticket,
  FileCheck,
  Zap,
  AlertTriangle,
  IndianRupee,
  Users,
  Home as HomeIcon,
  MapPin,
  Baby,
  FileX,
  UserCheck,
  Clock,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { SERVICES } from '../data/mockData';
import { useAppContext } from '../context/AppContext';

const getServiceIcon = (iconName) => {
  const icons = {
    IndianRupee,
    Users,
    Home: HomeIcon,
    MapPin,
    Baby,
    FileX,
    UserCheck,
    FileCheck,
  };
  const IconComponent = icons[iconName] || FileCheck;
  return <IconComponent size={24} />;
};

const Home = () => {
  const {
    user,
    citizen,
    token,
    tokenReminders = {},
    currentServing,
    queuePosition,
    estimatedWait,
    checkedIn,
    documents = [],
  } = useAppContext();

  const tokenReminderInfo = tokenReminders[token?.tokenNumber] || token?.reminders || {};
  const has30MinReminder = tokenReminderInfo.reminder30Min;
  const has15MinReminder = tokenReminderInfo.reminder15Min;

  return (
    <div className="page">
      {/* Citizen Welcome & Hero Banner */}
      <div className="hero" style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', background: 'rgba(255,255,255,0.18)', padding: '4px 12px', borderRadius: '20px', fontSize: '0.82rem', fontWeight: 600, marginBottom: '0.75rem' }}>
          <Sparkles size={14} color="#facc15" /> Government Citizen Service Portal • Pune Division
        </div>
        <h1>Welcome, {user?.name || citizen?.name || 'Citizen'}</h1>
        <p>
          Book government revenue & welfare services, track your token in real-time, receive 30m & 15m officer turn reminders, and download digital certificates.
        </p>
        <div className="hero-buttons">
          <Link to="/services" className="btn btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
            <Calendar size={18} /> Book a Government Service
          </Link>
          <Link to="/my-token" className="btn btn-secondary" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
            <Ticket size={18} /> View My Token & Status
          </Link>
          <Link to="/queue" className="btn btn-outline" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: '#ffffff', borderColor: 'rgba(255,255,255,0.4)' }}>
            <Radio size={18} /> Public Queue Board
          </Link>
        </div>
      </div>

      {/* ACTIVE CITIZEN TOKEN COMMAND CENTER (Shown if citizen has an active token) */}
      {token && (
        <div className="section" style={{ marginTop: '-1.5rem', marginBottom: '2rem' }}>
          <div
            className="card"
            style={{
              border: has15MinReminder ? '2px solid #ef4444' : has30MinReminder ? '2px solid #f59e0b' : '2px solid #0284c7',
              boxShadow: '0 10px 25px rgba(0,0,0,0.08)',
              overflow: 'hidden',
            }}
          >
            {/* Top Alert Bar based on Reminder */}
            <div
              style={{
                background: has15MinReminder
                  ? 'linear-gradient(90deg, #ef4444, #b91c1c)'
                  : has30MinReminder
                  ? 'linear-gradient(90deg, #f59e0b, #d97706)'
                  : 'linear-gradient(90deg, #0284c7, #0369a1)',
                color: '#ffffff',
                padding: '0.65rem 1.25rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '8px',
                fontSize: '0.85rem',
                fontWeight: 700,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {has15MinReminder ? <Zap size={18} /> : has30MinReminder ? <Clock size={18} /> : <Ticket size={18} />}
                <span>
                  {has15MinReminder
                    ? '🚨 URGENT: 15-Minute Final Call Active! Please report to Counter 3 now.'
                    : has30MinReminder
                    ? '⏰ 30-Minute Turn Reminder Active! Please arrive at Tehsildar Complex waiting lounge.'
                    : 'Active Token Allocated for Today • Queue Tracking in Progress'}
                </span>
              </div>
              <span style={{ background: 'rgba(255,255,255,0.2)', padding: '2px 8px', borderRadius: '12px', fontSize: '0.75rem' }}>
                {checkedIn ? '✓ Office Checked-In' : 'Pending Kiosk Check-In'}
              </span>
            </div>

            <div className="card-body" style={{ padding: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1.25rem' }}>
                {/* Token Badge */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
                  <div
                    style={{
                      background: 'var(--primary-50)',
                      border: '2px solid var(--primary-200)',
                      borderRadius: '12px',
                      padding: '0.75rem 1.25rem',
                      textAlign: 'center',
                    }}
                  >
                    <span style={{ fontSize: '0.72rem', color: 'var(--primary-800)', textTransform: 'uppercase', fontWeight: 800 }}>TOKEN NUMBER</span>
                    <div style={{ fontSize: '32px', fontWeight: 900, color: 'var(--primary-900)', lineHeight: '1.1' }}>
                      {token.tokenNumber}
                    </div>
                    <span style={{ fontSize: '0.75rem', color: 'var(--gray-500)', fontWeight: 600 }}>{token.counterName || 'Counter 3'}</span>
                  </div>

                  <div>
                    <h3 style={{ margin: '0 0 4px', fontSize: '1.2rem', color: 'var(--gray-900)' }}>
                      {token.service}
                    </h3>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', fontSize: '0.85rem', color: 'var(--gray-600)' }}>
                      <span><strong>Officer:</strong> Ms. Priya Sharma</span>
                      <span>•</span>
                      <span><strong>Date:</strong> {token.date}</span>
                      <span>•</span>
                      <span><strong>Slot:</strong> {token.time}</span>
                    </div>
                  </div>
                </div>

                {/* Live Queue Stat Pill */}
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  <div style={{ background: 'var(--gray-100)', padding: '0.5rem 1rem', borderRadius: '8px', textAlign: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--gray-500)', textTransform: 'uppercase', display: 'block' }}>Now Serving</span>
                    <strong style={{ fontSize: '1.2rem', color: '#0284c7' }}>{currentServing || 'A-035'}</strong>
                  </div>

                  <div style={{ background: 'var(--gray-100)', padding: '0.5rem 1rem', borderRadius: '8px', textAlign: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--gray-500)', textTransform: 'uppercase', display: 'block' }}>Ahead in Line</span>
                    <strong style={{ fontSize: '1.2rem', color: '#ea580c' }}>{queuePosition ?? 7} citizens</strong>
                  </div>

                  <div style={{ background: 'var(--gray-100)', padding: '0.5rem 1rem', borderRadius: '8px', textAlign: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--gray-500)', textTransform: 'uppercase', display: 'block' }}>Est. Wait</span>
                    <strong style={{ fontSize: '1.2rem', color: '#16a34a' }}>~{estimatedWait ?? 18} min</strong>
                  </div>
                </div>

                {/* Quick Action Button */}
                <div>
                  <Link to="/my-token" className="btn btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                    <span>Open My Token Slip</span>
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4 Feature Highlights */}
      <div className="section">
        <div className="grid-4">
          <div className="card">
            <div className="card-body">
              <div className="service-icon"><Ticket size={32} /></div>
              <h3>Digital Tokens</h3>
              <p>Instant contactless queue tokens with printable slips and official QR verification.</p>
            </div>
          </div>
          <div className="card">
            <div className="card-body">
              <div className="service-icon"><Clock size={32} /></div>
              <h3>30m & 15m Turn Reminders</h3>
              <p>Service officers dispatch SMS and voice call alerts before your number is called.</p>
            </div>
          </div>
          <div className="card">
            <div className="card-body">
              <div className="service-icon"><Radio size={32} /></div>
              <h3>Live Multi-Counter Queue</h3>
              <p>Public TV display board and real-time position tracking from your smartphone.</p>
            </div>
          </div>
          <div className="card">
            <div className="card-body">
              <div className="service-icon"><FileCheck size={32} /></div>
              <h3>Digital Certificates</h3>
              <p>Download digitally signed government documents directly to My Documents.</p>
            </div>
          </div>
        </div>
      </div>

      {/* ISSUED DOCUMENTS SUMMARY (If any documents available) */}
      {documents && documents.length > 0 && (
        <div className="section">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2 className="section-title" style={{ margin: 0 }}>Digitally Issued Certificates</h2>
            <Link to="/my-documents" style={{ fontSize: '0.85rem', fontWeight: 600, color: '#0284c7' }}>
              View All ({documents.length}) &rarr;
            </Link>
          </div>
          <div className="grid-2">
            {documents.map((doc, idx) => (
              <div key={idx} className="card" style={{ borderLeft: '4px solid #16a34a' }}>
                <div className="card-body" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <span className="badge badge-success" style={{ marginBottom: '4px', display: 'inline-block' }}>Digitally Issued</span>
                    <h4 style={{ margin: '2px 0', textTransform: 'uppercase' }}>{doc.type}</h4>
                    <p style={{ margin: 0, fontSize: '0.8rem', color: 'var(--gray-500)' }}>
                      ID: {doc.id} • Issued: {doc.issueDate}
                    </p>
                  </div>
                  <Link to="/my-documents" className="btn btn-outline btn-sm">
                    View Certificate
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* How It Works Workflow */}
      <div className="section">
        <h2 className="section-title">6-Step Citizen Service Journey</h2>
        <div className="steps-row">
          <div className="step-card">
            <div className="step-number">1</div>
            <h4>Select Service</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>Choose revenue, caste, or birth certificate</p>
          </div>
          <div className="step-card">
            <div className="step-number">2</div>
            <h4>Choose Slot</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>Pick convenient date & time slot</p>
          </div>
          <div className="step-card">
            <div className="step-number">3</div>
            <h4>Get Token</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>Instant QR slip & counter routing</p>
          </div>
          <div className="step-card">
            <div className="step-number">4</div>
            <h4>Officer Reminders</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>SMS & audio alert at 30m & 15m</p>
          </div>
          <div className="step-card">
            <div className="step-number">5</div>
            <h4>Counter Desk</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>Document verification & review</p>
          </div>
          <div className="step-card">
            <div className="step-number">6</div>
            <h4>Instant Issue</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--gray-500)', margin: '4px 0 0' }}>Digitally signed certificate issued</p>
          </div>
        </div>
      </div>

      {/* Popular Services Grid */}
      <div className="section">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h2 className="section-title" style={{ margin: 0 }}>Available Citizen Services</h2>
          <Link to="/services" style={{ fontSize: '0.85rem', fontWeight: 600, color: '#0284c7' }}>
            Browse All Services &rarr;
          </Link>
        </div>
        <div className="grid-4">
          {SERVICES.slice(0, 8).map((service) => (
            <div key={service.id} className="service-card card">
              <div className="card-body">
                <div className="service-icon">{getServiceIcon(service.icon)}</div>
                <h3>{service.name}</h3>
                <p>{service.description}</p>
                <Link
                  to="/booking"
                  state={{ serviceId: service.id, serviceName: service.name }}
                  className="btn btn-outline btn-sm"
                  style={{ marginTop: '8px' }}
                >
                  Book Slot &rarr;
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Important Notice */}
      <div className="section">
        <div className="alert alert-warning" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <AlertTriangle size={24} style={{ flexShrink: 0 }} />
          <span>
            <strong>Official Citizen Advisory:</strong> Please carry original Aadhaar cards, income proofs, and requisite photocopies for physical verification at Counter 3. Stay attentive to SMS and Public Address announcements.
          </span>
        </div>
      </div>
    </div>
  );
};

export default Home;
