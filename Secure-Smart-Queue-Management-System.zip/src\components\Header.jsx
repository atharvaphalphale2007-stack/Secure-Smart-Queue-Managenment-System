import React, { useState, useRef, useEffect } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import {
  Landmark,
  Home,
  Calendar,
  Ticket,
  Radio,
  FileText,
  AlertTriangle,
  Bell,
  Menu,
  X,
  User,
  ScanLine,
  ClipboardList,
  LayoutDashboard,
  LogIn,
  LogOut,
  ChevronDown,
  ShieldCheck,
  Zap,
  Sun,
  Moon,
  Globe,
  HelpCircle,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import NotificationDropdown from './NotificationDropdown';

export default function Header() {
  const { user, citizen, notifications, logout, theme, toggleTheme, language, setLanguage, t } = useAppContext();
  const navigate = useNavigate();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const notifRef = useRef(null);
  const moreRef = useRef(null);

  const unreadCount = (notifications || []).filter((n) => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (moreRef.current && !moreRef.current.contains(event.target)) {
        setShowMoreMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleLogoutClick = () => {
    logout();
    navigate('/login');
  };

  const handleGuidePreviewClick = () => {
    if (window.location.pathname !== '/login') {
      navigate('/login');
    }
    setTimeout(() => {
      const previewEl = document.getElementById('access-preview-section');
      if (previewEl) {
        previewEl.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const currentRole = user?.role || null;
  const userName = user?.name || citizen?.name || 'Citizen User';

  return (
    <header className="header">
      {/* Top Banner */}
      <div className="header-top" style={{ gap: '1rem', flexWrap: 'wrap' }}>
        <Link
          to={!user ? '/login' : currentRole === 'officer' ? '/officer' : currentRole === 'admin' ? '/admin' : '/'}
          className="header-brand"
          style={{ textDecoration: 'none', color: 'inherit' }}
        >
          <div className="header-emblem" aria-label="National Emblem Placeholder">
            <Landmark size={24} color="#ffffff" />
          </div>
          <div className="header-titles">
            <h1>{t('portalTitle')}</h1>
            <p>{t('portalSubtitle')}</p>
          </div>
        </Link>

        <div className="header-actions" style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          {/* Multi-Language Selector */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', background: 'rgba(255,255,255,0.15)', padding: '2px 8px', borderRadius: '20px' }}>
            <Globe size={14} color="#ffffff" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              style={{
                background: 'transparent',
                color: 'white',
                border: 'none',
                fontWeight: 600,
                fontSize: '0.8rem',
                cursor: 'pointer',
                outline: 'none',
              }}
            >
              <option value="en" style={{ color: '#000' }}>English</option>
              <option value="mr" style={{ color: '#000' }}>मराठी</option>
              <option value="hi" style={{ color: '#000' }}>हिंदी</option>
            </select>
          </div>

          {/* Light / Dark Mode Toggle: Explicitly available before & after login */}
          <button
            type="button"
            className="header-icon-btn"
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 10px', background: 'rgba(255,255,255,0.15)', borderRadius: '20px' }}
          >
            {theme === 'dark' ? <Sun size={16} color="#facc15" /> : <Moon size={16} color="#ffffff" />}
            <span style={{ fontSize: '0.78rem', color: '#ffffff', fontWeight: 600 }}>
              {theme === 'dark' ? 'Light' : 'Dark'}
            </span>
          </button>

          {/* Before Login: "How to Access & Preview" button */}
          {!user && (
            <button
              type="button"
              className="header-icon-btn"
              onClick={handleGuidePreviewClick}
              title="How to Access the Application & Feature Preview"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '6px 12px',
                background: 'rgba(255,255,255,0.2)',
                borderRadius: '20px',
                border: '1px solid rgba(255,255,255,0.3)',
                color: '#ffffff',
                fontWeight: 600,
                fontSize: '0.78rem',
                cursor: 'pointer',
              }}
            >
              <HelpCircle size={15} color="#ffffff" />
              <span>How to Access & Preview</span>
            </button>
          )}

          {/* Logged in Only: Notification Bell */}
          {user && (
            <div ref={notifRef} style={{ position: 'relative' }}>
              <button
                type="button"
                className="header-icon-btn"
                onClick={() => setShowNotifications((prev) => !prev)}
                title="Notifications"
                aria-label="View notifications"
                aria-expanded={showNotifications}
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="notification-badge" aria-label={`${unreadCount} unread notifications`}>
                    {unreadCount}
                  </span>
                )}
              </button>

              <NotificationDropdown
                isOpen={showNotifications}
                onClose={() => setShowNotifications(false)}
              />
            </div>
          )}

          {/* Logged in Only: User Profile Pill */}
          {user && (
            <div className="header-profile" title={`Role: ${currentRole.toUpperCase()}`}>
              <div
                className="header-avatar"
                aria-hidden="true"
                style={{
                  background: currentRole === 'officer' ? '#0284c7' : currentRole === 'admin' ? '#7c3aed' : '#134074',
                }}
              >
                {currentRole === 'officer' ? <ShieldCheck size={16} /> : currentRole === 'admin' ? <Landmark size={16} /> : <User size={16} />}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', textAlign: 'left' }}>
                <span className="header-profile-name" style={{ fontSize: '0.82rem', fontWeight: 600 }}>{userName}</span>
                <span style={{ fontSize: '0.68rem', color: 'rgba(255,255,255,0.8)', textTransform: 'capitalize' }}>
                  {currentRole === 'citizen' ? t('citizenRole') : currentRole === 'officer' ? t('officerRole') : t('adminRole')}
                </span>
              </div>
            </div>
          )}

          {/* Login / Logout Button */}
          <button
            type="button"
            className="header-icon-btn"
            onClick={user ? handleLogoutClick : () => navigate('/login')}
            title={user ? t('logout') : t('login')}
            aria-label={user ? t('logout') : t('login')}
            style={!user ? { display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 12px', background: 'rgba(255,255,255,0.25)', borderRadius: '20px' } : undefined}
          >
            {user ? (
              <LogOut size={20} />
            ) : (
              <>
                <LogIn size={16} />
                <span style={{ fontSize: '0.8rem', fontWeight: 700 }}>{t('login')}</span>
              </>
            )}
          </button>

          {/* Logged in Only: Mobile Hamburger Toggle */}
          {user && (
            <button
              type="button"
              className="header-icon-btn hamburger-btn"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
            >
              <Menu size={22} />
            </button>
          )}
        </div>
      </div>

      {/* Role-Protected Navigation Bar: ONLY RENDERED AFTER USER LOGS IN */}
      {user && (
        <nav className="header-nav" aria-label="Primary Navigation">
          {currentRole === 'citizen' && (
            <>
              <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
                <Home size={16} />
                <span>{t('home')}</span>
              </NavLink>

              <NavLink to="/services" className={({ isActive }) => (isActive ? 'active' : '')}>
                <Calendar size={16} />
                <span>{t('bookService')}</span>
              </NavLink>

              <NavLink to="/my-token" className={({ isActive }) => (isActive ? 'active' : '')}>
                <Ticket size={16} />
                <span>{t('myToken')}</span>
              </NavLink>

              <NavLink to="/queue" className={({ isActive }) => (isActive ? 'active' : '')}>
                <Radio size={16} />
                <span>{t('trackQueue')}</span>
              </NavLink>

              <NavLink to="/my-documents" className={({ isActive }) => (isActive ? 'active' : '')}>
                <FileText size={16} />
                <span>{t('myDocuments')}</span>
              </NavLink>

              <NavLink to="/grievance" className={({ isActive }) => (isActive ? 'active' : '')}>
                <AlertTriangle size={16} />
                <span>{t('raiseGrievance')}</span>
              </NavLink>

              <NavLink to="/urgent-request" className={({ isActive }) => (isActive ? 'active' : '')}>
                <Zap size={16} />
                <span>{t('urgentRequest')}</span>
              </NavLink>

              {/* More Citizen Links Dropdown */}
              <div ref={moreRef} style={{ position: 'relative', marginLeft: 'auto' }}>
                <button
                  type="button"
                  onClick={() => setShowMoreMenu((prev) => !prev)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    background: showMoreMenu ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.1)',
                    color: 'white',
                    border: 'none',
                    padding: '7px 14px',
                    borderRadius: '20px',
                    fontSize: '0.82rem',
                    fontWeight: '500',
                    cursor: 'pointer',
                  }}
                >
                  <span>More</span>
                  <ChevronDown size={14} />
                </button>

                {showMoreMenu && (
                  <div
                    style={{
                      position: 'absolute',
                      top: 'calc(100% + 8px)',
                      right: 0,
                      width: '210px',
                      background: 'white',
                      borderRadius: '8px',
                      boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
                      border: '1px solid #e2e8f0',
                      padding: '6px 0',
                      zIndex: 160,
                    }}
                  >
                    <NavLink
                      to="/check-in"
                      onClick={() => setShowMoreMenu(false)}
                      style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', color: '#1e293b', fontSize: '0.85rem', textDecoration: 'none' }}
                    >
                      <ScanLine size={16} color="#134074" />
                      <span>Check-in / QR</span>
                    </NavLink>

                    <NavLink
                      to="/application-status"
                      onClick={() => setShowMoreMenu(false)}
                      style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', color: '#1e293b', fontSize: '0.85rem', textDecoration: 'none' }}
                    >
                      <ClipboardList size={16} color="#134074" />
                      <span>Application Status</span>
                    </NavLink>
                  </div>
                )}
              </div>
            </>
          )}

          {currentRole === 'officer' && (
            <>
              <NavLink to="/officer" end className={({ isActive }) => (isActive ? 'active' : '')}>
                <ShieldCheck size={16} />
                <span>{t('officerWorkspace')}</span>
              </NavLink>
            </>
          )}

          {currentRole === 'admin' && (
            <>
              <NavLink to="/admin" end className={({ isActive }) => (isActive ? 'active' : '')}>
                <LayoutDashboard size={16} />
                <span>{t('adminDashboard')}</span>
              </NavLink>
            </>
          )}
        </nav>
      )}

      {/* Logged in Only: Mobile Navigation Drawer */}
      {user && (
        <>
          <div
            className={`mobile-nav-overlay ${mobileMenuOpen ? 'open' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <div
            className={`mobile-nav ${mobileMenuOpen ? 'open' : ''}`}
            role="dialog"
            aria-modal="true"
            aria-label="Mobile Navigation"
          >
            <div className="mobile-nav-close">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close menu"
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#ffffff',
                  cursor: 'pointer',
                  padding: '4px',
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <X size={24} />
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {currentRole === 'citizen' && (
                <>
                  <NavLink to="/" end onClick={() => setMobileMenuOpen(false)}>
                    <Home size={18} />
                    <span>{t('home')}</span>
                  </NavLink>
                  <NavLink to="/services" onClick={() => setMobileMenuOpen(false)}>
                    <Calendar size={18} />
                    <span>{t('bookService')}</span>
                  </NavLink>
                  <NavLink to="/my-token" onClick={() => setMobileMenuOpen(false)}>
                    <Ticket size={18} />
                    <span>{t('myToken')}</span>
                  </NavLink>
                  <NavLink to="/queue" onClick={() => setMobileMenuOpen(false)}>
                    <Radio size={18} />
                    <span>{t('trackQueue')}</span>
                  </NavLink>
                  <NavLink to="/check-in" onClick={() => setMobileMenuOpen(false)}>
                    <ScanLine size={18} />
                    <span>Check-in / QR</span>
                  </NavLink>
                  <NavLink to="/documents-verification" onClick={() => setMobileMenuOpen(false)}>
                    <FileText size={18} />
                    <span>Verify Documents</span>
                  </NavLink>
                  <NavLink to="/application-status" onClick={() => setMobileMenuOpen(false)}>
                    <ClipboardList size={18} />
                    <span>Application Status</span>
                  </NavLink>
                  <NavLink to="/my-documents" onClick={() => setMobileMenuOpen(false)}>
                    <FileText size={18} />
                    <span>{t('myDocuments')}</span>
                  </NavLink>
                  <NavLink to="/grievance" onClick={() => setMobileMenuOpen(false)}>
                    <AlertTriangle size={18} />
                    <span>{t('raiseGrievance')}</span>
                  </NavLink>
                  <NavLink to="/urgent-request" onClick={() => setMobileMenuOpen(false)}>
                    <Zap size={18} />
                    <span>Tatkal / Urgent</span>
                  </NavLink>
                </>
              )}
              {currentRole === 'officer' && (
                <NavLink to="/officer" end onClick={() => setMobileMenuOpen(false)}>
                  <ShieldCheck size={18} />
                  <span>{t('officerWorkspace')}</span>
                </NavLink>
              )}
              {currentRole === 'admin' && (
                <NavLink to="/admin" end onClick={() => setMobileMenuOpen(false)}>
                  <LayoutDashboard size={18} />
                  <span>{t('adminDashboard')}</span>
                </NavLink>
              )}
            </div>
          </div>
        </>
      )}
    </header>
  );
}
