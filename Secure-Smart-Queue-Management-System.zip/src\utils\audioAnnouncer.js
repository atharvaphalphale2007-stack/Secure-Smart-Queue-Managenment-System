// ============================================================
// SMART QUEUE MANAGEMENT SYSTEM — Audio Chime & Speech Synthesis
// ============================================================

/**
 * Play a professional airport/counter two-tone announcement chime
 */
export function playCounterChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Tone 1: 587.33 Hz (D5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.4);

    // Tone 2: 880 Hz (A5)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.25);
    gain2.gain.setValueAtTime(0.18, now + 0.25);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.25);
    osc2.stop(now + 0.8);
  } catch (err) {
    console.warn('Audio chime unavailable:', err);
  }
}

/**
 * Voice announcement using browser SpeechSynthesis
 *
 * @param {string} text Announcement text
 * @param {string} lang Language code ('en', 'hi', 'mr')
 */
export function speakAnnouncement(text, lang = 'en') {
  try {
    if (!('speechSynthesis' in window)) return;

    // Play initial chime
    playCounterChime();

    setTimeout(() => {
      window.speechSynthesis.cancel(); // Cancel any ongoing speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.05;

      if (lang === 'hi') {
        utterance.lang = 'hi-IN';
      } else if (lang === 'mr') {
        utterance.lang = 'mr-IN';
      } else {
        utterance.lang = 'en-IN';
      }

      window.speechSynthesis.speak(utterance);
    }, 450);
  } catch (err) {
    console.warn('Speech synthesis unavailable:', err);
  }
}
