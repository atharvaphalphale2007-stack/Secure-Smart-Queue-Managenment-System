import React, { useState, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import ConfirmationModal from '../components/ConfirmationModal';
import Toast from '../components/Toast';
import { TIME_SLOTS, SERVICES, SERVICE_COUNTER_MAP } from '../data/mockData';
import {
  getNextDays,
  getDayName,
  formatDateShort,
  formatDateLong,
  formatDateISO,
  isWeekend,
} from '../utils/helpers';

const Booking = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { booking, setBooking, setToken } = useAppContext();

  // If user navigates to /booking directly, default gracefully to Income Certificate instead of a dead-end error
  const initialService =
    location.state ||
    (booking
      ? { serviceId: booking.serviceId, serviceName: booking.serviceName }
      : { serviceId: 'income', serviceName: 'Income Certificate' });

  const [currentService, setCurrentService] = useState(initialService);
  const days = getNextDays(10); // Show next 10 days to include weekdays and weekends

  // Default to the first weekday so the page never loads on a weekend
  const firstWeekdayIndex = useMemo(
    () => days.findIndex((d) => !isWeekend(d)),
    [days]
  );
  const [selectedDate, setSelectedDate] = useState(
    firstWeekdayIndex >= 0 ? firstWeekdayIndex : 0
  );
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [serverSlots, setServerSlots] = useState([]);
  const [isOfficeClosed, setIsOfficeClosed] = useState(false);
  const [closedReason, setClosedReason] = useState('');

  const currentDateObj = days[selectedDate];
  const isSelectedDateWeekend = isWeekend(currentDateObj);

  React.useEffect(() => {
    const isoDate = formatDateISO(currentDateObj);
    import('../utils/api').then(({ api }) => {
      api.getSlots(isoDate, currentService.serviceId)
        .then((res) => {
          if (res?.closed) {
            setIsOfficeClosed(true);
            setClosedReason(res.reason || 'Closed');
            setServerSlots([]);
          } else {
            setIsOfficeClosed(false);
            setClosedReason('');
            setServerSlots(res?.slots || []);
          }
        })
        .catch(() => {
          setIsOfficeClosed(false);
        });
    });
  }, [selectedDate, currentService.serviceId, currentDateObj]);

  const dismissToast = (id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Real backend availability with local seed fallback
  const slotAvailability = (dateIndex, slotIndex) => {
    if (dateIndex === selectedDate && serverSlots.length > 0) {
      const serverSlot = serverSlots[slotIndex];
      if (serverSlot) return serverSlot.status;
    }
    const seed = (dateIndex * 7 + slotIndex * 3) % 10;
    if (seed < 6) return 'available';
    if (seed < 8) return 'limited';
    return 'unavailable';
  };

  const handleConfirm = async () => {
    if (isSelectedDateWeekend || isOfficeClosed || selectedSlot === null) return;
    const dateObj = days[selectedDate];
    const slot = TIME_SLOTS[selectedSlot];
    const slotDateIso = formatDateISO(dateObj);

    setIsBookingLoading(true);
    try {
      const { api } = await import('../utils/api');
      const res = await api.createBooking({
        serviceId: currentService.serviceId,
        slotDate: slotDateIso,
        slotTime: slot.time,
        slotLabel: slot.time,
      });

      if (res?.token && res?.booking) {
        setBooking({
          serviceId: currentService.serviceId,
          serviceName: currentService.serviceName,
          date: formatDateLong(dateObj),
          dateISO: slotDateIso,
          timeSlot: slot.time,
          office: 'Tehsildar Office Pune Central',
        });
        setToken({
          tokenId: res.token.id,
          tokenNumber: res.token.token_number,
          service: currentService.serviceName,
          serviceId: currentService.serviceId,
          date: formatDateLong(dateObj),
          time: slot.time,
          counter: res.token.counter_id,
          counterName: `Counter ${res.token.counter_id}`,
          qrString: res.token.qr_payload,
          createdTime: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        });
        setToasts([
          {
            id: 'booking-confirm-success',
            message: `Slot booked! Allocated Token #${res.token.token_number} for Counter ${res.token.counter_id}.`,
            type: 'success',
          },
        ]);
        setShowConfirm(false);
        setTimeout(() => navigate('/my-token'), 800);
        return;
      }
    } catch (err) {
      // If error from backend, show error message
      setToasts([
        {
          id: 'booking-error',
          message: err.message || 'Booking failed. Selected slot might be full.',
          type: 'error',
        },
      ]);
      setShowConfirm(false);
    } finally {
      setIsBookingLoading(false);
    }
  };

  return (
    <div className="page">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Services', path: '/services' },
          { label: 'Booking' },
        ]}
      />

      <div className="section">
        <div className="card">
          <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Calendar size={20} />
              <span>Book Appointment — {currentService.serviceName}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <label htmlFor="service-select" style={{ fontSize: '0.82rem', color: 'var(--gray-500)', margin: 0 }}>Service:</label>
              <select
                id="service-select"
                value={currentService.serviceId}
                onChange={(e) => {
                  const s = SERVICES.find((item) => item.id === e.target.value);
                  if (s) {
                    setCurrentService({ serviceId: s.id, serviceName: s.name });
                  }
                }}
                style={{
                  padding: '4px 8px',
                  borderRadius: '6px',
                  border: '1px solid var(--gray-300)',
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                {SERVICES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="card-body">
            {/* Working Days Notice Banner */}
            <div
              style={{
                background: '#fff7ed',
                border: '1px solid #ffedd5',
                color: '#c2410c',
                padding: '0.75rem 1rem',
                borderRadius: '0.5rem',
                fontSize: '0.85rem',
                marginBottom: '1.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <AlertTriangle size={18} color="#ea580c" />
              <strong>Government Office Schedule:</strong> Working days are <strong>Monday to Friday</strong>.
              Saturdays & Sundays are official government holidays.
            </div>

            {/* Date selection */}
            <h3 className="section-title" style={{ marginBottom: 12 }}>Select Date</h3>
            <div className="date-row" style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '8px' }}>
              {days.map((d, index) => {
                const weekend = isWeekend(d);
                return (
                  <button
                    key={index}
                    type="button"
                    className={`date-chip ${selectedDate === index ? 'selected' : ''}`}
                    disabled={weekend}
                    onClick={() => {
                      if (weekend) return;
                      setSelectedDate(index);
                      setSelectedSlot(null);
                    }}
                    style={{
                      border: weekend ? '1px solid #fca5a5' : undefined,
                      background: selectedDate === index ? undefined : weekend ? '#fef2f2' : undefined,
                      opacity: weekend ? 0.55 : 1,
                      cursor: weekend ? 'not-allowed' : 'pointer',
                    }}
                  >
                    <div className="day-name" style={{ color: weekend ? '#dc2626' : undefined }}>
                      {getDayName(d)} {weekend ? '🏖️' : ''}
                    </div>
                    <div className="day-date">{formatDateShort(d)}</div>
                    {weekend && (
                      <span style={{ fontSize: '0.65rem', color: '#dc2626', fontWeight: 700, marginTop: '2px' }}>
                        Holiday
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Weekend or Official Holiday Warning Notice */}
            {isSelectedDateWeekend || isOfficeClosed ? (
              <div
                style={{
                  background: '#fee2e2',
                  border: '1px solid #fca5a5',
                  color: '#991b1b',
                  padding: '1.25rem',
                  borderRadius: '0.5rem',
                  marginTop: '1.5rem',
                  textAlign: 'center',
                }}
              >
                <AlertTriangle size={32} color="#dc2626" style={{ marginBottom: '0.5rem' }} />
                <h4 style={{ margin: 0, fontSize: '1.1rem' }}>
                  {isOfficeClosed ? (closedReason || 'Government Office Closed on this date') : 'Government Office Closed (Saturday / Sunday Holiday)'}
                </h4>
                <p style={{ margin: '6px 0 0', fontSize: '0.9rem' }}>
                  {isOfficeClosed
                    ? 'Bookings are suspended on official government holidays.'
                    : 'No slots can be booked on weekends. Please select a working weekday (Monday through Friday) above.'}
                </p>
              </div>
            ) : (
              <>
                {/* Time slot selection */}
                <h3 className="section-title" style={{ marginTop: 24, marginBottom: 12 }}>
                  <Clock size={18} /> Select Time Slot
                </h3>
                <div className="slot-grid">
                  {TIME_SLOTS.map((slot, index) => {
                    const availability = slotAvailability(selectedDate, index);
                    const isSelected = selectedSlot === index;

                    let btnClass = 'slot-btn ';
                    let label = '';
                    let isDisabled = false;

                    if (availability === 'unavailable') {
                      btnClass += 'unavailable';
                      label = 'Full';
                      isDisabled = true;
                    } else if (availability === 'limited') {
                      btnClass += 'limited';
                      label = 'Limited';
                    } else {
                      btnClass += 'available';
                      label = 'Available';
                    }

                    if (isSelected) btnClass += ' selected';

                    return (
                      <button
                        key={index}
                        className={btnClass}
                        disabled={isDisabled}
                        onClick={() => setSelectedSlot(index)}
                      >
                        <div>{slot.time}</div>
                        <span className="slot-label">{label}</span>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Booking Summary */}
      {!isSelectedDateWeekend && selectedDate !== null && selectedSlot !== null && (
        <div className="section">
          <div className="booking-summary">
            <h3>Booking Summary</h3>
            <div className="summary-row">
              <span className="summary-label">Service</span>
              <span className="summary-value">{currentService.serviceName}</span>
            </div>
            <div className="summary-row">
              <span className="summary-label">Date</span>
              <span className="summary-value">{formatDateLong(days[selectedDate])}</span>
            </div>
            <div className="summary-row">
              <span className="summary-label">Time</span>
              <span className="summary-value">{TIME_SLOTS[selectedSlot].time}</span>
            </div>
            <div className="summary-row">
              <span className="summary-label">Counter</span>
              <span className="summary-value">Counter {SERVICE_COUNTER_MAP[currentService.serviceId] || 3}</span>
            </div>
            <div className="summary-row">
              <span className="summary-label">Office</span>
              <span className="summary-value">Government Citizen Service Centre</span>
            </div>
            <button
              className="btn btn-primary btn-lg btn-block"
              style={{ marginTop: 20 }}
              onClick={() => setShowConfirm(true)}
            >
              Confirm Booking
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={handleConfirm}
        title="Confirm Your Booking"
        confirmText="Confirm Booking"
      >
        <p style={{ marginBottom: 12 }}>Please review your booking details:</p>
        <div className="booking-summary" style={{ background: 'var(--gray-50)', padding: 16, borderRadius: 8 }}>
          <div className="summary-row">
            <span className="summary-label">Service</span>
            <span className="summary-value">{currentService.serviceName}</span>
          </div>
          <div className="summary-row">
            <span className="summary-label">Date</span>
            <span className="summary-value">{formatDateLong(days[selectedDate])}</span>
          </div>
          {selectedSlot !== null && (
            <div className="summary-row">
              <span className="summary-label">Time</span>
              <span className="summary-value">{TIME_SLOTS[selectedSlot].time}</span>
            </div>
          )}
          <div className="summary-row">
            <span className="summary-label">Counter</span>
            <span className="summary-value">Counter {SERVICE_COUNTER_MAP[currentService.serviceId] || 3}</span>
          </div>
          <div className="summary-row">
            <span className="summary-label">Office</span>
            <span className="summary-value">Government Citizen Service Centre</span>
          </div>
        </div>
      </ConfirmationModal>

      {/* Toast notifications */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
};

export default Booking;
