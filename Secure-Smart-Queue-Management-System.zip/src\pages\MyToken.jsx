import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import {
  Radio,
  Users,
  Clock,
  Monitor,
  Zap,
  Printer,
  Smartphone,
  Volume2,
  MapPin,
  AlertCircle,
  FileCheck,
  CheckCircle,
  Sparkles,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import { speakAnnouncement, playCounterChime } from '../utils/audioAnnouncer';

const MyToken = () => {
  const {
    token,
    tokenReminders = {},
    smsInbox = [],
    booking,
    currentServing,
    queuePosition,
    estimatedWait,
    checkedIn,
    applicationStatus,
    sendOfficerReminder,
    addToast,
    language,
  } = useAppContext();

  // Modals state
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [smsModalOpen, setSmsModalOpen] = useState(false);
  const [directionsModalOpen, setDirectionsModalOpen] = useState(false);

  // Dynamic live countdown simulation in seconds
  const [countdownOffset, setCountdownOffset] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdownOffset((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const totalWaitSecs = Math.max(0, (estimatedWait || 15) * 60 - countdownOffset);
  const minutesLeft = Math.floor(totalWaitSecs / 60);
  const secondsLeft = totalWaitSecs % 60;
  const progressPercent = Math.min(100, Math.max(10, 100 - (totalWaitSecs / 1080) * 100));

  if (!token) {
    return (
      <div className="page">
        <Breadcrumb paths={[{ name: 'Home', url: '/' }, { name: 'My Token' }]} />
        <div className="card" style={{ marginTop: '20px' }}>
          <div className="card-body" style={{ textAlign: 'center', padding: '50px 20px' }}>
            <div
              style={{
                width: '72px',
                height: '72px',
                borderRadius: '50%',
                background: 'var(--primary-100)',
                color: 'var(--primary-800)',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1rem',
              }}
            >
              <Clock size={36} />
            </div>
            <h2 style={{ fontSize: '1.4rem', marginBottom: '0.5rem' }}>No Active Token Allocated</h2>
            <p style={{ color: 'var(--gray-500)', marginBottom: '1.5rem', maxWidth: '420px', margin: '0 auto 1.5rem' }}>
              You do not have a booked service token in the queue yet. Select a government service to schedule your appointment and get your digital token.
            </p>
            <Link to="/services" className="btn btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
              <Sparkles size={18} /> Book a Government Service
            </Link>
          </div>
        </div>
      </div>
    );
  }

  let statusText = 'Waiting in Queue';
  if (applicationStatus === 'completed') {
    statusText = 'Service Completed & Issued';
  } else if (checkedIn) {
    statusText = 'Checked-In at Counter';
  } else if (booking) {
    statusText = 'Appointment Booked';
  }

  const tokenReminderInfo = tokenReminders[token?.tokenNumber] || token?.reminders || {};
  const has30MinReminder = tokenReminderInfo.reminder30Min;
  const has15MinReminder = tokenReminderInfo.reminder15Min;

  const handlePlayVoiceAnnouncement = () => {
    playCounterChime();
    const announceMsg = has15MinReminder
      ? `Attention Token ${token.tokenNumber}, your fifteen minute final call for Counter 3 has been issued.`
      : has30MinReminder
      ? `Token ${token.tokenNumber}, your thirty minute arrival reminder for Counter 3 is active.`
      : `Token ${token.tokenNumber}, your current wait is approximately ${minutesLeft} minutes at Counter 3.`;

    speakAnnouncement(announceMsg, language);
    addToast('🔊 Playing Public Address Chime & Announcement Callout', 'info');
  };

  const handleFastForwardReminder = (minutes) => {
    sendOfficerReminder(token.tokenNumber, minutes);
    if (minutes === 30) {
      setCountdownOffset(Math.max(0, (estimatedWait || 15) * 60 - 30 * 60));
    } else {
      setCountdownOffset(Math.max(0, (estimatedWait || 15) * 60 - 15 * 60));
    }
  };

  return (
    <div className="page">
      <Breadcrumb paths={[{ name: 'Home', url: '/' }, { name: 'My Token' }]} />

      {/* Page Title & Action Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <div>
          <h1 className="page-title" style={{ margin: 0 }}>My Digital Token & Live Status</h1>
          <p className="page-subtitle" style={{ margin: '4px 0 0' }}>
            Real-time queue tracking, officer turn reminders, and digital verification slip.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          {/* Audio Chime Button */}
          <button
            type="button"
            className="btn btn-outline"
            onClick={handlePlayVoiceAnnouncement}
            title="Listen to Public Audio Callout"
            style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
          >
            <Volume2 size={16} /> Audio Callout
          </button>

          {/* SMS Simulator Button */}
          <button
            type="button"
            className="btn btn-outline"
            onClick={() => setSmsModalOpen(true)}
            title="View simulated SMS & notifications on citizen mobile"
            style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
          >
            <Smartphone size={16} /> SMS Alerts ({smsInbox.length})
          </button>

          {/* Print Slip Button */}
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setPrintModalOpen(true)}
            title="Print or Download Official Token Slip"
            style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
          >
            <Printer size={16} /> Print Token Slip
          </button>
        </div>
      </div>

      {/* COMPLETED STATUS BANNER */}
      {applicationStatus === 'completed' && (
        <div
          style={{
            background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
            border: '2px solid #22c55e',
            borderRadius: '12px',
            padding: '1.25rem 1.5rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '1rem',
            boxShadow: '0 4px 15px rgba(34, 197, 94, 0.15)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ background: '#22c55e', color: '#fff', padding: '8px', borderRadius: '50%' }}>
              <CheckCircle size={26} />
            </div>
            <div>
              <h4 style={{ margin: 0, color: '#15803d', fontSize: '1.1rem', fontWeight: 800 }}>
                🎉 Service Completed & Official Certificate Issued!
              </h4>
              <p style={{ margin: '4px 0 0', color: '#166534', fontSize: '0.9rem' }}>
                Your {token.service} has been verified and digitally signed by Officer Ms. Priya Sharma.
              </p>
            </div>
          </div>
          <Link to="/my-documents" className="btn btn-success" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <FileCheck size={16} /> View & Download in My Documents
          </Link>
        </div>
      )}

      {/* 15-MINUTE HIGH PRIORITY FINAL CALL ALERT BANNER */}
      {has15MinReminder && applicationStatus !== 'completed' && (
        <div
          style={{
            background: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)',
            border: '2px solid #ef4444',
            borderRadius: '12px',
            padding: '1.25rem 1.5rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1rem',
            boxShadow: '0 4px 18px rgba(239, 68, 68, 0.18)',
            animation: 'pulse 2s infinite',
          }}
        >
          <div style={{ background: '#ef4444', color: '#fff', padding: '10px', borderRadius: '50%', flexShrink: 0 }}>
            <Zap size={26} />
          </div>
          <div style={{ flexGrow: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '4px' }}>
              <h4 style={{ margin: 0, color: '#b91c1c', fontSize: '1.15rem', fontWeight: 800 }}>
                🚨 FINAL CALL: Your Token is Arriving in ~15 Minutes at Counter 3!
              </h4>
              <span style={{ fontSize: '0.78rem', background: '#dc2626', color: '#fff', padding: '3px 10px', borderRadius: '12px', fontWeight: 700 }}>
                Dispatched at {tokenReminderInfo.reminder15MinTime || 'Recent'}
              </span>
            </div>
            <p style={{ margin: '6px 0 0', color: '#991b1b', fontSize: '0.92rem', lineHeight: '1.5' }}>
              Service Officer Ms. Priya Sharma has signaled your <strong>15-Minute Final Call</strong>. Token <strong>{token.tokenNumber}</strong> is immediately next in queue! Please proceed to <strong>Counter 3 (Income Certificate Desk, Ground Floor)</strong> with your original Aadhaar and required photocopies.
            </p>
            <div style={{ marginTop: '0.75rem', display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              <button
                type="button"
                className="btn btn-sm"
                onClick={handlePlayVoiceAnnouncement}
                style={{ background: '#ef4444', color: '#fff', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <Volume2 size={14} /> Replay Audio Callout
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setDirectionsModalOpen(true)}
                style={{ borderColor: '#ef4444', color: '#b91c1c', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <MapPin size={14} /> Counter 3 Directions
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 30-MINUTE TURN REMINDER ALERT BANNER */}
      {has30MinReminder && !has15MinReminder && applicationStatus !== 'completed' && (
        <div
          style={{
            background: 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)',
            border: '2px solid #f59e0b',
            borderRadius: '12px',
            padding: '1.25rem 1.5rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1rem',
            boxShadow: '0 4px 15px rgba(245, 158, 11, 0.14)',
          }}
        >
          <div style={{ background: '#f59e0b', color: '#fff', padding: '10px', borderRadius: '50%', flexShrink: 0 }}>
            <Clock size={26} />
          </div>
          <div style={{ flexGrow: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '4px' }}>
              <h4 style={{ margin: 0, color: '#b45309', fontSize: '1.15rem', fontWeight: 800 }}>
                ⏰ 30-Minute Turn Reminder Received from Officer Priya Sharma
              </h4>
              <span style={{ fontSize: '0.78rem', background: '#d97706', color: '#fff', padding: '3px 10px', borderRadius: '12px', fontWeight: 700 }}>
                Dispatched at {tokenReminderInfo.reminder30MinTime || 'Recent'}
              </span>
            </div>
            <p style={{ margin: '6px 0 0', color: '#92400e', fontSize: '0.92rem', lineHeight: '1.5' }}>
              Officer Ms. Priya Sharma (Counter 3) notified that Token <strong>{token.tokenNumber}</strong> is expected to be called in approximately <strong>30 minutes</strong>. Please ensure you are inside the Tehsildar Complex and taking a seat in the waiting lounge.
            </p>
            <div style={{ marginTop: '0.75rem', display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              <button
                type="button"
                className="btn btn-sm"
                onClick={handlePlayVoiceAnnouncement}
                style={{ background: '#f59e0b', color: '#fff', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <Volume2 size={14} /> Listen to Audio Call
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setDirectionsModalOpen(true)}
                style={{ borderColor: '#f59e0b', color: '#b45309', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <MapPin size={14} /> Directions to Counter 3
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Token Badge Card with Live Progress Ring */}
      <div
        className="card token-card"
        style={{
          marginBottom: '1.5rem',
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
          borderTop: '5px solid #134074',
        }}
      >
        <div className="card-body" style={{ padding: '2rem' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: 700, letterSpacing: '0.08em', color: 'var(--gray-400)' }}>
            DIGITAL CITIZEN SERVICE TOKEN
          </div>
          <div className="token-number" style={{ fontSize: '52px', margin: '8px 0', color: '#134074', fontWeight: 900 }}>
            {token.tokenNumber}
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <span className={`badge ${applicationStatus === 'completed' ? 'badge-success' : 'badge-primary'}`}>
              {statusText}
            </span>
            {has30MinReminder && (
              <span style={{ fontSize: '0.78rem', background: '#fef3c7', color: '#b45309', border: '1px solid #fde68a', padding: '4px 10px', borderRadius: '12px', fontWeight: 700 }}>
                ⏰ 30m Reminder Active
              </span>
            )}
            {has15MinReminder && (
              <span style={{ fontSize: '0.78rem', background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca', padding: '4px 10px', borderRadius: '12px', fontWeight: 700 }}>
                🚨 15m Final Call Active
              </span>
            )}
          </div>

          {/* Live Progress Bar & Countdown Meter */}
          <div style={{ maxWidth: '480px', margin: '0 auto', background: 'var(--gray-50)', padding: '1rem', borderRadius: '0.75rem', border: '1px solid var(--gray-200)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.85rem', marginBottom: '6px' }}>
              <span style={{ fontWeight: 600, color: 'var(--gray-600)' }}>
                {applicationStatus === 'completed' ? 'Service Finished' : 'Estimated Time to Counter Turn:'}
              </span>
              <strong style={{ fontSize: '1rem', color: has15MinReminder ? '#dc2626' : has30MinReminder ? '#d97706' : '#0284c7' }}>
                {applicationStatus === 'completed' ? '✓ Completed' : `${String(minutesLeft).padStart(2, '0')}:${String(secondsLeft).padStart(2, '0')} remaining`}
              </strong>
            </div>

            <div style={{ width: '100%', height: '8px', background: 'var(--gray-200)', borderRadius: '4px', overflow: 'hidden' }}>
              <div
                style={{
                  width: `${progressPercent}%`,
                  height: '100%',
                  background: has15MinReminder ? 'linear-gradient(90deg, #f59e0b, #ef4444)' : 'linear-gradient(90deg, #134074, #0284c7)',
                  transition: 'width 1s ease-in-out',
                }}
              />
            </div>

            {/* Simulation shortcuts for pairing with officer testing */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '10px', flexWrap: 'wrap' }}>
              <button
                type="button"
                onClick={() => handleFastForwardReminder(30)}
                style={{ fontSize: '0.75rem', background: 'none', border: '1px solid var(--gray-300)', borderRadius: '12px', padding: '2px 8px', cursor: 'pointer', color: '#d97706' }}
              >
                Simulate 30m Alert
              </button>
              <button
                type="button"
                onClick={() => handleFastForwardReminder(15)}
                style={{ fontSize: '0.75rem', background: 'none', border: '1px solid var(--gray-300)', borderRadius: '12px', padding: '2px 8px', cursor: 'pointer', color: '#dc2626' }}
              >
                Simulate 15m Call
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Stat Live Metrics Grid */}
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        <div className="card stat-card">
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div className="stat-icon" style={{ color: '#0056b3' }}><Radio size={32} /></div>
            <div className="stat-info">
              <small>Currently Serving</small>
              <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{currentServing || 'A-035'}</div>
            </div>
          </div>
        </div>

        <div className="card stat-card">
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div className="stat-icon" style={{ color: '#fd7e14' }}><Users size={32} /></div>
            <div className="stat-info">
              <small>Citizens Before You</small>
              <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{queuePosition ?? 7}</div>
            </div>
          </div>
        </div>

        <div className="card stat-card">
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div className="stat-icon" style={{ color: '#28a745' }}><Clock size={32} /></div>
            <div className="stat-info">
              <small>Wait Time</small>
              <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{minutesLeft} min</div>
            </div>
          </div>
        </div>

        <div className="card stat-card">
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div className="stat-icon" style={{ color: '#0056b3' }}><Monitor size={32} /></div>
            <div className="stat-info">
              <small>Counter Desk</small>
              <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{token.counterName || 'Counter 3'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Details & QR Code Grid */}
      <div className="grid-2" style={{ gap: '20px', marginBottom: '1.5rem' }}>
        {/* Appointment Card */}
        <div className="card">
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ margin: 0 }}>Appointment Information</h3>
              <span className="badge badge-secondary">ID: {token.tokenId}</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '1.25rem', fontSize: '0.88rem' }}>
              <div>
                <span style={{ color: 'var(--gray-400)', display: 'block', fontSize: '0.78rem' }}>Requested Service</span>
                <strong>{token.service}</strong>
              </div>
              <div>
                <span style={{ color: 'var(--gray-400)', display: 'block', fontSize: '0.78rem' }}>Assigned Officer</span>
                <strong>Ms. Priya Sharma (Tehsildar)</strong>
              </div>
              <div>
                <span style={{ color: 'var(--gray-400)', display: 'block', fontSize: '0.78rem' }}>Appointment Date</span>
                <strong>{token.date}</strong>
              </div>
              <div>
                <span style={{ color: 'var(--gray-400)', display: 'block', fontSize: '0.78rem' }}>Scheduled Time Slot</span>
                <strong>{token.time}</strong>
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <span style={{ color: 'var(--gray-400)', display: 'block', fontSize: '0.78rem' }}>Service Complex Location</span>
                <strong>Tehsildar Administrative Complex, Ground Floor Counter 3, Pune</strong>
              </div>
            </div>

            {checkedIn ? (
              <div className="alert alert-success" style={{ marginBottom: '1.25rem' }}>
                ✓ You are checked in at the office. Please stay attentive for Counter 3 announcements.
              </div>
            ) : (
              <div className="alert alert-info" style={{ marginBottom: '1.25rem' }}>
                Please arrive at the office and complete physical QR check-in at the kiosk.
              </div>
            )}

            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <Link to="/queue" className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Radio size={16} /> Track Live Queue
              </Link>
              {!checkedIn && (
                <Link to="/check-in" className="btn btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  Complete Check-in
                </Link>
              )}
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => setDirectionsModalOpen(true)}
                style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
              >
                <MapPin size={16} /> Location Map
              </button>
            </div>
          </div>
        </div>

        {/* QR Code Card */}
        <div className="card">
          <div className="card-body qr-card" style={{ textAlign: 'center' }}>
            <h3 style={{ margin: '0 0 0.5rem' }}>Official Check-in QR Code</h3>
            <p style={{ margin: '0 0 1rem', fontSize: '0.82rem', color: 'var(--gray-500)' }}>
              Scan at the entry security kiosk or present directly to Officer Priya Sharma.
            </p>

            <div
              style={{
                display: 'inline-block',
                padding: '16px',
                background: '#ffffff',
                borderRadius: '12px',
                border: '2px solid var(--gray-200)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.06)',
                margin: '0 auto 10px',
              }}
            >
              <QRCodeSVG value={token.qrString} size={160} />
            </div>

            <div style={{ fontSize: '0.78rem', color: 'var(--gray-400)', fontFamily: 'monospace' }}>
              HASH: SHA256-SQMS-MH-{token.tokenNumber}-SECURE
            </div>

            <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setPrintModalOpen(true)}
                style={{ display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <Printer size={14} /> Print Slip
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setSmsModalOpen(true)}
                style={{ display: 'flex', alignItems: 'center', gap: '4px' }}
              >
                <Smartphone size={14} /> SMS Verification
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* QUICK ASSISTANCE & SPECIAL REQUESTS DOCK */}
      <div className="card" style={{ padding: '1.25rem 1.5rem', borderRadius: '12px', background: 'var(--gray-50)', border: '1px solid var(--gray-200)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h4 style={{ margin: 0, fontSize: '1rem', color: 'var(--gray-900)' }}>Need Special Assistance or Expedited Service?</h4>
            <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: 'var(--gray-500)' }}>
              Submit an urgent priority request or raise a document spelling correction ticket directly.
            </p>
          </div>
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
            <Link to="/urgent-request" className="btn btn-sm" style={{ background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca', fontWeight: 600 }}>
              ⚡ Tatkal / Urgent Request
            </Link>
            <Link to="/grievance" className="btn btn-sm btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <AlertCircle size={14} /> Raise Detail Correction
            </Link>
          </div>
        </div>
      </div>

      {/* MODAL 1: Printable Official Token Receipt */}
      {printModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.65)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 999,
            padding: '1rem',
          }}
          onClick={() => setPrintModalOpen(false)}
        >
          <div
            style={{
              background: '#ffffff',
              color: '#000000',
              borderRadius: '12px',
              maxWidth: '520px',
              width: '100%',
              padding: '2rem',
              boxShadow: '0 20px 30px rgba(0,0,0,0.3)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Printable Receipt Content */}
            <div style={{ textAlign: 'center', borderBottom: '2px dashed #94a3b8', paddingBottom: '1.25rem', marginBottom: '1.25rem' }}>
              <div style={{ fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#475569' }}>
                GOVERNMENT OF MAHARASHTRA
              </div>
              <h3 style={{ margin: '4px 0', fontSize: '1.2rem', color: '#0f172a' }}>
                Tehsildar Citizen Service Complex
              </h3>
              <p style={{ margin: 0, fontSize: '0.78rem', color: '#64748b' }}>
                District Revenue Office, Pune — 411001 • Smart Queue Management Slip
              </p>
            </div>

            <div style={{ textAlign: 'center', marginBottom: '1.25rem' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase' }}>ALLOCATED TOKEN NUMBER</div>
              <div style={{ fontSize: '44px', fontWeight: 900, color: '#0284c7', margin: '4px 0' }}>
                {token.tokenNumber}
              </div>
              <span style={{ fontSize: '0.8rem', background: '#e0f2fe', color: '#0369a1', padding: '2px 8px', borderRadius: '4px', fontWeight: 700 }}>
                {token.counterName || 'Counter 3'} • {token.service}
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '0.82rem', marginBottom: '1.25rem', background: '#f8fafc', padding: '12px', borderRadius: '8px' }}>
              <div><strong>Citizen:</strong> Rahul Patil</div>
              <div><strong>Aadhaar:</strong> XXXX-XXXX-4242</div>
              <div><strong>Date:</strong> {token.date}</div>
              <div><strong>Time:</strong> {token.time}</div>
              <div><strong>Officer:</strong> Ms. Priya Sharma</div>
              <div><strong>Status:</strong> {statusText}</div>
            </div>

            <div style={{ textAlign: 'center', marginBottom: '1.25rem' }}>
              <QRCodeSVG value={token.qrString} size={130} />
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '4px' }}>
                SQMS-QR-VERIFY • Keep this QR code handy for Counter 3 scanning
              </div>
            </div>

            <div style={{ fontSize: '0.75rem', color: '#64748b', borderTop: '1px solid #e2e8f0', paddingTop: '0.75rem', marginBottom: '1.5rem', lineHeight: '1.4' }}>
              <strong>Notice:</strong> Turn reminders are dispatched via SMS at 30 minutes and 15 minutes before token arrival. Please report to Counter 3 when called.
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setPrintModalOpen(false)}
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => window.print()}
                style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
              >
                <Printer size={16} /> Print Receipt
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Citizen Mobile Phone SMS Simulator */}
      {smsModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.65)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 999,
            padding: '1rem',
          }}
          onClick={() => setSmsModalOpen(false)}
        >
          <div
            style={{
              background: '#0f172a',
              color: '#ffffff',
              borderRadius: '24px',
              maxWidth: '380px',
              width: '100%',
              padding: '1.5rem',
              boxShadow: '0 25px 40px rgba(0,0,0,0.4)',
              border: '4px solid #334155',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Phone Notch */}
            <div style={{ width: '120px', height: '16px', background: '#334155', borderRadius: '8px', margin: '0 auto 1.25rem' }} />

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Smartphone size={18} color="#38bdf8" />
                <div>
                  <div style={{ fontSize: '0.88rem', fontWeight: 700 }}>Messages • GOV-SQMS</div>
                  <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>To: +91 98XXXXXX42 (Rahul Patil)</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSmsModalOpen(false)}
                style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '1rem' }}
              >
                ✕
              </button>
            </div>

            {/* SMS Message Thread */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '360px', overflowY: 'auto', paddingRight: '4px' }}>
              {smsInbox.map((sms) => {
                const isUrgent = sms.type === 'reminder15';
                const is30 = sms.type === 'reminder30';

                return (
                  <div
                    key={sms.id}
                    style={{
                      background: isUrgent ? '#7f1d1d' : is30 ? '#78350f' : '#1e293b',
                      border: `1px solid ${isUrgent ? '#ef4444' : is30 ? '#f59e0b' : '#334155'}`,
                      borderRadius: '12px',
                      padding: '10px 14px',
                      fontSize: '0.82rem',
                      lineHeight: '1.4',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: '#cbd5e1', marginBottom: '4px' }}>
                      <span style={{ fontWeight: 700 }}>{sms.sender}</span>
                      <span>{sms.time}</span>
                    </div>
                    <div>{sms.text}</div>
                  </div>
                );
              })}
            </div>

            <div style={{ marginTop: '1.25rem', textAlign: 'center' }}>
              <button
                type="button"
                className="btn btn-sm btn-primary"
                onClick={() => handleFastForwardReminder(15)}
                style={{ width: '100%', padding: '8px' }}
              >
                ⚡ Trigger Test 15-Min SMS Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Location Map & Counter Directions */}
      {directionsModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.65)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 999,
            padding: '1rem',
          }}
          onClick={() => setDirectionsModalOpen(false)}
        >
          <div
            style={{
              background: 'var(--white)',
              color: 'inherit',
              borderRadius: '12px',
              maxWidth: '500px',
              width: '100%',
              padding: '2rem',
              boxShadow: '0 20px 30px rgba(0,0,0,0.3)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <MapPin size={22} color="#0284c7" /> Counter 3 Location & Directions
              </h3>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setDirectionsModalOpen(false)}
              >
                ✕
              </button>
            </div>

            <div style={{ background: 'var(--gray-50)', padding: '1rem', borderRadius: '8px', marginBottom: '1.25rem', border: '1px solid var(--gray-200)', fontSize: '0.88rem' }}>
              <div><strong>Complex:</strong> Tehsildar & Sub-Divisional Complex</div>
              <div><strong>Building:</strong> Administrative Wing B</div>
              <div><strong>Floor:</strong> Ground Floor</div>
              <div><strong>Desk:</strong> Counter 3 — Income Certificate & Revenue Services</div>
              <div><strong>Officer in-charge:</strong> Ms. Priya Sharma (Senior Tehsildar)</div>
            </div>

            <h4 style={{ margin: '0 0 0.5rem', fontSize: '0.95rem' }}>Step-by-Step Walking Directions:</h4>
            <ol style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.85rem', color: 'var(--gray-600)', lineHeight: '1.6' }}>
              <li>Enter through Main Gate 1 (Opposite Pune District Court).</li>
              <li>Complete security QR scanning at the Entry Kiosk.</li>
              <li>Proceed straight past the Main Fountain to Building B entrance.</li>
              <li>Enter the Ground Floor Service Hall; Counter 3 is located directly on your left.</li>
              <li>Wait in the Counter 3 seating lounge until your 15-minute call is announced.</li>
            </ol>

            <div style={{ marginTop: '1.5rem', textAlign: 'right' }}>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setDirectionsModalOpen(false)}
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyToken;
