// Secure Smart Queue Management System — Document Upload, Storage & Verification
// Validates file size, MIME types, magic bytes, prevents directory traversal, and enforces RBAC.

import { Router } from 'express';
import { fileURLToPath } from 'node:url';
import { dirname, join, extname } from 'node:path';
import { existsSync, mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import crypto from 'node:crypto';
import { getDb } from '../db.js';
import { requireRole } from '../middleware/auth.js';
import { logAuditEvent } from '../utils/auditLogger.js';

const router = Router();
const __dirname = dirname(fileURLToPath(import.meta.url));
const UPLOAD_DIR = join(__dirname, '..', 'uploads', 'documents');

if (!existsSync(UPLOAD_DIR)) {
  mkdirSync(UPLOAD_DIR, { recursive: true });
}

const ALLOWED_MIMES = new Set(['application/pdf', 'image/jpeg', 'image/png']);
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

// Helper: inspect magic bytes
function validateMagicBytes(buffer, mimeType) {
  if (buffer.length < 4) return false;

  if (mimeType === 'application/pdf') {
    // Starts with %PDF (0x25 0x50 0x44 0x46)
    return buffer[0] === 0x25 && buffer[1] === 0x50 && buffer[2] === 0x44 && buffer[3] === 0x46;
  }
  if (mimeType === 'image/jpeg') {
    // Starts with 0xFF 0xD8 0xFF
    return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mimeType === 'image/png') {
    // Starts with 0x89 0x50 0x4E 0x47
    return buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;
  }
  return false;
}

// GET /api/documents — List current citizen's documents
router.get('/', (req, res) => {
  const db = getDb();
  const docs = db.prepare(`
    SELECT id, application_id, citizen_id, doc_name, original_name, file_size, mime_type,
           verification_status, rejection_reason, uploaded_at, verified_at
    FROM documents
    WHERE citizen_id = ?
    ORDER BY uploaded_at DESC
  `).all(req.user.id);
  res.json(docs);
});

// POST /api/documents/upload — Upload document (Base64 payload)
router.post('/upload', (req, res) => {
  const docName = req.body?.docName || req.body?.doc_type;
  const fileName = req.body?.fileName || req.body?.file_name;
  const rawBase64 = req.body?.fileBase64 || req.body?.file_data_base64;
  const mimeType = req.body?.mimeType || req.body?.mime_type;
  const applicationId = req.body?.applicationId || req.body?.application_id;

  if (!docName || !rawBase64 || !mimeType) {
    return res.status(400).json({ error: 'docName, fileBase64, and mimeType are required' });
  }

  const cleanBase64 = rawBase64.includes(',') ? rawBase64.split(',')[1] : rawBase64;

  if (!ALLOWED_MIMES.has(mimeType)) {
    return res.status(400).json({
      error: `File type not supported. Allowed formats: PDF, JPEG, PNG. Received: ${mimeType}`,
    });
  }

  let fileBuffer;
  try {
    fileBuffer = Buffer.from(cleanBase64, 'base64');
  } catch {
    return res.status(400).json({ error: 'Invalid base64 payload' });
  }

  if (fileBuffer.length > MAX_FILE_SIZE) {
    return res.status(400).json({ error: 'File size exceeds 5MB limit' });
  }

  // Deep validation: magic bytes check
  if (!validateMagicBytes(fileBuffer, mimeType)) {
    logAuditEvent({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: 'MALICIOUS_FILE_UPLOAD_BLOCKED',
      resourceType: 'document',
      resourceId: fileName || docName,
      details: `File failed magic byte signature check for declared mime: ${mimeType}`,
      ipAddress: req.ip || '127.0.0.1',
      status: 'BLOCKED',
    });

    return res.status(400).json({
      error: 'File content verification failed: binary headers do not match declared file type',
    });
  }

  // Prevent path traversal: generate random UUID storage name
  const rawExt = extname(fileName || '').toLowerCase();
  const safeExt = rawExt && ['.pdf', '.jpg', '.jpeg', '.png'].includes(rawExt)
    ? rawExt
    : mimeType === 'application/pdf' ? '.pdf' : mimeType === 'image/png' ? '.png' : '.jpg';

  const storedFilename = `doc_${Date.now()}_${crypto.randomBytes(8).toString('hex')}${safeExt}`;
  const filePath = join(UPLOAD_DIR, storedFilename);

  try {
    writeFileSync(filePath, fileBuffer);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to write file to storage: ' + err.message });
  }

  const docId = `DOC-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  const db = getDb();

  db.prepare(`
    INSERT INTO documents (
      id, application_id, citizen_id, doc_name, original_name, stored_filename,
      file_path, file_size, mime_type, verification_status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
  `).run(
    docId,
    applicationId || null,
    req.user.id,
    docName.trim(),
    fileName ? fileName.trim() : docName.trim(),
    storedFilename,
    filePath,
    fileBuffer.length,
    mimeType
  );

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'DOCUMENT_UPLOADED',
    resourceType: 'document',
    resourceId: docId,
    details: `Uploaded ${docName} (${fileBuffer.length} bytes)`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  const created = db.prepare(`
    SELECT id, doc_name, original_name, file_size, mime_type, verification_status, uploaded_at
    FROM documents WHERE id = ?
  `).get(docId);

  res.status(201).json({ success: true, document: created });
});

// GET /api/documents/:id/download — Authorized file download
router.get('/:id/download', (req, res) => {
  const db = getDb();
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Document not found' });

  // Access Control: Citizen must own the document or user must be officer/admin
  if (req.user.role === 'citizen' && doc.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Access denied: You do not have permission to view this document' });
  }

  if (!existsSync(doc.file_path)) {
    return res.status(404).json({ error: 'File not found on secure storage volume' });
  }

  const fileData = readFileSync(doc.file_path);
  res.setHeader('Content-Type', doc.mime_type);
  res.setHeader('Content-Disposition', `inline; filename="${doc.original_name}"`);
  res.send(fileData);
});

// PATCH /api/documents/:id/verify — Officer document verification decision
router.patch('/:id/verify', requireRole('officer', 'admin'), (req, res) => {
  const { status, reason } = req.body || {};
  if (!status || !['verified', 'rejected', 'correction_needed'].includes(status)) {
    return res.status(400).json({ error: 'Status must be verified, rejected, or correction_needed' });
  }

  const db = getDb();
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Document not found' });

  const nowIso = new Date().toISOString();

  db.prepare(`
    UPDATE documents SET
      verification_status = ?,
      rejection_reason = ?,
      verified_by = ?,
      verified_at = ?
    WHERE id = ?
  `).run(status, reason || null, req.user.id, nowIso, doc.id);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'DOCUMENT_VERIFIED',
    resourceType: 'document',
    resourceId: doc.id,
    details: `Officer marked document ${doc.doc_name} as ${status}. Reason: ${reason || 'N/A'}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Document marked as ${status}` });
});

export default router;