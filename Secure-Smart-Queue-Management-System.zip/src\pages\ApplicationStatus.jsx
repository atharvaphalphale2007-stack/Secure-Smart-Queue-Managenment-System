import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Circle, ArrowRight, Clock } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import { useAppContext } from '../context/AppContext';

const ApplicationStatus = () => {
  const { applicationStatus, token, citizen, booking, advanceApplication } = useAppContext();

  const statusOrder = ['none', 'received', 'verified', 'processing', 'approved', 'completed'];
  const currentIndex = statusOrder.indexOf(applicationStatus);

  const steps = [
    { label: 'Application Received', status: 'received', date: '25 Sep 2026' },
    { label: 'Document Verified', status: 'verified', date: '25 Sep 2026' },
    { label: 'Processing', status: 'processing', date: 'In Progress' },
    { label: 'Approved', status: 'approved', date: 'Pending' },
    { label: 'Completed', status: 'completed', date: 'Pending' }
  ];

  return (
    <div className="page-container">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Application Status' }
        ]}
      />

      <div className="section">
        <h1 className="page-title">Application Status</h1>
        
        <div className="card" style={{ marginBottom: '2rem' }}>
          <div className="card-body">
            <div className="grid-4">
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Application ID</p>
                <p style={{ fontWeight: 500 }}>APP-2026-0925-0042</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Service</p>
                <p style={{ fontWeight: 500 }}>{token?.service || 'Income Certificate'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Citizen</p>
                <p style={{ fontWeight: 500 }}>{citizen?.name || 'Rahul Patil'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Date</p>
                <p style={{ fontWeight: 500 }}>{booking?.date || '25 Sep 2026'}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid-2" style={{ gap: '2rem', marginBottom: '2rem' }}>
          <div className="card">
            <div className="card-header">
              <h2>Processing Timeline</h2>
            </div>
            <div className="card-body">
              <div className="timeline" style={{ position: 'relative', paddingLeft: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div style={{ position: 'absolute', left: '0.9rem', top: '1rem', bottom: '1rem', width: '2px', backgroundColor: '#e2e8f0' }}></div>
                
                {steps.map((step) => {
                  const stepIndex = statusOrder.indexOf(step.status);
                  let state = 'pending';
                  if (stepIndex <= currentIndex) state = 'completed';
                  else if (stepIndex === currentIndex + 1 && currentIndex > 0) state = 'active';
                  
                  if (step.status === applicationStatus && applicationStatus === 'processing') state = 'active';
                  
                  return (
                    <div key={step.status} className="timeline-step" style={{ position: 'relative' }}>
                      <div className={`timeline-marker ${state}`} style={{ position: 'absolute', left: '-2.5rem', backgroundColor: '#fff', borderRadius: '50%' }}>
                        {state === 'completed' ? <CheckCircle color="#22c55e" size={24} /> : (state === 'active' ? <Clock color="#2563eb" size={24} /> : <Circle color="#cbd5e1" size={24} />)}
                      </div>
                      <div className="timeline-content">
                        <h4 style={{ margin: 0, color: state === 'pending' ? '#94a3b8' : '#1e293b' }}>{step.label}</h4>
                        <p style={{ margin: 0, fontSize: '0.875rem', color: '#64748b' }}>
                          {state === 'active' ? 'In Progress' : (state === 'completed' ? step.date : 'Pending')}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="alert alert-info">
              Estimated completion: Within 3-5 working days from the date of application.
            </div>

            <div className="card">
              <div className="card-body">
                <h3 style={{ marginBottom: '1rem' }}>Demo: Advance Application Status</h3>
                <div className="alert alert-info" style={{ marginBottom: '1rem', backgroundColor: '#f8fafc', borderColor: '#e2e8f0', color: '#475569' }}>
                  Click below to simulate application progress for demonstration.
                </div>
                
                {applicationStatus === 'completed' ? (
                  <>
                    <div className="alert alert-success" style={{ marginBottom: '1rem' }}>
                      Application has been completed! View your certificate in My Documents.
                    </div>
                    <Link to="/my-documents" className="btn btn-primary" style={{ display: 'flex', justifyContent: 'center' }}>
                      View My Documents
                    </Link>
                  </>
                ) : (
                  <button 
                    className="btn btn-primary" 
                    onClick={advanceApplication}
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', width: '100%', justifyContent: 'center' }}
                  >
                    Advance to Next Stage <ArrowRight size={18} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationStatus;
