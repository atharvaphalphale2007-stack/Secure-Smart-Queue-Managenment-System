import React, { useState } from 'react';
import {
  LayoutDashboard, Radio, Calendar, Monitor, ClipboardList,
  FileText, Zap, AlertTriangle, BarChart3,
  Users, CheckCircle, ShieldCheck, Server, Search
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts';
import StatusBadge from '../components/StatusBadge';
import {
  ADMIN_STATS, DAILY_BOOKINGS, SERVICE_DISTRIBUTION,
  COUNTERS, RECENT_APPLICATIONS, SERVICES, TIME_SLOTS
} from '../data/mockData';
import { useAppContext } from '../context/AppContext';

const AdminDashboard = () => {
  const { user, grievance, urgentRequest, handleOfficerGrievanceAction, handleOfficerUrgentAction } = useAppContext();
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [searchCitizen, setSearchCitizen] = useState('');
  const [adminStats, setAdminStats] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [securityAlerts, setSecurityAlerts] = useState([]);
  const [auditVerification, setAuditVerification] = useState(null);
  const [isVerifying, setIsVerifying] = useState(false);

  React.useEffect(() => {
    import('../utils/api').then(({ api }) => {
      api.getAdminStats().then(setAdminStats).catch(() => {});
      api.getAuditLogs({ limit: 20 }).then((res) => setAuditLogs(res?.logs || [])).catch(() => {});
      api.getSecurityAlerts().then(setSecurityAlerts).catch(() => {});
    });
  }, []);

  const handleVerifyAuditChain = async () => {
    setIsVerifying(true);
    try {
      const { api } = await import('../utils/api');
      const res = await api.verifyAuditTrail();
      setAuditVerification(res);
    } catch {
      setAuditVerification({ valid: false, error: 'Verification error' });
    } finally {
      setIsVerifying(false);
    }
  };

  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard },
    { name: 'Audit Logs & Security', icon: ShieldCheck },
    { name: 'Manage Citizens', icon: Users },
    { name: 'Manage Officers', icon: ShieldCheck },
    { name: 'Government Services', icon: FileText },
    { name: 'Manage Slots', icon: Calendar },
    { name: 'Live Queues', icon: Radio },
    { name: 'Manage Counters', icon: Monitor },
    { name: 'Applications', icon: ClipboardList },
    { name: 'Urgent Requests', icon: Zap },
    { name: 'Grievances', icon: AlertTriangle },
    { name: 'Reports & Stats', icon: BarChart3 },
    { name: 'System Health', icon: Server },
  ];

  return (
    <div style={{ maxWidth: '1280px', margin: '1.5rem auto', padding: '0 1rem' }}>
      {/* Admin Header Banner */}
      <div
        style={{
          background: 'linear-gradient(135deg, #7c3aed 0%, #4c1d95 100%)',
          color: 'white',
          borderRadius: '0.75rem',
          padding: '1.5rem 2rem',
          marginBottom: '2rem',
          boxShadow: '0 4px 15px rgba(124, 58, 237, 0.25)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div>
          <div style={{ fontSize: '0.82rem', textTransform: 'uppercase', letterSpacing: '0.05em', opacity: 0.9 }}>
            Directorate of Information Technology & Public Administration
          </div>
          <h1 style={{ margin: '0.25rem 0 0', fontSize: '1.6rem', color: '#ffffff' }}>
            System Administrator Control Center
          </h1>
          <p style={{ margin: '4px 0 0', fontSize: '0.9rem', opacity: 0.95 }}>
            Logged in as: {user?.name || 'System Administrator'} ({user?.email || 'admin.sqms@gov.in'})
          </p>
        </div>
        <span className="badge" style={{ background: 'rgba(255,255,255,0.2)', color: '#ffffff', padding: '0.5rem 1rem', fontSize: '0.85rem' }}>
          🟢 System Status: ALL SYSTEMS OPERATIONAL
        </span>
      </div>

      <div className="admin-layout" style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
        {/* Sidebar */}
        <div className="admin-sidebar" style={{ width: '250px', flexShrink: 0, backgroundColor: '#fff', borderRadius: '0.75rem', padding: '1rem', border: '1px solid #e2e8f0', height: 'fit-content' }}>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {navItems.map((item) => (
              <li key={item.name} style={{ marginBottom: '0.4rem' }}>
                <button
                  className={`btn btn-block ${activeTab === item.name ? 'btn-primary' : 'btn-outline'}`}
                  style={{
                    textAlign: 'left',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    justifyContent: 'flex-start',
                    border: activeTab === item.name ? undefined : 'none',
                    color: activeTab === item.name ? undefined : '#475569',
                    backgroundColor: activeTab === item.name ? '#7c3aed' : undefined,
                    borderColor: activeTab === item.name ? '#7c3aed' : undefined,
                  }}
                  onClick={() => setActiveTab(item.name)}
                >
                  <item.icon size={18} />
                  {item.name}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Main Workspace Area */}
        <div className="admin-main" style={{ flexGrow: 1, minWidth: '0' }}>
          {/* TAB: DASHBOARD */}
          {activeTab === 'Dashboard' && (
            <div>
              <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
                <div className="card stat-card">
                  <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="stat-icon" style={{ backgroundColor: '#f3e8ff', color: '#7c3aed', padding: '1rem', borderRadius: '50%' }}><Calendar size={24}/></div>
                    <div className="stat-info">
                      <p style={{ margin: '0 0 0.25rem', color: '#64748b', fontSize: '0.85rem' }}>Total Bookings</p>
                      <h3 style={{ margin: 0, fontSize: '1.5rem' }}>{adminStats?.totalBookings ?? ADMIN_STATS.totalBookings}</h3>
                    </div>
                  </div>
                </div>
                <div className="card stat-card">
                  <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="stat-icon" style={{ backgroundColor: '#ffedd5', color: '#ea580c', padding: '1rem', borderRadius: '50%' }}><Users size={24}/></div>
                    <div className="stat-info">
                      <p style={{ margin: '0 0 0.25rem', color: '#64748b', fontSize: '0.85rem' }}>Active Queue</p>
                      <h3 style={{ margin: 0, fontSize: '1.5rem' }}>{adminStats?.activeQueue ?? ADMIN_STATS.activeQueue}</h3>
                    </div>
                  </div>
                </div>
                <div className="card stat-card">
                  <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="stat-icon" style={{ backgroundColor: '#dcfce7', color: '#16a34a', padding: '1rem', borderRadius: '50%' }}><Monitor size={24}/></div>
                    <div className="stat-info">
                      <p style={{ margin: '0 0 0.25rem', color: '#64748b', fontSize: '0.85rem' }}>Available Counters</p>
                      <h3 style={{ margin: 0, fontSize: '1.5rem' }}>{ADMIN_STATS.availableCounters}</h3>
                    </div>
                  </div>
                </div>
                <div className="card stat-card">
                  <div className="card-body" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="stat-icon" style={{ backgroundColor: '#dcfce7', color: '#16a34a', padding: '1rem', borderRadius: '50%' }}><CheckCircle size={24}/></div>
                    <div className="stat-info">
                      <p style={{ margin: '0 0 0.25rem', color: '#64748b', fontSize: '0.85rem' }}>Completed Services</p>
                      <h3 style={{ margin: 0, fontSize: '1.5rem' }}>{adminStats?.completedServices ?? ADMIN_STATS.completedServices}</h3>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid-2" style={{ marginBottom: '2rem' }}>
                <div className="card">
                  <div className="card-header"><h3>Daily Citizen Footfall</h3></div>
                  <div className="card-body">
                    <ResponsiveContainer width="100%" height={230}>
                      <BarChart data={DAILY_BOOKINGS}>
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip cursor={{ fill: '#f1f5f9' }} />
                        <Bar dataKey="bookings" fill="#7c3aed" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header"><h3>Service Distribution</h3></div>
                  <div className="card-body">
                    <ResponsiveContainer width="100%" height={230}>
                      <PieChart>
                        <Pie data={SERVICE_DISTRIBUTION} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                          {SERVICE_DISTRIBUTION.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: MANAGE CITIZENS */}
          {activeTab === 'Manage Citizens' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0 }}>Registered Citizens Directory</h3>
                <div style={{ position: 'relative', width: '240px' }}>
                  <Search size={16} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
                  <input
                    type="text"
                    placeholder="Search citizens..."
                    value={searchCitizen}
                    onChange={(e) => setSearchCitizen(e.target.value)}
                    style={{ padding: '0.4rem 0.4rem 0.4rem 2.2rem', width: '100%', borderRadius: '0.4rem', border: '1px solid #cbd5e1', fontSize: '0.85rem' }}
                  />
                </div>
              </div>
              <div className="table-wrapper">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Citizen Name</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Aadhaar No.</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Mobile</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Email</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Rahul Patil</td>
                      <td style={{ padding: '0.75rem 1rem' }}>XXXX-XXXX-4242</td>
                      <td style={{ padding: '0.75rem 1rem' }}>98XXXXXX42</td>
                      <td style={{ padding: '0.75rem 1rem' }}>rahul.patil@example.com</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">Verified Active</span></td>
                    </tr>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Sneha Jadhav</td>
                      <td style={{ padding: '0.75rem 1rem' }}>XXXX-XXXX-8812</td>
                      <td style={{ padding: '0.75rem 1rem' }}>98XXXXXX12</td>
                      <td style={{ padding: '0.75rem 1rem' }}>sneha.j@example.com</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">Verified Active</span></td>
                    </tr>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Amit Kumar</td>
                      <td style={{ padding: '0.75rem 1rem' }}>XXXX-XXXX-3341</td>
                      <td style={{ padding: '0.75rem 1rem' }}>97XXXXXX55</td>
                      <td style={{ padding: '0.75rem 1rem' }}>amit.k@example.com</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">Verified Active</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: MANAGE OFFICERS */}
          {activeTab === 'Manage Officers' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0 }}>Service Officers & Duty Roster</h3>
                <button className="btn btn-sm btn-primary" style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed' }}>+ Add Officer</button>
              </div>
              <div className="table-wrapper">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Officer Name</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Designation</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Assigned Counter</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Service Category</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Ms. Priya Sharma</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Senior Tehsildar</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Counter 3</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Income Certificate</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">On Duty</span></td>
                    </tr>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Rahul Deshmukh</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Verification Officer</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Counter 4</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Caste Certificate</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-warning">Busy</span></td>
                    </tr>
                    <tr>
                      <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Amit Joshi</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Assistant Officer</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Counter 1</td>
                      <td style={{ padding: '0.75rem 1rem' }}>Birth Certificate</td>
                      <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">On Duty</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: GOVERNMENT SERVICES */}
          {activeTab === 'Government Services' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0 }}>Government Services Catalog Management</h3>
                <button className="btn btn-sm btn-primary" style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed' }}>+ Create Service</button>
              </div>
              <div className="table-wrapper">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Service Title</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Processing Time</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Fee</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {SERVICES.map((s) => (
                      <tr key={s.id}>
                        <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>{s.name}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{s.processingTime}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{s.fee}</td>
                        <td style={{ padding: '0.75rem 1rem' }}><span className="badge badge-success">Active</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: MANAGE SLOTS */}
          {activeTab === 'Manage Slots' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Time Slots & Daily Slot Capacity</h3>
              </div>
              <div className="card-body">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                  {TIME_SLOTS.map((slot, idx) => (
                    <div key={idx} style={{ padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', background: '#f8fafc' }}>
                      <div style={{ fontWeight: 700, color: '#0f172a' }}>{slot.time}</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '4px' }}>Capacity: 15 / 15 slots</div>
                      <div style={{ marginTop: '8px' }}><span className="badge badge-success">Open</span></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: LIVE QUEUES */}
          {activeTab === 'Live Queues' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Real-Time Counter Queue Monitor</h3>
              </div>
              <div className="card-body">
                <div className="grid-3">
                  {COUNTERS.map((c) => (
                    <div key={c.id} style={{ border: '1px solid #e2e8f0', borderRadius: '0.5rem', padding: '1.25rem', background: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                        <h4 style={{ margin: 0 }}>{c.name}</h4>
                        <StatusBadge status={c.status} />
                      </div>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Service: {c.service}</div>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Officer: {c.officer}</div>
                      <div style={{ marginTop: '1rem', background: '#f1f5f9', padding: '0.75rem', borderRadius: '0.4rem', textAlign: 'center' }}>
                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Serving Token</div>
                        <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#7c3aed' }}>{c.currentToken || '—'}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: MANAGE COUNTERS */}
          {activeTab === 'Manage Counters' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0 }}>Counter Allocation & Control</h3>
                <button className="btn btn-sm btn-primary" style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed' }}>+ Open New Counter</button>
              </div>
              <div className="table-wrapper">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Counter</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Assigned Service</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Assigned Officer</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Current Token</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {COUNTERS.map((counter, idx) => (
                      <tr key={idx}>
                        <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>{counter.name}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{counter.service}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{counter.officer}</td>
                        <td style={{ padding: '0.75rem 1rem', fontWeight: 'bold', color: '#7c3aed' }}>{counter.currentToken || '—'}</td>
                        <td style={{ padding: '0.75rem 1rem' }}><StatusBadge status={counter.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: APPLICATIONS */}
          {activeTab === 'Applications' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Global Citizen Applications Audit Log</h3>
              </div>
              <div className="table-wrapper">
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Application ID</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Citizen Name</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Service</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Date</th>
                      <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {RECENT_APPLICATIONS.map((app, idx) => (
                      <tr key={idx}>
                        <td style={{ padding: '0.75rem 1rem' }}>{app.id}</td>
                        <td style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>{app.citizen}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{app.service}</td>
                        <td style={{ padding: '0.75rem 1rem' }}>{app.date}</td>
                        <td style={{ padding: '0.75rem 1rem' }}><StatusBadge status={app.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: URGENT REQUESTS */}
          {activeTab === 'Urgent Requests' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Urgent & Standby Emergency Requests Control</h3>
              </div>
              <div className="card-body">
                {urgentRequest ? (
                  <div style={{ border: '1px solid #e2e8f0', padding: '1.25rem', borderRadius: '0.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                      <span className="badge badge-danger">Urgent Priority</span>
                      <span className="badge badge-secondary">{urgentRequest.status}</span>
                    </div>
                    <h4>{urgentRequest.urgencyType || 'Medical Emergency'}</h4>
                    <p style={{ color: '#64748b', fontSize: '0.9rem' }}>{urgentRequest.reason || 'Urgent medical document submission needed.'}</p>
                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                      <button className="btn btn-sm btn-success" onClick={() => handleOfficerUrgentAction('approved')}>✓ Grant Priority</button>
                      <button className="btn btn-sm btn-danger" onClick={() => handleOfficerUrgentAction('rejected')}>✕ Reject</button>
                    </div>
                  </div>
                ) : (
                  <p style={{ color: '#64748b', margin: 0, textAlign: 'center', padding: '2rem' }}>No pending urgent requests.</p>
                )}
              </div>
            </div>
          )}

          {/* TAB: GRIEVANCES */}
          {activeTab === 'Grievances' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Grievance & Correction Request Portal</h3>
              </div>
              <div className="card-body">
                {grievance ? (
                  <div style={{ border: '1px solid #e2e8f0', padding: '1.25rem', borderRadius: '0.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                      <span className="badge badge-warning">Ticket #{grievance.id || 'GRV-2026-0042'}</span>
                      <span className="badge badge-secondary">{grievance.status}</span>
                    </div>
                    <h4>{grievance.errorType || 'Spelling Error Correction'}</h4>
                    <p style={{ color: '#64748b', fontSize: '0.9rem' }}>{grievance.correctInfo || 'Correct spelling to Rahul Patil'}</p>
                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                      <button className="btn btn-sm btn-success" onClick={() => handleOfficerGrievanceAction('resolved')}>✓ Mark Resolved</button>
                      <button className="btn btn-sm btn-danger" onClick={() => handleOfficerGrievanceAction('rejected')}>✕ Reject</button>
                    </div>
                  </div>
                ) : (
                  <p style={{ color: '#64748b', margin: 0, textAlign: 'center', padding: '2rem' }}>No open grievances.</p>
                )}
              </div>
            </div>
          )}

          {/* TAB: REPORTS & STATS */}
          {activeTab === 'Reports & Stats' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Performance Reports & Queue Analytics</h3>
              </div>
              <div className="card-body">
                <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
                  <div style={{ padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}>
                    <h4>Average Citizen Wait Time</h4>
                    <div style={{ fontSize: '2rem', fontWeight: 800, color: '#16a34a' }}>14.2 min</div>
                    <p style={{ color: '#64748b', fontSize: '0.8rem', margin: 0 }}>Reduced by 32% with Smart Token QR System</p>
                  </div>
                  <div style={{ padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}>
                    <h4>Service Completion Rate</h4>
                    <div style={{ fontSize: '2rem', fontWeight: 800, color: '#7c3aed' }}>96.8%</div>
                    <p style={{ color: '#64748b', fontSize: '0.8rem', margin: 0 }}>186 of 192 tokens completed today</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: SYSTEM HEALTH */}
          {activeTab === 'System Health' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>System Infrastructure & Scanner Diagnostics</h3>
              </div>
              <div className="card-body">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
                  <div style={{ background: '#dcfce7', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #86efac' }}>
                    <div style={{ fontWeight: 700, color: '#16a34a' }}>QR Verification Server</div>
                    <div style={{ fontSize: '0.85rem', color: '#14532d' }}>Status: Operational (HMAC-SHA256)</div>
                  </div>
                  <div style={{ background: '#dcfce7', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #86efac' }}>
                    <div style={{ fontWeight: 700, color: '#16a34a' }}>Database Engine</div>
                    <div style={{ fontSize: '0.85rem', color: '#14532d' }}>Status: Persistent SQLite (WAL Mode)</div>
                  </div>
                  <div style={{ background: '#dcfce7', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #86efac' }}>
                    <div style={{ fontWeight: 700, color: '#16a34a' }}>Audit Hash Chain</div>
                    <div style={{ fontSize: '0.85rem', color: '#14532d' }}>Status: Chained Cryptographic Ledger</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: AUDIT LOGS & SECURITY */}
          {activeTab === 'Audit Logs & Security' && (
            <div>
              {/* Audit Verification Card */}
              <div className="card" style={{ marginBottom: '1.5rem', borderLeft: '4px solid #7c3aed' }}>
                <div className="card-body" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                  <div>
                    <h3 style={{ margin: 0, fontSize: '1.15rem' }}>Cryptographic Tamper-Evident Audit Ledger</h3>
                    <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '0.85rem' }}>
                      Every authentication, booking, queue movement, and document decision is linked in a SHA-256 hash chain.
                    </p>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={handleVerifyAuditChain}
                    disabled={isVerifying}
                    style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed' }}
                  >
                    {isVerifying ? 'Verifying Hashes...' : 'Verify Audit Chain Integrity'}
                  </button>
                </div>

                {auditVerification && (
                  <div style={{ padding: '0 1.5rem 1.5rem 1.5rem' }}>
                    <div
                      style={{
                        padding: '1rem',
                        borderRadius: '0.5rem',
                        backgroundColor: auditVerification.valid ? '#f0fdf4' : '#fef2f2',
                        border: `1px solid ${auditVerification.valid ? '#bbf7d0' : '#fecaca'}`,
                        fontSize: '0.88rem',
                      }}
                    >
                      <div style={{ fontWeight: 700, color: auditVerification.valid ? '#166534' : '#991b1b', marginBottom: '4px' }}>
                        {auditVerification.valid ? '✓ HASH CHAIN VERIFIED — ZERO TAMPERING DETECTED' : '✕ AUDIT INTEGRITY FAILURE'}
                      </div>
                      <div>Total Records Verified: <strong>{auditVerification.totalChecked}</strong></div>
                      {auditVerification.latestHash && (
                        <div style={{ wordBreak: 'break-all', fontSize: '0.78rem', color: '#475569', marginTop: '4px' }}>
                          Current Chain Tip Hash: <code>{auditVerification.latestHash}</code>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Security Alerts Card */}
              {securityAlerts.length > 0 && (
                <div className="card" style={{ marginBottom: '1.5rem', borderColor: '#fca5a5' }}>
                  <div className="card-header" style={{ backgroundColor: '#fef2f2' }}>
                    <h3 style={{ margin: 0, color: '#991b1b', fontSize: '1.05rem' }}>Active Cybersecurity & Fraud Alerts</h3>
                  </div>
                  <div className="card-body" style={{ padding: 0 }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                      <thead>
                        <tr style={{ backgroundColor: '#fff1f2' }}>
                          <th style={{ padding: '0.6rem 1rem', textAlign: 'left' }}>Time</th>
                          <th style={{ padding: '0.6rem 1rem', textAlign: 'left' }}>Alert Type</th>
                          <th style={{ padding: '0.6rem 1rem', textAlign: 'left' }}>Severity</th>
                          <th style={{ padding: '0.6rem 1rem', textAlign: 'left' }}>Details</th>
                          <th style={{ padding: '0.6rem 1rem', textAlign: 'left' }}>IP Address</th>
                        </tr>
                      </thead>
                      <tbody>
                        {securityAlerts.map((alt) => (
                          <tr key={alt.id} style={{ borderBottom: '1px solid #fee2e2' }}>
                            <td style={{ padding: '0.6rem 1rem' }}>{new Date(alt.timestamp).toLocaleTimeString()}</td>
                            <td style={{ padding: '0.6rem 1rem', fontWeight: 600 }}>{alt.alert_type}</td>
                            <td style={{ padding: '0.6rem 1rem' }}>
                              <span style={{ color: alt.severity === 'high' ? '#dc2626' : '#d97706', fontWeight: 700 }}>
                                {alt.severity.toUpperCase()}
                              </span>
                            </td>
                            <td style={{ padding: '0.6rem 1rem' }}>{alt.details}</td>
                            <td style={{ padding: '0.6rem 1rem' }}><code>{alt.ip_address}</code></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Audit Logs Table */}
              <div className="card">
                <div className="card-header">
                  <h3 style={{ margin: 0 }}>Recent Immutable Audit Trail Records</h3>
                </div>
                <div className="card-body" style={{ padding: 0, overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#f8fafc' }}>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Timestamp</th>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Actor</th>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Action</th>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Resource</th>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Details</th>
                        <th style={{ padding: '0.75rem 1rem', textAlign: 'left' }}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {auditLogs.length > 0 ? (
                        auditLogs.map((log) => (
                          <tr key={log.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '0.65rem 1rem', whiteSpace: 'nowrap' }}>
                              {new Date(log.timestamp).toLocaleTimeString('en-IN')}
                            </td>
                            <td style={{ padding: '0.65rem 1rem', fontWeight: 600 }}>
                              {log.actor_id} ({log.actor_role})
                            </td>
                            <td style={{ padding: '0.65rem 1rem' }}>
                              <code style={{ fontSize: '0.8rem', background: '#f1f5f9', padding: '2px 6px', borderRadius: '4px' }}>
                                {log.action}
                              </code>
                            </td>
                            <td style={{ padding: '0.65rem 1rem' }}>{log.resource_type} {log.resource_id ? `#${log.resource_id}` : ''}</td>
                            <td style={{ padding: '0.65rem 1rem', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {log.details}
                            </td>
                            <td style={{ padding: '0.65rem 1rem' }}>
                              <span style={{ color: log.status === 'SUCCESS' ? '#16a34a' : '#dc2626', fontWeight: 600 }}>
                                {log.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="6" style={{ padding: '2rem', textAlign: 'center', color: '#64748b' }}>
                            Loading live audit records from database...
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
