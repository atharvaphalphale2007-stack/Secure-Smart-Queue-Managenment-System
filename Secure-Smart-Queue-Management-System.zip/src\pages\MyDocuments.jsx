import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Download, Share2, Eye } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import CertificateModal from '../components/CertificateModal';

const MyDocuments = () => {
  const { documents } = useAppContext();
  const [showCertificate, setShowCertificate] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [toastMessage, setToastMessage] = useState('');

  const handleDownload = () => {
    setToastMessage('Download simulated');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleShare = () => {
    setToastMessage('Share link copied');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const openModal = (doc) => {
    setSelectedDoc(doc);
    setShowCertificate(true);
  };

  const hasDocuments = documents && documents.length > 0;

  return (
    <div className="main-content">
      <Breadcrumb items={[{ label: 'Home', path: '/' }, { label: 'My Documents' }]} />
      <div className="section">
        <h1 className="page-title">My Documents</h1>
        <p className="page-subtitle">View and manage your digitally issued certificates.</p>

        {!hasDocuments ? (
          <div className="card">
            <div className="card-body" style={{ textAlign: 'center', padding: '3rem 1rem' }}>
              <FileText size={64} color="#9ca3af" style={{ margin: '0 auto 1rem' }} />
              <h3>No documents issued yet.</h3>
              <p style={{ color: '#6b7280', marginBottom: '1.5rem' }}>Complete your service application to receive digital certificates.</p>
              <Link to="/application-status" className="btn btn-primary">Check Application Status</Link>
            </div>
          </div>
        ) : (
          <div className="grid-2">
            {documents.map((doc, idx) => (
              <div key={idx} className="card">
                <div className="card-body">
                  <span className="badge badge-success" style={{ marginBottom: '0.5rem', display: 'inline-block' }}>Digitally Issued</span>
                  <h3 style={{ textTransform: 'uppercase', marginBottom: '1rem' }}>{doc.type}</h3>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: '0.5rem', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
                    <strong>Certificate ID:</strong>
                    <span>{doc.id}</span>
                    
                    <strong>Issued To:</strong>
                    <span>{doc.name}</span>
                    
                    <strong>Issue Date:</strong>
                    <span>{doc.issueDate}</span>
                    
                    <strong>Status:</strong>
                    <span><span className="badge badge-success">Digitally Issued</span></span>
                  </div>

                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button className="btn btn-primary btn-sm" onClick={() => openModal(doc)}>
                      <Eye size={16} /> View Document
                    </button>
                    <button className="btn btn-secondary btn-sm" onClick={handleDownload}>
                      <Download size={16} /> Download
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={handleShare}>
                      <Share2 size={16} /> Share
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <CertificateModal
        isOpen={showCertificate}
        onClose={() => setShowCertificate(false)}
        document={selectedDoc}
      />

      {toastMessage && (
        <div className="toast-container">
          <div className="toast toast-success">{toastMessage}</div>
        </div>
      )}
    </div>
  );
};

export default MyDocuments;
