// Secure Smart Queue Management System — Cryptographic Tamper-Evident Audit Logger
// Computes SHA-256 hash chains for all sensitive operations.

import crypto from 'node:crypto';
import { getDb } from '../db.js';

const GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

export function computeEntryHash(previousHash, timestamp, actorId, action, resourceType, resourceId, details, status) {
  const payload = [
    previousHash || GENESIS_HASH,
    timestamp || '',
    actorId || 'SYSTEM',
    action || '',
    resourceType || '',
    resourceId || '',
    typeof details === 'object' ? JSON.stringify(details) : (details || ''),
    status || 'SUCCESS'
  ].join('|');

  return crypto.createHash('sha256').update(payload).digest('hex');
}

export function logAuditEvent({
  actorId = 'SYSTEM',
  actorRole = 'system',
  action,
  resourceType,
  resourceId = null,
  details = null,
  ipAddress = '127.0.0.1',
  status = 'SUCCESS'
}) {
  const db = getDb();
  const timestamp = new Date().toISOString();
  const detailsStr = typeof details === 'object' ? JSON.stringify(details) : (details || '');

  // Fetch previous hash
  const lastRow = db.prepare('SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1').get();
  const previousHash = lastRow?.entry_hash || GENESIS_HASH;

  const entryHash = computeEntryHash(
    previousHash,
    timestamp,
    actorId,
    action,
    resourceType,
    resourceId,
    detailsStr,
    status
  );

  const insert = db.prepare(`
    INSERT INTO audit_logs (
      timestamp, actor_id, actor_role, action, resource_type, resource_id,
      details, ip_address, status, previous_hash, entry_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const res = insert.run(
    timestamp,
    actorId,
    actorRole,
    action,
    resourceType,
    resourceId ? String(resourceId) : null,
    detailsStr,
    ipAddress,
    status,
    previousHash,
    entryHash
  );

  return {
    id: res.lastInsertRowid,
    timestamp,
    action,
    entryHash,
  };
}

export function verifyAuditTrail() {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM audit_logs ORDER BY id ASC').all();

  let prevHash = GENESIS_HASH;
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (row.previous_hash !== prevHash) {
      return {
        valid: false,
        totalChecked: i,
        failedAtId: row.id,
        reason: `Previous hash mismatch. Expected ${prevHash}, found ${row.previous_hash}`,
      };
    }

    const expectedHash = computeEntryHash(
      row.previous_hash,
      row.timestamp,
      row.actor_id,
      row.action,
      row.resource_type,
      row.resource_id,
      row.details,
      row.status
    );

    if (row.entry_hash !== expectedHash) {
      return {
        valid: false,
        totalChecked: i,
        failedAtId: row.id,
        reason: `Entry hash mismatch at record ${row.id}. Stored: ${row.entry_hash}, Computed: ${expectedHash}`,
      };
    }

    prevHash = row.entry_hash;
  }

  return {
    valid: true,
    totalChecked: rows.length,
    latestHash: prevHash,
  };
}

export default { logAuditEvent, verifyAuditTrail, computeEntryHash };
