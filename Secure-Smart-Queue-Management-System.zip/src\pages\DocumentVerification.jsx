import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Check, AlertCircle, X } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import StatusBadge from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';

const DocumentVerification = () => {
  const { citizen, token, docVerification, setDocVerification, advanceApplication } = useAppContext();
  const navigate = useNavigate();

  const allVerified = Object.values(docVerification).every(s => s === 'verified');

  const handleContinue = () => {
    advanceApplication();
    navigate('/application-status');
  };

  const handleRequestMissing = () => {
    alert('Missing document notification sent to citizen');
  };

  const docs = [
    { key: 'aadhaar', name: 'Aadhaar Card', status: docVerification.aadhaar, num: 1 },
    { key: 'addressProof', name: 'Address Proof', status: docVerification.addressProof, num: 2 },
    { key: 'incomeProof', name: 'Income Proof', status: docVerification.incomeProof, num: 3 },
    { key: 'photo', name: 'Passport Photo', status: docVerification.photo, num: 4 }
  ];

  return (
    <div className="page-container">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Document Verification' }
        ]}
      />

      <div className="section">
        <h1 className="page-title">Document Verification</h1>
        <p className="page-subtitle">Officer verification interface for citizen documents.</p>

        <div className="card" style={{ marginBottom: '2rem' }}>
          <div className="card-body">
            <h3 style={{ marginBottom: '1rem' }}>Citizen Details</h3>
            <div className="grid-3" style={{ gap: '1rem', marginBottom: '1rem' }}>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Citizen</p>
                <p style={{ fontWeight: 500 }}>{citizen?.name || 'Rahul Patil'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Token</p>
                <p style={{ fontWeight: 500 }}>{token?.tokenNumber || 'A-042'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Service</p>
                <p style={{ fontWeight: 500 }}>{token?.service || 'Income Certificate'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Assigned Counter</p>
                <p style={{ fontWeight: 500 }}>{token?.counterName || 'Counter 3'}</p>
              </div>
              <div>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Assigned Officer</p>
                <p style={{ fontWeight: 500 }}>Ms. Priya Sharma</p>
              </div>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: '2rem' }}>
          <div className="card-header" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <FileText size={20} />
            <h2>Required Documents</h2>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '2rem' }}>
              {docs.map(doc => (
                <div key={doc.key} className="doc-checklist-item" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div className="doc-number" style={{ width: '24px', height: '24px', backgroundColor: '#f1f5f9', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.875rem', fontWeight: 500 }}>
                      {doc.num}
                    </div>
                    <div>
                      <h4 style={{ margin: 0 }}>{doc.name}</h4>
                    </div>
                  </div>
                  
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <StatusBadge status={doc.status} />
                    <div className="doc-actions" style={{ display: 'flex', gap: '0.5rem' }}>
                      <button className="btn btn-sm" style={{ backgroundColor: '#22c55e', color: 'white', border: 'none', padding: '0.25rem 0.5rem', borderRadius: '4px', cursor: 'pointer' }} onClick={() => setDocVerification(doc.key, 'verified')} title="Verified">
                        <Check size={16} />
                      </button>
                      <button className="btn btn-sm" style={{ backgroundColor: '#f97316', color: 'white', border: 'none', padding: '0.25rem 0.5rem', borderRadius: '4px', cursor: 'pointer' }} onClick={() => setDocVerification(doc.key, 'missing')} title="Missing">
                        <AlertCircle size={16} />
                      </button>
                      <button className="btn btn-sm" style={{ backgroundColor: '#ef4444', color: 'white', border: 'none', padding: '0.25rem 0.5rem', borderRadius: '4px', cursor: 'pointer' }} onClick={() => setDocVerification(doc.key, 'invalid')} title="Invalid">
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {allVerified ? (
              <div className="alert alert-success" style={{ marginBottom: '1.5rem' }}>
                All Documents Verified ✓
              </div>
            ) : (
              <div className="alert alert-warning" style={{ marginBottom: '1.5rem' }}>
                Application cannot proceed until all mandatory documents are verified.
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <button className="btn btn-warning btn-sm" onClick={handleRequestMissing}>
                Request Missing Document
              </button>
              <button 
                className="btn btn-success btn-lg" 
                disabled={!allVerified} 
                onClick={handleContinue}
                style={{ opacity: allVerified ? 1 : 0.5, cursor: allVerified ? 'pointer' : 'not-allowed' }}
              >
                Continue Processing
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentVerification;
