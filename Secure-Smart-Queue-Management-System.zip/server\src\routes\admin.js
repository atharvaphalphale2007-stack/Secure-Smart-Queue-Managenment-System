// Secure Smart Queue Management System — Administrator Control Center
import { Router } from 'express';
import { getDb } from '../db.js';
import { requireRole } from '../middleware/auth.js';
import { logAuditEvent, verifyAuditTrail } from '../utils/auditLogger.js';

const router = Router();

// Enforce admin role for all routes in this module
router.use(requireRole('admin'));

// GET /api/admin/stats — System-wide analytics
router.get('/stats', (_req, res) => {
  const db = getDb();
  const totalBookings = db.prepare('SELECT COUNT(*) AS c FROM bookings').get()?.c || 0;
  const activeQueue = db.prepare("SELECT COUNT(*) AS c FROM tokens WHERE queue_status IN ('waiting','arrived','serving')").get()?.c || 0;
  const completedServices = db.prepare("SELECT COUNT(*) AS c FROM tokens WHERE queue_status = 'completed'").get()?.c || 0;
  const pendingApplications = db.prepare("SELECT COUNT(*) AS c FROM applications WHERE status IN ('submitted','under_verification','resubmitted')").get()?.c || 0;
  const urgentRequests = db.prepare("SELECT COUNT(*) AS c FROM urgent_requests WHERE status = 'pending'").get()?.c || 0;
  const grievances = db.prepare("SELECT COUNT(*) AS c FROM grievances WHERE status = 'submitted'").get()?.c || 0;
  const totalCitizens = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'citizen'").get()?.c || 0;
  const totalOfficers = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'officer'").get()?.c || 0;
  const unresolvedAlerts = db.prepare("SELECT COUNT(*) AS c FROM security_alerts WHERE resolved = 0").get()?.c || 0;

  res.json({
    totalBookings,
    activeQueue,
    completedServices,
    pendingApplications,
    urgentRequests,
    grievances,
    totalCitizens,
    totalOfficers,
    unresolvedAlerts,
  });
});

// GET /api/admin/audit-logs — Paginated audit log retrieval
router.get('/audit-logs', (req, res) => {
  const { limit = 50, offset = 0, action, actorId } = req.query;
  const db = getDb();

  let query = 'SELECT * FROM audit_logs WHERE 1=1';
  const params = [];

  if (action) {
    query += ' AND action = ?';
    params.push(action);
  }
  if (actorId) {
    query += ' AND actor_id = ?';
    params.push(actorId);
  }

  query += ' ORDER BY id DESC LIMIT ? OFFSET ?';
  params.push(Number(limit), Number(offset));

  const logs = db.prepare(query).all(...params);
  const totalCount = db.prepare('SELECT COUNT(*) AS c FROM audit_logs').get()?.c || 0;

  res.json({ total: totalCount, logs });
});

// GET /api/admin/audit-logs/verify — Cryptographic SHA-256 chain verification
router.get('/audit-logs/verify', (_req, res) => {
  const verification = verifyAuditTrail();
  res.json({
    ...verification,
    verifiedAt: new Date().toISOString(),
  });
});

// GET /api/admin/security-alerts — Security and fraud alerts
router.get('/security-alerts', (_req, res) => {
  const db = getDb();
  const alerts = db.prepare('SELECT * FROM security_alerts ORDER BY id DESC LIMIT 100').all();
  res.json(alerts);
});

// PATCH /api/admin/security-alerts/:id/resolve — Mark alert resolved
router.patch('/security-alerts/:id/resolve', (req, res) => {
  const db = getDb();
  db.prepare(`
    UPDATE security_alerts SET resolved = 1, resolved_at = datetime('now'), resolved_by = ? WHERE id = ?
  `).run(req.user.id, req.params.id);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'admin',
    action: 'SECURITY_ALERT_RESOLVED',
    resourceType: 'security_alert',
    resourceId: req.params.id,
    details: 'Administrator marked security alert as resolved',
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true });
});

// GET /api/admin/users — List registered users
router.get('/users', (req, res) => {
  const { role } = req.query;
  const db = getDb();

  let query = 'SELECT id, role, name, email, mobile, aadhaar, address, designation, department, counter, created_at, locked_until FROM users';
  const params = [];
  if (role) {
    query += ' WHERE role = ?';
    params.push(role);
  }
  query += ' ORDER BY created_at DESC';

  const users = db.prepare(query).all(...params);
  res.json(users);
});

// GET /api/admin/configs — Retrieve system configuration key-values
router.get('/configs', (_req, res) => {
  const db = getDb();
  const configs = db.prepare('SELECT * FROM system_configs').all();
  res.json(configs);
});

// PUT /api/admin/configs/:key — Update system configuration
router.put('/configs/:key', (req, res) => {
  const { value, description } = req.body || {};
  if (value === undefined) return res.status(400).json({ error: 'value is required' });

  const db = getDb();
  db.prepare(`
    INSERT INTO system_configs (key, value, description, updated_at, updated_by)
    VALUES (?, ?, ?, datetime('now'), ?)
    ON CONFLICT(key) DO UPDATE SET
      value = excluded.value,
      description = COALESCE(excluded.description, system_configs.description),
      updated_at = datetime('now'),
      updated_by = excluded.updated_by
  `).run(req.params.key, String(value), description || null, req.user.id);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'admin',
    action: 'SYSTEM_CONFIG_UPDATED',
    resourceType: 'config',
    resourceId: req.params.key,
    details: `Updated config ${req.params.key} to: ${value}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, key: req.params.key, value });
});

// Holidays management
router.get('/holidays', (_req, res) => {
  const db = getDb();
  const holidays = db.prepare('SELECT * FROM holidays ORDER BY date ASC').all();
  res.json(holidays);
});

router.post('/holidays', (req, res) => {
  const { date, title, description, officeId = 'OFFICE-PUNE-01' } = req.body || {};
  if (!date || !title) return res.status(400).json({ error: 'date and title are required' });

  const db = getDb();
  try {
    db.prepare(`
      INSERT INTO holidays (office_id, date, title, description) VALUES (?, ?, ?, ?)
    `).run(officeId, date, title, description || null);

    res.status(201).json({ success: true, date, title });
  } catch {
    res.status(409).json({ error: 'Holiday already exists on this date or invalid parameters' });
  }
});

router.delete('/holidays/:id', (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM holidays WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

export default router;