// Secure Smart Queue Management System — Government Services Catalog Routes
import { Router } from 'express';
import { getDb } from '../db.js';
import { requireRole } from '../middleware/auth.js';
import { logAuditEvent } from '../utils/auditLogger.js';

const router = Router();

// GET /api/services — List all active government services
router.get('/', (_req, res) => {
  const db = getDb();
  const services = db.prepare(`
    SELECT s.*, o.name AS office_name, o.district, o.grace_period_mins
    FROM services s
    LEFT JOIN offices o ON o.id = s.office_id
    WHERE s.is_active = 1
    ORDER BY s.name ASC
  `).all();

  // Attach required docs and guidelines
  const result = services.map((svc) => {
    const docs = db.prepare('SELECT * FROM service_required_docs WHERE service_id = ?').all(svc.id);
    const guidelines = db.prepare('SELECT guideline FROM service_guidelines WHERE service_id = ?').all(svc.id);
    const counterMap = db.prepare('SELECT counter_id FROM service_counter_map WHERE service_id = ?').get(svc.id);

    return {
      ...svc,
      requiredDocs: docs.map((d) => d.doc_name),
      requiredDocsDetail: docs,
      guidelines: guidelines.map((g) => g.guideline),
      assignedCounterId: counterMap?.counter_id || null,
    };
  });

  res.json(result);
});

// GET /api/services/:id — Detailed service metadata
router.get('/:id', (req, res) => {
  const db = getDb();
  const service = db.prepare(`
    SELECT s.*, o.name AS office_name, o.district, o.opening_time, o.closing_time, o.grace_period_mins
    FROM services s
    LEFT JOIN offices o ON o.id = s.office_id
    WHERE s.id = ?
  `).get(req.params.id);

  if (!service) {
    return res.status(404).json({ error: 'Government service not found' });
  }

  const docs = db.prepare('SELECT * FROM service_required_docs WHERE service_id = ?').all(req.params.id);
  const guidelines = db.prepare('SELECT guideline FROM service_guidelines WHERE service_id = ?').all(req.params.id);
  const counterMap = db.prepare('SELECT counter_id FROM service_counter_map WHERE service_id = ?').get(req.params.id);

  res.json({
    ...service,
    requiredDocs: docs.map((d) => d.doc_name),
    requiredDocsDetail: docs,
    guidelines: guidelines.map((g) => g.guideline),
    assignedCounterId: counterMap?.counter_id || null,
  });
});

// POST /api/services — Create a new government service (Admin only)
router.post('/', requireRole('admin'), (req, res) => {
  const {
    id, name, description, icon, processingTime, counterHandlingTimeMin,
    fee, officeAddress, landmark, eligibilityInfo, officialSource,
    counterId, requiredDocs = [], guidelines = []
  } = req.body || {};

  if (!id || !name) {
    return res.status(400).json({ error: 'Service ID and Name are required' });
  }

  const db = getDb();
  const officeId = 'OFFICE-PUNE-01';

  try {
    db.transaction(() => {
      db.prepare(`
        INSERT INTO services (
          id, office_id, name, description, icon, processing_time,
          counter_handling_time_min, fee, office_address, landmark,
          eligibility_info, official_source
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        id.toLowerCase().trim(),
        officeId,
        name.trim(),
        description || '',
        icon || 'FileText',
        processingTime || '3-5 working days',
        counterHandlingTimeMin || 10,
        fee || '₹0',
        officeAddress || '',
        landmark || '',
        eligibilityInfo || '',
        officialSource || 'Government of Maharashtra'
      );

      if (counterId) {
        db.prepare('INSERT OR REPLACE INTO service_counter_map (service_id, counter_id) VALUES (?, ?)')
          .run(id.toLowerCase().trim(), counterId);
      }

      for (const doc of requiredDocs) {
        const docName = typeof doc === 'string' ? doc : doc.name;
        const xerox = typeof doc === 'object' ? (doc.xerox || 0) : 1;
        db.prepare(`
          INSERT INTO service_required_docs (service_id, doc_name, xerox, is_mandatory, max_size_mb, allowed_formats)
          VALUES (?, ?, ?, 1, 5, 'application/pdf,image/jpeg,image/png')
        `).run(id.toLowerCase().trim(), docName, xerox);
      }

      for (const g of guidelines) {
        db.prepare('INSERT INTO service_guidelines (service_id, guideline) VALUES (?, ?)')
          .run(id.toLowerCase().trim(), typeof g === 'string' ? g : g.guideline);
      }
    });

    logAuditEvent({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: 'ADMIN_CREATE_SERVICE',
      resourceType: 'service',
      resourceId: id,
      details: `Created new government service: ${name}`,
      ipAddress: req.ip || '127.0.0.1',
      status: 'SUCCESS',
    });

    res.status(201).json({ success: true, serviceId: id });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create service: ' + err.message });
  }
});

// PUT /api/services/:id — Update existing service (Admin only)
router.put('/:id', requireRole('admin'), (req, res) => {
  const {
    name, description, fee, processingTime, counterHandlingTimeMin,
    eligibilityInfo, officialSource, isActive
  } = req.body || {};

  const db = getDb();
  const service = db.prepare('SELECT id FROM services WHERE id = ?').get(req.params.id);
  if (!service) return res.status(404).json({ error: 'Service not found' });

  db.prepare(`
    UPDATE services SET
      name = COALESCE(?, name),
      description = COALESCE(?, description),
      fee = COALESCE(?, fee),
      processing_time = COALESCE(?, processing_time),
      counter_handling_time_min = COALESCE(?, counter_handling_time_min),
      eligibility_info = COALESCE(?, eligibility_info),
      official_source = COALESCE(?, official_source),
      is_active = COALESCE(?, is_active),
      last_updated = datetime('now')
    WHERE id = ?
  `).run(
    name || null, description || null, fee || null, processingTime || null,
    counterHandlingTimeMin || null, eligibilityInfo || null, officialSource || null,
    isActive !== undefined ? (isActive ? 1 : 0) : null,
    req.params.id
  );

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'ADMIN_UPDATE_SERVICE',
    resourceType: 'service',
    resourceId: req.params.id,
    details: 'Service metadata updated by administrator',
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, updatedId: req.params.id });
});

export default router;