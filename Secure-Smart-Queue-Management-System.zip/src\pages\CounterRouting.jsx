import React from 'react';
import { ArrowDown } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import StatusBadge from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';
import { SERVICES, SERVICE_COUNTER_MAP, COUNTERS } from '../data/mockData';

const CounterRouting = () => {
  const { token, booking } = useAppContext();

  return (
    <div className="page-container">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Counter Routing' }
        ]}
      />

      <div className="section">
        <h1 className="page-title">Smart Counter Assignment</h1>
        <p className="page-subtitle">The system automatically assigns the citizen to the appropriate counter based on the selected service.</p>

        {token && (
          <div className="card" style={{ marginBottom: '2rem', borderLeft: '4px solid #2563eb' }}>
            <div className="card-body">
              <h3 style={{ marginBottom: '1rem', color: '#1e293b' }}>Current Assignment</h3>
              <div className="grid-4" style={{ gap: '1rem' }}>
                <div>
                  <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Selected Service</p>
                  <p style={{ fontWeight: 500 }}>{token.service}</p>
                </div>
                <div>
                  <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Assigned Counter</p>
                  <p style={{ fontWeight: 500, color: '#2563eb' }}>{token.counterName}</p>
                </div>
                <div>
                  <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Officer</p>
                  <p style={{ fontWeight: 500 }}>Ms. Priya Sharma</p>
                </div>
                <div>
                  <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Counter Status</p>
                  <StatusBadge status="active" />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid-2" style={{ gap: '2rem' }}>
          <div className="card">
            <div className="card-header">
              <h2>Service to Counter Map</h2>
            </div>
            <div className="table-wrapper">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                    <th style={{ padding: '0.75rem', textAlign: 'left', fontWeight: 600 }}>Service</th>
                    <th style={{ padding: '0.75rem', textAlign: 'left', fontWeight: 600 }}>Counter</th>
                    <th style={{ padding: '0.75rem', textAlign: 'left', fontWeight: 600 }}>Officer</th>
                  </tr>
                </thead>
                <tbody>
                  {SERVICES.map(service => {
                    const counterNum = SERVICE_COUNTER_MAP[service.id];
                    const counter = COUNTERS.find(c => c.id === counterNum);
                    const isHighlighted = booking?.serviceId === service.id;
                    return (
                      <tr key={service.id} style={{ borderBottom: '1px solid #e2e8f0', backgroundColor: isHighlighted ? '#eff6ff' : 'transparent' }}>
                        <td style={{ padding: '0.75rem' }}>{service.name}</td>
                        <td style={{ padding: '0.75rem' }}>{counter?.name || `Counter ${counterNum}`}</td>
                        <td style={{ padding: '0.75rem' }}>{counter?.officer || 'Staff'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card">
            <div className="card-body">
              <h2 style={{ marginBottom: '1.5rem' }}>How Counter Routing Works</h2>
              
              <div className="flow-steps" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div className="flow-step" style={{ padding: '1rem', backgroundColor: '#f1f5f9', borderRadius: '8px', width: '100%', textAlign: 'center', border: '1px solid #cbd5e1' }}>
                  <strong>1. Service Selected</strong>
                </div>
                <div className="flow-arrow" style={{ padding: '0.5rem 0' }}>
                  <ArrowDown color="#94a3b8" />
                </div>
                <div className="flow-step" style={{ padding: '1rem', backgroundColor: '#f1f5f9', borderRadius: '8px', width: '100%', textAlign: 'center', border: '1px solid #cbd5e1' }}>
                  <strong>2. Service Category Identified</strong>
                </div>
                <div className="flow-arrow" style={{ padding: '0.5rem 0' }}>
                  <ArrowDown color="#94a3b8" />
                </div>
                <div className="flow-step" style={{ padding: '1rem', backgroundColor: '#f1f5f9', borderRadius: '8px', width: '100%', textAlign: 'center', border: '1px solid #cbd5e1' }}>
                  <strong>3. Counter Availability Checked</strong>
                </div>
                <div className="flow-arrow" style={{ padding: '0.5rem 0' }}>
                  <ArrowDown color="#94a3b8" />
                </div>
                <div className="flow-step" style={{ padding: '1rem', backgroundColor: '#eff6ff', borderRadius: '8px', width: '100%', textAlign: 'center', border: '1px solid #bfdbfe', color: '#1e40af' }}>
                  <strong>4. Counter Assigned</strong>
                </div>
                <div className="flow-arrow" style={{ padding: '0.5rem 0' }}>
                  <ArrowDown color="#94a3b8" />
                </div>
                <div className="flow-step" style={{ padding: '1rem', backgroundColor: '#f0fdf4', borderRadius: '8px', width: '100%', textAlign: 'center', border: '1px solid #bbf7d0', color: '#166534' }}>
                  <strong>5. Citizen Notified</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CounterRouting;
