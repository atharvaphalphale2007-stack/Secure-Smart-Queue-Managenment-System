import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  ShieldCheck,
  LayoutDashboard,
  Clock,
  Zap,
  ArrowRight,
  ChevronUp,
  ChevronDown,
  Sparkles,
  CheckCircle,
  RotateCcw,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';

/**
 * RoleSimulatorDock
 * A floating developer/reviewer toolbar shown ONLY WHEN LOGGED IN.
 * Allows instant role switching and trigger simulations for testing paired
 * citizen-officer turn reminders (30m & 15m), queue movement, and document issuance.
 */
export default function RoleSimulatorDock() {
  const {
    user,
    switchRole,
    token,
    sendOfficerReminder,
    callNextCitizen,
    advanceApplication,
    resetDemo,
    applicationStatus,
  } = useAppContext();
  const navigate = useNavigate();

  const [expanded, setExpanded] = useState(false);

  // STRICT REQUIREMENT: Never render if unauthenticated!
  if (!user) return null;

  const currentRole = user?.role || 'citizen';
  const tokenNum = token?.tokenNumber || 'A-042';

  const handleRoleSwitch = (role) => {
    switchRole(role);
    if (role === 'officer') {
      navigate('/officer');
    } else if (role === 'admin') {
      navigate('/admin');
    } else {
      navigate('/my-token');
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '18px',
        right: '18px',
        zIndex: 900,
        fontFamily: 'inherit',
      }}
    >
      {/* Collapsed Pill */}
      {!expanded ? (
        <button
          type="button"
          onClick={() => setExpanded(true)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
            color: '#ffffff',
            border: '1px solid rgba(255,255,255,0.2)',
            padding: '8px 16px',
            borderRadius: '30px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.35)',
            fontSize: '0.82rem',
            fontWeight: 700,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          title="Open Live Cross-Role Testing & Simulation Dock"
        >
          <Sparkles size={16} color="#38bdf8" />
          <span>Role & Live Simulator Dock</span>
          <span
            style={{
              background: currentRole === 'officer' ? '#0284c7' : currentRole === 'admin' ? '#7c3aed' : '#16a34a',
              color: '#fff',
              padding: '2px 8px',
              borderRadius: '12px',
              fontSize: '0.72rem',
              textTransform: 'uppercase',
            }}
          >
            {currentRole}
          </span>
          <ChevronUp size={16} />
        </button>
      ) : (
        /* Expanded Control Panel */
        <div
          style={{
            background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
            color: '#ffffff',
            border: '1px solid #334155',
            borderRadius: '16px',
            padding: '16px 20px',
            width: '360px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
          }}
        >
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #334155', paddingBottom: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={18} color="#38bdf8" />
              <strong style={{ fontSize: '0.9rem' }}>Live System Simulator</strong>
            </div>
            <button
              type="button"
              onClick={() => setExpanded(false)}
              style={{
                background: 'none',
                border: 'none',
                color: '#94a3b8',
                cursor: 'pointer',
                padding: '4px',
                display: 'flex',
                alignItems: 'center',
              }}
              title="Minimize"
            >
              <ChevronDown size={18} />
            </button>
          </div>

          {/* Quick Role Switcher */}
          <div style={{ marginBottom: '14px' }}>
            <div style={{ fontSize: '0.72rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>
              Active Profile Switcher
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '6px' }}>
              <button
                type="button"
                onClick={() => handleRoleSwitch('citizen')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  background: currentRole === 'citizen' ? '#16a34a' : '#334155',
                  color: '#ffffff',
                  border: currentRole === 'citizen' ? '1px solid #4ade80' : 'none',
                  padding: '8px 4px',
                  borderRadius: '8px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <Users size={16} />
                <span>Citizen</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSwitch('officer')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  background: currentRole === 'officer' ? '#0284c7' : '#334155',
                  color: '#ffffff',
                  border: currentRole === 'officer' ? '1px solid #38bdf8' : 'none',
                  padding: '8px 4px',
                  borderRadius: '8px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <ShieldCheck size={16} />
                <span>Officer</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSwitch('admin')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  background: currentRole === 'admin' ? '#7c3aed' : '#334155',
                  color: '#ffffff',
                  border: currentRole === 'admin' ? '1px solid #c084fc' : 'none',
                  padding: '8px 4px',
                  borderRadius: '8px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <LayoutDashboard size={16} />
                <span>Admin</span>
              </button>
            </div>
          </div>

          {/* Quick Simulation Triggers */}
          <div style={{ marginBottom: '14px' }}>
            <div style={{ fontSize: '0.72rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>
              Instant Event Triggers (Target: {tokenNum})
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
              <button
                type="button"
                onClick={() => sendOfficerReminder(tokenNum, 30)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  background: '#f59e0b',
                  color: '#000000',
                  border: 'none',
                  padding: '7px 8px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                <Clock size={14} /> Send 30m Alert
              </button>

              <button
                type="button"
                onClick={() => sendOfficerReminder(tokenNum, 15)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  background: '#ef4444',
                  color: '#ffffff',
                  border: 'none',
                  padding: '7px 8px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                <Zap size={14} /> Send 15m Call
              </button>

              <button
                type="button"
                onClick={callNextCitizen}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  background: '#38bdf8',
                  color: '#0f172a',
                  border: 'none',
                  padding: '7px 8px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                <ArrowRight size={14} /> Advance Queue
              </button>

              <button
                type="button"
                onClick={advanceApplication}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  background: '#22c55e',
                  color: '#000000',
                  border: 'none',
                  padding: '7px 8px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                <CheckCircle size={14} /> {applicationStatus === 'completed' ? 'Issued' : 'Approve Stage'}
              </button>
            </div>
          </div>

          {/* Reset Demo State */}
          <div style={{ textAlign: 'center', borderTop: '1px solid #334155', paddingTop: '8px' }}>
            <button
              type="button"
              onClick={resetDemo}
              style={{
                background: 'none',
                border: 'none',
                color: '#94a3b8',
                fontSize: '0.75rem',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              <RotateCcw size={12} /> Reset to Initial Demo Data
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
