import React, { useState } from 'react';
import {
  ShieldCheck,
  Radio,
  CheckCircle,
  QrCode,
  FileCheck,
  AlertTriangle,
  Zap,
  ChevronRight,
  Clock,
  Bell,
  Check,
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';

export default function OfficerDashboard() {
  const {
    user,
    citizen,
    token,
    tokenReminders = {},
    sendOfficerReminder,
    applicationStatus,
    docVerification,
    setDocVerification,
    advanceApplication,
    grievance,
    urgentRequest,
    handleOfficerGrievanceAction,
    handleOfficerUrgentAction,
  } = useAppContext();

  const [activeTab, setActiveTab] = useState('queue'); // 'queue' | 'verification' | 'reminders' | 'grievances' | 'urgent'
  const [scanModalOpen, setScanModalOpen] = useState(false);
  const [scannedResult, setScannedResult] = useState(null);
  const [reminderToast, setReminderToast] = useState(null);

  const activeTokenNumber = token?.tokenNumber || 'A-042';
  const activeService = token?.service || 'Income Certificate';

  const handleDocumentStatus = (docKey, status) => {
    setDocVerification(docKey, status);
  };

  const handleSimulateScan = async () => {
    try {
      const { api } = await import('../utils/api');
      const res = await api.verifyStage2Counter(activeTokenNumber, user?.counter || 3);
      setScannedResult({
        valid: true,
        tokenNumber: activeTokenNumber,
        citizenName: res?.citizenName || citizen.name,
        aadhaar: citizen.aadhaar,
        service: res?.service || activeService,
        status: 'STAGE 2 VERIFIED & SERVING AT COUNTER',
        time: new Date().toLocaleTimeString(),
      });
    } catch (err) {
      setScannedResult({
        valid: false,
        tokenNumber: activeTokenNumber,
        citizenName: citizen.name,
        aadhaar: citizen.aadhaar,
        service: activeService,
        status: `REJECTED: ${err.message}`,
        time: new Date().toLocaleTimeString(),
      });
    }
  };

  const handleSendReminder = (tokenNum, minutes) => {
    const result = sendOfficerReminder(tokenNum, minutes);
    setReminderToast({
      tokenNumber: tokenNum,
      minutes,
      time: result.time,
      message: minutes === 30
        ? `⏰ 30-Minute Turn Reminder successfully sent to Token #${tokenNum} via SMS (+91 98XXXXXX42) & App Notification!`
        : `🚨 15-Minute Final Call successfully sent to Token #${tokenNum} via SMS (+91 98XXXXXX42) & App Notification!`,
    });

    setTimeout(() => {
      setReminderToast(null);
    }, 6000);
  };

  // Queue rows for table
  const queueList = [
    { tokenNumber: activeTokenNumber, name: citizen.name, service: activeService, checkIn: 'Checked-In', mobile: citizen.mobile || '98XXXXXX42' },
    { tokenNumber: 'A-043', name: 'Suresh Deshmukh', service: 'Income Certificate', checkIn: 'Waiting', mobile: '98XXXXXX11' },
    { tokenNumber: 'A-044', name: 'Anjali Mehta', service: 'Income Certificate', checkIn: 'Waiting', mobile: '98XXXXXX88' },
  ];

  const currentTokenReminders = tokenReminders[activeTokenNumber] || token?.reminders || {};

  return (
    <div style={{ maxWidth: '1200px', margin: '1.5rem auto', padding: '0 1rem' }}>
      {/* Officer Banner Header */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)',
          color: 'white',
          borderRadius: '0.75rem',
          padding: '1.5rem 2rem',
          marginBottom: '2rem',
          boxShadow: '0 4px 15px rgba(2, 132, 199, 0.25)',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <div
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              borderRadius: '50%',
              padding: '0.85rem',
              backdropFilter: 'blur(4px)',
            }}
          >
            <ShieldCheck size={36} color="#ffffff" />
          </div>
          <div>
            <div style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', opacity: 0.9 }}>
              Government Service Verification Portal
            </div>
            <h1 style={{ margin: '0.25rem 0 0', fontSize: '1.6rem', color: '#ffffff' }}>
              {user?.name || 'Ms. Priya Sharma'} — Counter 3
            </h1>
            <p style={{ margin: '4px 0 0', fontSize: '0.9rem', opacity: 0.95 }}>
              Senior Tehsildar & Verification Officer • Income Certificate Desk
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button
            type="button"
            className="btn"
            onClick={() => setScanModalOpen(true)}
            style={{
              background: '#ffffff',
              color: '#0284c7',
              fontWeight: 700,
              padding: '0.65rem 1.25rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              borderRadius: '0.5rem',
              border: 'none',
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            }}
          >
            <QrCode size={18} />
            Scan Citizen QR Code
          </button>
        </div>
      </div>

      {/* Reminder Dispatched Toast Notification */}
      {reminderToast && (
        <div
          style={{
            background: reminderToast.minutes === 30 ? '#fffbeb' : '#fef2f2',
            border: `2px solid ${reminderToast.minutes === 30 ? '#f59e0b' : '#ef4444'}`,
            color: reminderToast.minutes === 30 ? '#92400e' : '#991b1b',
            borderRadius: '0.75rem',
            padding: '1rem 1.5rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
            animation: 'fadeIn 0.3s ease-in-out',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {reminderToast.minutes === 30 ? <Clock size={24} color="#d97706" /> : <Zap size={24} color="#dc2626" />}
            <div>
              <div style={{ fontWeight: 800, fontSize: '0.95rem' }}>
                {reminderToast.minutes === 30 ? '30-Minute Reminder Dispatched' : '15-Minute Final Call Dispatched'} ({reminderToast.time})
              </div>
              <div style={{ fontSize: '0.85rem' }}>{reminderToast.message}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setReminderToast(null)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontWeight: 800, fontSize: '1.1rem', color: 'inherit' }}
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Grid: Navigation Tabs & Workspace */}
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: '1.5rem' }}>
        {/* Officer Navigation Sidebar */}
        <div style={{ background: '#ffffff', borderRadius: '0.75rem', padding: '1rem', height: 'fit-content', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', marginBottom: '0.75rem', paddingLeft: '0.5rem' }}>
            Officer Controls
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
            <button
              type="button"
              className={`btn ${activeTab === 'queue' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setActiveTab('queue')}
              style={{
                justifyContent: 'flex-start',
                textAlign: 'left',
                border: activeTab === 'queue' ? undefined : 'none',
                color: activeTab === 'queue' ? undefined : '#475569',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.75rem 1rem',
              }}
            >
              <Radio size={18} />
              View Assigned Queue
            </button>

            <button
              type="button"
              className={`btn ${activeTab === 'reminders' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setActiveTab('reminders')}
              style={{
                justifyContent: 'flex-start',
                textAlign: 'left',
                border: activeTab === 'reminders' ? undefined : 'none',
                color: activeTab === 'reminders' ? undefined : '#475569',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.75rem 1rem',
              }}
            >
              <Bell size={18} />
              Turn Reminders (30m & 15m)
            </button>

            <button
              type="button"
              className={`btn ${activeTab === 'verification' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setActiveTab('verification')}
              style={{
                justifyContent: 'flex-start',
                textAlign: 'left',
                border: activeTab === 'verification' ? undefined : 'none',
                color: activeTab === 'verification' ? undefined : '#475569',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.75rem 1rem',
              }}
            >
              <FileCheck size={18} />
              Document Verification
            </button>

            <button
              type="button"
              className={`btn ${activeTab === 'grievances' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setActiveTab('grievances')}
              style={{
                justifyContent: 'flex-start',
                textAlign: 'left',
                border: activeTab === 'grievances' ? undefined : 'none',
                color: activeTab === 'grievances' ? undefined : '#475569',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.75rem 1rem',
              }}
            >
              <AlertTriangle size={18} />
              Correction Requests ({grievance ? 1 : 0})
            </button>

            <button
              type="button"
              className={`btn ${activeTab === 'urgent' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setActiveTab('urgent')}
              style={{
                justifyContent: 'flex-start',
                textAlign: 'left',
                border: activeTab === 'urgent' ? undefined : 'none',
                color: activeTab === 'urgent' ? undefined : '#475569',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.75rem 1rem',
              }}
            >
              <Zap size={18} />
              Urgent Requests ({urgentRequest ? 1 : 0})
            </button>
          </div>
        </div>

        {/* Workspace Body */}
        <div>
          {/* TAB 1: Assigned Queue & Current Active Token */}
          {activeTab === 'queue' && (
            <div>
              {/* Active Token Card */}
              <div className="card" style={{ marginBottom: '1.5rem', borderLeft: '4px solid #0284c7' }}>
                <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Radio size={20} color="#0284c7" />
                    <h3 style={{ margin: 0 }}>Currently Processing Citizen Token</h3>
                  </div>
                  <span className="badge badge-primary" style={{ fontSize: '0.85rem' }}>Counter 3 • Active Token</span>
                </div>

                <div className="card-body">
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
                    <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Token Number</div>
                      <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0284c7' }}>{activeTokenNumber}</div>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Citizen Name</div>
                      <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#0f172a' }}>{citizen.name}</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Aadhaar: {citizen.aadhaar}</div>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Service Requested</div>
                      <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#0f172a' }}>{activeService}</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Time Slot: 10:30 AM - 11:00 AM</div>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Application Status</div>
                      <div style={{ marginTop: '4px' }}>
                        <StatusBadge status={applicationStatus === 'none' ? 'received' : applicationStatus} />
                      </div>
                    </div>
                  </div>

                  {/* FEATURE: Officer 30-Min and 15-Min Turn Reminder Dispatch Panel */}
                  <div
                    style={{
                      background: 'linear-gradient(135deg, #f0fdf4 0%, #ecfeff 100%)',
                      border: '1px solid #a7f3d0',
                      borderRadius: '0.65rem',
                      padding: '1.25rem',
                      marginBottom: '1.5rem',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Bell size={20} color="#059669" />
                        <h4 style={{ margin: 0, color: '#065f46', fontSize: '1rem' }}>
                          Dispatch Turn Arrival Reminder to Citizen (SMS & In-App Alert)
                        </h4>
                      </div>
                      <span style={{ fontSize: '0.78rem', color: '#047857', fontWeight: 600 }}>
                        Target: {citizen.name} ({activeTokenNumber})
                      </span>
                    </div>

                    <p style={{ margin: '0 0 1rem', fontSize: '0.84rem', color: '#065f46' }}>
                      Notify the citizen prior to calling their number so they arrive on time and are present at Counter 3:
                    </p>

                    <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
                      {/* 30 Min Reminder Button */}
                      <button
                        type="button"
                        onClick={() => handleSendReminder(activeTokenNumber, 30)}
                        style={{
                          background: currentTokenReminders?.reminder30Min ? '#fef3c7' : '#ffffff',
                          color: '#b45309',
                          border: `2px solid ${currentTokenReminders?.reminder30Min ? '#f59e0b' : '#fcd34d'}`,
                          padding: '0.65rem 1.25rem',
                          borderRadius: '0.5rem',
                          fontWeight: 700,
                          fontSize: '0.88rem',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.5rem',
                          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                        }}
                      >
                        <Clock size={18} />
                        {currentTokenReminders?.reminder30Min
                          ? `✓ 30-Min Reminder Sent (${currentTokenReminders.reminder30MinTime || 'Active'}) • Re-send`
                          : '⏰ Send 30-Min Arrival Reminder'}
                      </button>

                      {/* 15 Min Reminder Button */}
                      <button
                        type="button"
                        onClick={() => handleSendReminder(activeTokenNumber, 15)}
                        style={{
                          background: currentTokenReminders?.reminder15Min ? '#fee2e2' : '#ffffff',
                          color: '#b91c1c',
                          border: `2px solid ${currentTokenReminders?.reminder15Min ? '#ef4444' : '#fca5a5'}`,
                          padding: '0.65rem 1.25rem',
                          borderRadius: '0.5rem',
                          fontWeight: 700,
                          fontSize: '0.88rem',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.5rem',
                          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                        }}
                      >
                        <Zap size={18} />
                        {currentTokenReminders?.reminder15Min
                          ? `🚨 15-Min Final Call Sent (${currentTokenReminders.reminder15MinTime || 'Active'}) • Re-send`
                          : '🚨 Send 15-Min Final Call Reminder'}
                      </button>

                      {(currentTokenReminders?.reminder30Min || currentTokenReminders?.reminder15Min) && (
                        <span style={{ fontSize: '0.78rem', color: '#047857', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Check size={14} /> Alerts Active on Citizen Device
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Advance Application Workflow Controls */}
                  <div style={{ background: '#e0f2fe', padding: '1.25rem', borderRadius: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
                    <div>
                      <h4 style={{ margin: 0, color: '#0369a1', fontSize: '0.95rem' }}>Update Application Lifecycle</h4>
                      <p style={{ margin: '2px 0 0', fontSize: '0.82rem', color: '#0284c7' }}>
                        Current Status: <strong style={{ textTransform: 'capitalize' }}>{applicationStatus}</strong>
                      </p>
                    </div>
                    <div style={{ display: 'flex', gap: '0.75rem' }}>
                      {applicationStatus !== 'completed' ? (
                        <button
                          type="button"
                          className="btn btn-primary"
                          onClick={advanceApplication}
                          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#0284c7', borderColor: '#0284c7' }}
                        >
                          <ChevronRight size={18} />
                          Advance to {applicationStatus === 'received' ? 'Verified' : applicationStatus === 'verified' ? 'Processing' : applicationStatus === 'processing' ? 'Approved' : 'Completed (Issue Cert)'}
                        </button>
                      ) : (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#16a34a', fontWeight: 700 }}>
                          <CheckCircle size={20} /> Service Completed & Issued!
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Assigned Queue List with Direct 30m / 15m Reminder Action Buttons */}
              <div className="card">
                <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h3 style={{ margin: 0 }}>Counter 3 — Waiting Queue List</h3>
                    <p style={{ margin: '2px 0 0', fontSize: '0.82rem', color: '#64748b' }}>
                      Send 30-minute and 15-minute reminders to citizens waiting in line.
                    </p>
                  </div>
                  <span className="badge badge-secondary">{queueList.length} Citizens in Line</span>
                </div>
                <div className="table-wrapper">
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Token</th>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Citizen</th>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Service</th>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Check-in</th>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Turn Reminders</th>
                        <th style={{ textAlign: 'left', padding: '0.75rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {queueList.map((item) => {
                        const reminders = tokenReminders[item.tokenNumber] || {};
                        const isMainToken = item.tokenNumber === activeTokenNumber;

                        return (
                          <tr key={item.tokenNumber}>
                            <td style={{ padding: '0.75rem 1rem', fontWeight: 'bold', color: isMainToken ? '#0284c7' : '#0f172a' }}>
                              {item.tokenNumber}
                            </td>
                            <td style={{ padding: '0.75rem 1rem' }}>
                              <div style={{ fontWeight: 600 }}>{item.name}</div>
                              <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Mob: {item.mobile}</div>
                            </td>
                            <td style={{ padding: '0.75rem 1rem' }}>{item.service}</td>
                            <td style={{ padding: '0.75rem 1rem' }}>
                              <span className={`badge ${item.checkIn === 'Checked-In' ? 'badge-success' : 'badge-secondary'}`}>
                                {item.checkIn}
                              </span>
                            </td>
                            <td style={{ padding: '0.75rem 1rem' }}>
                              <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                                {/* 30-Min Button */}
                                <button
                                  type="button"
                                  onClick={() => handleSendReminder(item.tokenNumber, 30)}
                                  style={{
                                    padding: '4px 8px',
                                    fontSize: '0.74rem',
                                    fontWeight: 700,
                                    borderRadius: '4px',
                                    border: '1px solid #f59e0b',
                                    background: reminders.reminder30Min ? '#fef3c7' : '#ffffff',
                                    color: '#b45309',
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '3px',
                                  }}
                                  title="Send 30 Min Arrival Reminder to Citizen"
                                >
                                  <Clock size={12} />
                                  {reminders.reminder30Min ? '30m ✓' : '30m'}
                                </button>

                                {/* 15-Min Button */}
                                <button
                                  type="button"
                                  onClick={() => handleSendReminder(item.tokenNumber, 15)}
                                  style={{
                                    padding: '4px 8px',
                                    fontSize: '0.74rem',
                                    fontWeight: 700,
                                    borderRadius: '4px',
                                    border: '1px solid #ef4444',
                                    background: reminders.reminder15Min ? '#fee2e2' : '#ffffff',
                                    color: '#b91c1c',
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '3px',
                                  }}
                                  title="Send 15 Min Final Call to Citizen"
                                >
                                  <Zap size={12} />
                                  {reminders.reminder15Min ? '15m ✓' : '15m'}
                                </button>
                              </div>
                            </td>
                            <td style={{ padding: '0.75rem 1rem' }}>
                              {isMainToken ? (
                                <button
                                  type="button"
                                  className="btn btn-sm btn-primary"
                                  onClick={() => setActiveTab('verification')}
                                >
                                  Verify Docs
                                </button>
                              ) : (
                                <button className="btn btn-sm btn-outline" disabled>
                                  Waiting
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Dedicated Turn Reminders Management Hub */}
          {activeTab === 'reminders' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                <div>
                  <h3 style={{ margin: 0 }}>Citizen Turn Reminders Dispatch Control</h3>
                  <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: '#64748b' }}>
                    Send pre-arrival alerts at 30 minutes and 15 minutes before the citizen's turn.
                  </p>
                </div>
                <span className="badge badge-primary">Counter 3 Gateway</span>
              </div>

              <div className="card-body">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
                  {/* 30-Minute Card */}
                  <div style={{ border: '2px solid #fcd34d', borderRadius: '0.75rem', padding: '1.5rem', background: '#fffbeb' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#b45309', fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.5rem' }}>
                      <Clock size={24} /> 30-Minute Arrival Reminder
                    </div>
                    <p style={{ fontSize: '0.86rem', color: '#92400e', lineHeight: '1.5', marginBottom: '1rem' }}>
                      Advise citizens to start moving towards the Tehsildar Complex. Sent when their number is approximately 3-4 positions away.
                    </p>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="btn btn-sm"
                        onClick={() => handleSendReminder('A-042', 30)}
                        style={{ background: '#f59e0b', color: '#ffffff', fontWeight: 700 }}
                      >
                        Notify Token A-042 (30m)
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm"
                        onClick={() => handleSendReminder('A-043', 30)}
                        style={{ background: '#d97706', color: '#ffffff', fontWeight: 700 }}
                      >
                        Notify Token A-043 (30m)
                      </button>
                    </div>
                  </div>

                  {/* 15-Minute Card */}
                  <div style={{ border: '2px solid #fca5a5', borderRadius: '0.75rem', padding: '1.5rem', background: '#fef2f2' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#b91c1c', fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.5rem' }}>
                      <Zap size={24} /> 15-Minute Final Approach Alert
                    </div>
                    <p style={{ fontSize: '0.86rem', color: '#991b1b', lineHeight: '1.5', marginBottom: '1rem' }}>
                      Urgent alert to stand near Counter 3 with originals. Sent when the preceding citizen is nearing document completion.
                    </p>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="btn btn-sm"
                        onClick={() => handleSendReminder('A-042', 15)}
                        style={{ background: '#ef4444', color: '#ffffff', fontWeight: 700 }}
                      >
                        Notify Token A-042 (15m)
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm"
                        onClick={() => handleSendReminder('A-043', 15)}
                        style={{ background: '#dc2626', color: '#ffffff', fontWeight: 700 }}
                      >
                        Notify Token A-043 (15m)
                      </button>
                    </div>
                  </div>
                </div>

                {/* Reminder History Table */}
                <h4 style={{ margin: '0 0 0.75rem', fontSize: '1rem', color: '#0f172a' }}>
                  Today's Dispatched Reminder History
                </h4>
                <div className="table-wrapper">
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                    <thead>
                      <tr style={{ background: '#f8fafc' }}>
                        <th style={{ textAlign: 'left', padding: '0.65rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Token</th>
                        <th style={{ textAlign: 'left', padding: '0.65rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Citizen Name</th>
                        <th style={{ textAlign: 'left', padding: '0.65rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Reminder Type</th>
                        <th style={{ textAlign: 'left', padding: '0.65rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Channel</th>
                        <th style={{ textAlign: 'left', padding: '0.65rem 1rem', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td style={{ padding: '0.65rem 1rem', fontWeight: 700, color: '#0284c7' }}>A-042</td>
                        <td style={{ padding: '0.65rem 1rem' }}>Rahul Patil</td>
                        <td style={{ padding: '0.65rem 1rem' }}>
                          <span className="badge badge-warning">30-Min Arrival</span>
                        </td>
                        <td style={{ padding: '0.65rem 1rem' }}>SMS + App Push</td>
                        <td style={{ padding: '0.65rem 1rem', color: '#16a34a', fontWeight: 600 }}>✓ Delivered</td>
                      </tr>
                      <tr>
                        <td style={{ padding: '0.65rem 1rem', fontWeight: 700, color: '#0284c7' }}>A-042</td>
                        <td style={{ padding: '0.65rem 1rem' }}>Rahul Patil</td>
                        <td style={{ padding: '0.65rem 1rem' }}>
                          <span className="badge badge-danger">15-Min Final Call</span>
                        </td>
                        <td style={{ padding: '0.65rem 1rem' }}>SMS + App Push</td>
                        <td style={{ padding: '0.65rem 1rem', color: '#16a34a', fontWeight: 600 }}>✓ Delivered</td>
                      </tr>
                      <tr>
                        <td style={{ padding: '0.65rem 1rem', fontWeight: 700 }}>A-035</td>
                        <td style={{ padding: '0.65rem 1rem' }}>Kavita Shinde</td>
                        <td style={{ padding: '0.65rem 1rem' }}>
                          <span className="badge badge-danger">15-Min Final Call</span>
                        </td>
                        <td style={{ padding: '0.65rem 1rem' }}>SMS + App Push</td>
                        <td style={{ padding: '0.65rem 1rem', color: '#16a34a', fontWeight: 600 }}>✓ Completed Service</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Document Verification Worklist */}
          {activeTab === 'verification' && (
            <div className="card">
              <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0 }}>Citizen Document Verification Panel</h3>
                  <p style={{ margin: '2px 0 0', fontSize: '0.85rem', color: '#64748b' }}>
                    Token: <strong>{activeTokenNumber}</strong> • Citizen: <strong>{citizen.name}</strong>
                  </p>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-outline"
                  onClick={() => setScanModalOpen(true)}
                  style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  <QrCode size={16} /> Re-scan QR
                </button>
              </div>

              <div className="card-body">
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
                  {/* Aadhaar Card */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', background: '#ffffff' }}>
                    <div>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>1. Aadhaar Card (Identity Proof)</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>UIDAI Number: {citizen.aadhaar} • Original & Xerox verified</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.aadhaar === 'verified' ? 'btn-success' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('aadhaar', 'verified')}
                      >
                        ✓ Verified
                      </button>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.aadhaar === 'missing' ? 'btn-danger' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('aadhaar', 'missing')}
                      >
                        ✕ Missing
                      </button>
                    </div>
                  </div>

                  {/* Address Proof */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', background: '#ffffff' }}>
                    <div>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>2. Address Proof (Electricity / Ration Card)</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Address: {citizen.address}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.addressProof === 'verified' ? 'btn-success' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('addressProof', 'verified')}
                      >
                        ✓ Verified
                      </button>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.addressProof === 'missing' ? 'btn-danger' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('addressProof', 'missing')}
                      >
                        ✕ Missing
                      </button>
                    </div>
                  </div>

                  {/* Income Proof */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', background: '#ffffff' }}>
                    <div>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>3. Income Proof (Salary Slip / Form 16 / Affidavit)</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Annual Income Declared: ₹2,50,000</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.incomeProof === 'verified' ? 'btn-success' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('incomeProof', 'verified')}
                      >
                        ✓ Mark Verified
                      </button>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.incomeProof === 'missing' ? 'btn-danger' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('incomeProof', 'missing')}
                      >
                        ✕ Missing
                      </button>
                    </div>
                  </div>

                  {/* Passport Photo */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', background: '#ffffff' }}>
                    <div>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>4. Passport Size Photograph</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Physical photo attached to form</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.photo === 'verified' ? 'btn-success' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('photo', 'verified')}
                      >
                        ✓ Verified
                      </button>
                      <button
                        type="button"
                        className={`btn btn-sm ${docVerification.photo === 'missing' ? 'btn-danger' : 'btn-outline'}`}
                        onClick={() => handleDocumentStatus('photo', 'missing')}
                      >
                        ✕ Missing
                      </button>
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                  <button
                    type="button"
                    className="btn btn-success"
                    onClick={() => {
                      setDocVerification('incomeProof', 'verified');
                      advanceApplication();
                    }}
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
                  >
                    <CheckCircle size={18} />
                    Approve All Documents & Advance Application
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Grievances / Correction Requests */}
          {activeTab === 'grievances' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Citizen Correction & Grievance Tickets</h3>
              </div>
              <div className="card-body">
                {grievance ? (
                  <div style={{ border: '1px solid #e2e8f0', borderRadius: '0.5rem', padding: '1.25rem', background: '#fff' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                      <span className="badge badge-warning" style={{ fontSize: '0.85rem' }}>Ticket #{grievance.id || 'GRV-2026-0042'}</span>
                      <span className="badge badge-secondary" style={{ textTransform: 'capitalize' }}>Status: {grievance.status}</span>
                    </div>
                    <div style={{ marginBottom: '1rem' }}>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Error Category</div>
                      <div style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a' }}>{grievance.errorType || 'Name & Document Spelling Correction'}</div>
                    </div>
                    <div style={{ marginBottom: '1rem' }}>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Requested Correction</div>
                      <div style={{ fontSize: '0.92rem', color: '#334155' }}>{grievance.correctInfo || 'Correct name spelling to Rahul Patil'}</div>
                    </div>

                    <div style={{ display: 'flex', gap: '0.75rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                      <button
                        type="button"
                        className="btn btn-sm btn-success"
                        onClick={() => handleOfficerGrievanceAction('resolved')}
                      >
                        ✓ Resolve & Update Document
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        onClick={() => handleOfficerGrievanceAction('rejected')}
                      >
                        ✕ Reject Ticket
                      </button>
                    </div>
                  </div>
                ) : (
                  <p style={{ color: '#64748b', margin: 0, textAlign: 'center', padding: '2rem 0' }}>
                    No pending grievance tickets assigned to Counter 3.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: Urgent Requests */}
          {activeTab === 'urgent' && (
            <div className="card">
              <div className="card-header">
                <h3 style={{ margin: 0 }}>Urgent & Standby Queue Priority Requests</h3>
              </div>
              <div className="card-body">
                {urgentRequest ? (
                  <div style={{ border: '1px solid #e2e8f0', borderRadius: '0.5rem', padding: '1.25rem', background: '#fff' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                      <span className="badge badge-danger" style={{ fontSize: '0.85rem' }}>🚨 URGENT PRIORITY</span>
                      <span className="badge badge-secondary">Status: {urgentRequest.status}</span>
                    </div>
                    <div style={{ marginBottom: '0.75rem' }}>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Urgency Category</div>
                      <div style={{ fontWeight: 700, fontSize: '1rem', color: '#dc2626' }}>{urgentRequest.urgencyType || 'Education Scholarship Deadline'}</div>
                    </div>
                    <div style={{ marginBottom: '1rem' }}>
                      <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Reason Details</div>
                      <div style={{ fontSize: '0.92rem', color: '#334155' }}>{urgentRequest.reason || 'Scholarship submission deadline ends today at 5 PM.'}</div>
                    </div>

                    <div style={{ display: 'flex', gap: '0.75rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                      <button
                        type="button"
                        className="btn btn-sm btn-success"
                        onClick={() => handleOfficerUrgentAction('approved')}
                      >
                        ✓ Grant Express Priority Token
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        onClick={() => handleOfficerUrgentAction('rejected')}
                      >
                        ✕ Reject Priority
                      </button>
                    </div>
                  </div>
                ) : (
                  <p style={{ color: '#64748b', margin: 0, textAlign: 'center', padding: '2rem 0' }}>
                    No active urgent standby requests for Counter 3.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* QR Scanner Simulation Modal */}
      {scanModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 999,
            padding: '1rem',
          }}
          onClick={() => setScanModalOpen(false)}
        >
          <div
            style={{
              background: 'white',
              borderRadius: '1rem',
              padding: '2rem',
              maxWidth: '480px',
              width: '100%',
              boxShadow: '0 20px 25px -5px rgba(0,0,0,0.2)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <QrCode size={22} color="#0284c7" /> Officer QR Verification Scanner
              </h3>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => setScanModalOpen(false)}
              >
                ✕
              </button>
            </div>

            <div
              style={{
                border: '2px dashed #0284c7',
                borderRadius: '0.75rem',
                padding: '2rem 1rem',
                textAlign: 'center',
                background: '#f0f9ff',
                marginBottom: '1.5rem',
              }}
            >
              <QrCode size={64} color="#0284c7" style={{ marginBottom: '0.5rem' }} />
              <div style={{ fontWeight: 600, color: '#0369a1' }}>Point Camera / Scanner at Citizen Token QR</div>
              <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '4px' }}>
                Supports Encrypted Government Verification QR Codes
              </div>
            </div>

            {scannedResult ? (
              <div style={{ background: '#dcfce7', border: '1px solid #86efac', padding: '1rem', borderRadius: '0.5rem', marginBottom: '1.5rem' }}>
                <div style={{ fontWeight: 700, color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
                  <CheckCircle size={18} /> Valid Token Verified!
                </div>
                <div style={{ fontSize: '0.85rem', color: '#14532d' }}>
                  <div>Token: <strong>{scannedResult.tokenNumber}</strong></div>
                  <div>Citizen: <strong>{scannedResult.citizenName}</strong></div>
                  <div>Aadhaar: <strong>{scannedResult.aadhaar}</strong></div>
                  <div>Service: <strong>{scannedResult.service}</strong></div>
                </div>
              </div>
            ) : (
              <button
                type="button"
                className="btn btn-primary btn-block"
                onClick={handleSimulateScan}
                style={{ backgroundColor: '#0284c7', borderColor: '#0284c7', padding: '0.75rem' }}
              >
                ⚡ Simulate Scanning Active Citizen Token (A-042)
              </button>
            )}

            <div style={{ marginTop: '1rem', textAlign: 'right' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setScanModalOpen(false)}
              >
                Close Scanner
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
