import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

/**
 * Reusable Breadcrumb navigation component.
 * Accepts either:
 *   items={[{label, path}]}
 *   paths={[{name, url}]}
 * Last item is shown as the current page (no link).
 */
export default function Breadcrumb({ items, paths }) {
  // Normalize: support both prop formats
  const crumbs = items || (paths || []).map((p) => ({
    label: p.name || p.label,
    path: p.url || p.path,
  }));

  if (!crumbs || crumbs.length === 0) return null;

  return (
    <nav className="breadcrumb" aria-label="Breadcrumb navigation">
      {crumbs.map((item, index) => {
        const isLast = index === crumbs.length - 1;
        const label = item.label || item.name || '';

        return (
          <React.Fragment key={label + index}>
            {index > 0 && (
              <span className="separator" aria-hidden="true">
                <ChevronRight size={14} />
              </span>
            )}
            {isLast || !item.path ? (
              <span className="current" aria-current={isLast ? 'page' : undefined}>
                {label}
              </span>
            ) : (
              <Link to={item.path}>{label}</Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
