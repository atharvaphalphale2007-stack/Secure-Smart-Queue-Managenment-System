import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock, CheckCircle, IndianRupee, Users, Home as HomeIcon,
  MapPin, Baby, FileX, UserCheck, FileCheck, Landmark, Phone, Building, Timer, Hourglass
} from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import { SERVICES, OFFICE_DETAILS } from '../data/mockData';

const getServiceIcon = (iconName) => {
  const icons = {
    IndianRupee,
    Users,
    Home: HomeIcon,
    MapPin,
    Baby,
    FileX,
    UserCheck,
    FileCheck
  };
  const IconComponent = icons[iconName] || FileCheck;
  return <IconComponent size={24} />;
};

const Services = () => {
  const navigate = useNavigate();
  const [selectedService, setSelectedService] = useState(null);

  const handleContinue = () => {
    if (selectedService) {
      navigate('/booking', {
        state: {
          serviceId: selectedService.id,
          serviceName: selectedService.name
        }
      });
    }
  };

  return (
    <div className="page">
      <Breadcrumb paths={[{ name: 'Home', url: '/' }, { name: 'Services' }]} />

      <div className="section">
        <h1 className="page-title">Government Services Catalog</h1>
        <p className="page-subtitle">Select a service to view requirements, estimated document handling times, office address, and book an appointment slot.</p>

        <div className="grid-3">
          {SERVICES.map(service => (
            <div key={service.id} className="service-card card">
              <div className="card-body">
                <div className="service-icon">
                  {getServiceIcon(service.icon)}
                </div>
                <h3>{service.name}</h3>
                <p>{service.description}</p>

                <div style={{ fontSize: '0.82rem', color: '#64748b', marginTop: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <MapPin size={15} color="#0284c7" />
                  <span>Tehsildar Office Complex, Pune</span>
                </div>

                <div className="service-meta" style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', color: '#334155' }}>
                    <Timer size={16} color="#d97706" />
                    <span>Handling Time: <strong>{service.counterHandlingTime || '10-12 mins'}</strong></span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', color: '#334155' }}>
                    <Clock size={16} color="#16a34a" />
                    <span>Certificate Issue: <strong>{service.processingTime}</strong></span>
                  </div>
                </div>

                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => setSelectedService(service)}
                  style={{ width: '100%', marginTop: '12px' }}
                >
                  View Details & Handling Times
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Service Details Modal with Document Handling Times */}
      {selectedService && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '650px', width: '90%', borderRadius: '1rem' }}>
            <div className="modal-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2>{selectedService.name} — Service Details</h2>
              <button className="btn btn-sm btn-outline" onClick={() => setSelectedService(null)}>✕</button>
            </div>
            <div className="modal-body" style={{ maxHeight: '75vh', overflowY: 'auto' }}>

              {/* Estimated Document Handling & Delivery Time Section */}
              <div
                style={{
                  background: 'linear-gradient(135deg, #fef3c7 0%, #fff7ed 100%)',
                  border: '1px solid #fde68a',
                  borderRadius: '0.75rem',
                  padding: '1.25rem',
                  marginBottom: '1.25rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#b45309', fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.75rem' }}>
                  <Timer size={20} color="#d97706" />
                  Estimated Document Handling & Processing Timelines
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div style={{ background: '#ffffff', padding: '0.85rem', borderRadius: '0.5rem', border: '1px solid #fef3c7' }}>
                    <div style={{ fontSize: '0.78rem', color: '#78350f', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Hourglass size={14} color="#d97706" /> Counter Verification Time
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: 800, color: '#d97706', marginTop: '2px' }}>
                      {selectedService.counterHandlingTime || '10 - 15 mins'}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: '#92400e' }}>Average time per citizen at officer desk</div>
                  </div>

                  <div style={{ background: '#ffffff', padding: '0.85rem', borderRadius: '0.5rem', border: '1px solid #fef3c7' }}>
                    <div style={{ fontSize: '0.78rem', color: '#78350f', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Clock size={14} color="#16a34a" /> Certificate Issuance Time
                    </div>
                    <div style={{ fontSize: '1.1rem', fontWeight: 800, color: '#16a34a', marginTop: '2px' }}>
                      {selectedService.processingTime}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: '#92400e' }}>Final digital certificate delivery</div>
                  </div>
                </div>
              </div>

              {/* Government Office Address Box */}
              <div
                style={{
                  background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
                  border: '1px solid #bae6fd',
                  borderRadius: '0.75rem',
                  padding: '1.25rem',
                  marginBottom: '1.25rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#0369a1', fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.75rem' }}>
                  <Landmark size={20} color="#0284c7" />
                  Official Government Office Address for Citizen Visit
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.88rem', color: '#1e293b' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                    <Building size={18} color="#0284c7" style={{ flexShrink: 0, marginTop: '2px' }} />
                    <div>
                      <strong>Office Name:</strong> {OFFICE_DETAILS.name}
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                    <MapPin size={18} color="#dc2626" style={{ flexShrink: 0, marginTop: '2px' }} />
                    <div>
                      <strong>Full Address:</strong> {selectedService.officeAddress || OFFICE_DETAILS.address}
                      <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '2px' }}>
                        📍 Landmark: {selectedService.landmark || OFFICE_DETAILS.landmark}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Clock size={16} color="#d97706" style={{ flexShrink: 0 }} />
                    <div>
                      <strong>Office Working Hours:</strong> {OFFICE_DETAILS.workingHours}
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Phone size={16} color="#16a34a" style={{ flexShrink: 0 }} />
                    <div>
                      <strong>Citizen Helpline:</strong> {OFFICE_DETAILS.helpline}
                    </div>
                  </div>
                </div>
              </div>

              {/* Service Fee */}
              <div className="doc-info" style={{ marginBottom: '1.25rem', display: 'flex', gap: '1.5rem', background: '#f8fafc', padding: '0.85rem 1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                <p style={{ margin: 0 }}><strong>Government Fee:</strong> {selectedService.fee || 'Free'}</p>
                <p style={{ margin: 0 }}><strong>Queue Service Method:</strong> Smart Token QR Routing</p>
              </div>

              {/* Required Documents */}
              <h3 style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Required Documents</h3>
              <div className="doc-checklist-item" style={{ marginBottom: '1.25rem' }}>
                {selectedService.requiredDocs.map((doc, idx) => (
                  <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                    <CheckCircle size={18} className="badge-success" />
                    <span>{doc.name} {doc.xerox > 0 && <span className="badge badge-gray">({doc.xerox} Xerox required)</span>}</span>
                  </div>
                ))}
              </div>

              {/* Xerox Requirements */}
              {selectedService.requiredDocs.some(doc => doc.xerox > 0) && (
                <div style={{ marginBottom: '1.25rem' }}>
                  <h3 style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Xerox Requirements</h3>
                  <ul style={{ paddingLeft: '20px' }}>
                    {selectedService.requiredDocs.filter(doc => doc.xerox > 0).map((doc, idx) => (
                      <li key={idx}>{doc.name}: {doc.xerox} Xerox copy required</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Important Guidelines */}
              {selectedService.guidelines && selectedService.guidelines.length > 0 && (
                <div>
                  <h3 style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Important Guidelines for Visit</h3>
                  <ul style={{ paddingLeft: '20px' }}>
                    {selectedService.guidelines.map((guide, idx) => (
                      <li key={idx} style={{ marginBottom: '4px', fontSize: '0.9rem' }}>{guide}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <div className="modal-footer" style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', paddingTop: '1rem', borderTop: '1px solid #e2e8f0' }}>
              <button className="btn btn-outline" onClick={() => setSelectedService(null)}>Close</button>
              <button className="btn btn-primary" onClick={handleContinue}>Continue to Book Slot</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Services;
