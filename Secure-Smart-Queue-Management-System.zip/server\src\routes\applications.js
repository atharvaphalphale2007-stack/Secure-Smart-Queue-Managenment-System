// Secure Smart Queue Management System — Citizen Application Lifecycle Management
import { Router } from 'express';
import { getDb } from '../db.js';
import { requireRole } from '../middleware/auth.js';
import { logAuditEvent } from '../utils/auditLogger.js';

const router = Router();

// GET /api/applications/me — Citizen's application history
router.get('/me', (req, res) => {
  const db = getDb();
  const applications = db.prepare(`
    SELECT
      a.*,
      s.name AS service_name, s.icon AS service_icon, s.processing_time, s.fee,
      t.token_number, t.queue_status,
      b.slot_date, b.slot_time,
      c.name AS counter_name
    FROM applications a
    JOIN services s ON s.id = a.service_id
    LEFT JOIN tokens t ON t.id = a.token_id
    LEFT JOIN bookings b ON b.id = a.booking_id
    LEFT JOIN counters c ON c.id = b.counter_id
    WHERE a.citizen_id = ?
    ORDER BY a.created_at DESC
  `).all(req.user.id);

  // Attach status history and uploaded documents
  const result = applications.map((app) => {
    const history = db.prepare(`
      SELECT * FROM application_history WHERE application_id = ? ORDER BY id ASC
    `).all(app.id);

    const documents = db.prepare(`
      SELECT id, doc_name, original_name, file_size, mime_type, verification_status, rejection_reason, uploaded_at
      FROM documents WHERE application_id = ?
    `).all(app.id);

    return {
      ...app,
      timeline: history,
      documents,
    };
  });

  res.json(result);
});

// GET /api/applications/:id — Detailed application view
router.get('/:id', (req, res) => {
  const db = getDb();
  const app = db.prepare(`
    SELECT
      a.*,
      s.name AS service_name, s.fee, s.processing_time,
      u.name AS citizen_name, u.email AS citizen_email, u.mobile AS citizen_mobile, u.aadhaar,
      t.token_number, t.queue_status,
      b.slot_date, b.slot_time
    FROM applications a
    JOIN services s ON s.id = a.service_id
    JOIN users u ON u.id = a.citizen_id
    LEFT JOIN tokens t ON t.id = a.token_id
    LEFT JOIN bookings b ON b.id = a.booking_id
    WHERE a.id = ?
  `).get(req.params.id);

  if (!app) return res.status(404).json({ error: 'Application not found' });

  // Ownership verification
  if (req.user.role === 'citizen' && app.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized to view this application' });
  }

  const history = db.prepare('SELECT * FROM application_history WHERE application_id = ? ORDER BY id ASC').all(app.id);
  const documents = db.prepare('SELECT * FROM documents WHERE application_id = ?').all(app.id);

  res.json({
    ...app,
    timeline: history,
    documents,
  });
});

// PATCH /api/applications/:id/status — Advance or update status with mandatory reason
router.patch('/:id/status', requireRole('officer', 'admin'), (req, res) => {
  const { status, reason, notes } = req.body || {};
  if (!status || !reason) {
    return res.status(400).json({ error: 'Target status and mandatory transition reason are required' });
  }

  const allowedStatuses = ['submitted', 'under_verification', 'correction_required', 'resubmitted', 'approved', 'rejected', 'completed'];
  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ error: `Invalid status. Allowed: ${allowedStatuses.join(', ')}` });
  }

  const db = getDb();
  const app = db.prepare('SELECT * FROM applications WHERE id = ?').get(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application not found' });

  const prevStatus = app.status;

  db.transaction(() => {
    db.prepare(`
      UPDATE applications SET
        status = ?,
        officer_notes = COALESCE(?, officer_notes),
        updated_at = datetime('now')
      WHERE id = ?
    `).run(status, notes || null, app.id);

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(app.id, req.user.id, req.user.role, prevStatus, status, reason);

    // Notify citizen
    const message = status === 'approved'
      ? `🎉 Congratulations! Your application for ${app.service_id} has been APPROVED.`
      : status === 'correction_required'
      ? `⚠️ Action Required: Corrections requested for application ${app.id}. Reason: ${reason}`
      : `Application ${app.id} status updated to: ${status.toUpperCase()}.`;

    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, ?)
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      app.citizen_id,
      message,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      status === 'approved' ? 'success' : status === 'correction_required' ? 'warning' : 'info'
    );
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'APPLICATION_STATUS_TRANSITION',
    resourceType: 'application',
    resourceId: app.id,
    details: `Transition from ${prevStatus} -> ${status}. Reason: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, application: db.prepare('SELECT * FROM applications WHERE id = ?').get(app.id) });
});

// POST /api/applications/:id/request-correction — Officer requests specific document correction
router.post('/:id/request-correction', requireRole('officer', 'admin'), (req, res) => {
  const { docName, reason } = req.body || {};
  if (!reason) {
    return res.status(400).json({ error: 'Correction reason is required' });
  }

  const db = getDb();
  const app = db.prepare('SELECT * FROM applications WHERE id = ?').get(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application not found' });

  db.transaction(() => {
    // Update application state
    db.prepare(`
      UPDATE applications SET status = 'correction_required', officer_notes = ?, updated_at = datetime('now') WHERE id = ?
    `).run(`Correction required: ${reason}`, app.id);

    // If specific document, mark status
    if (docName) {
      db.prepare(`
        UPDATE documents SET verification_status = 'correction_needed', rejection_reason = ?
        WHERE application_id = ? AND doc_name = ?
      `).run(reason, app.id, docName);
    }

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      VALUES (?, ?, ?, ?, 'correction_required', ?)
    `).run(app.id, req.user.id, req.user.role, app.status, `Correction requested: ${reason}`);

    // Create Notification
    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, 'warning')
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      app.citizen_id,
      `Action Needed: Document correction required for ${docName || 'your application'}. Reason: ${reason}`,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    );
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'APPLICATION_CORRECTION_REQUESTED',
    resourceType: 'application',
    resourceId: app.id,
    details: `Officer requested correction for ${docName || 'application'}: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: 'Correction request recorded and citizen notified' });
});

// POST /api/applications/:id/resubmit — Citizen re-submits after making corrections
router.post('/:id/resubmit', (req, res) => {
  const { notes } = req.body || {};
  const db = getDb();

  const app = db.prepare('SELECT * FROM applications WHERE id = ?').get(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application not found' });

  if (app.citizen_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Unauthorized to resubmit this application' });
  }

  db.transaction(() => {
    db.prepare(`
      UPDATE applications SET status = 'resubmitted', officer_notes = ?, updated_at = datetime('now') WHERE id = ?
    `).run(notes ? `Citizen resubmitted: ${notes}` : 'Citizen uploaded corrected documents', app.id);

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      VALUES (?, ?, 'citizen', ?, 'resubmitted', ?)
    `).run(app.id, req.user.id, app.status, notes || 'Replacement documents submitted for officer review');
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'APPLICATION_RESUBMITTED',
    resourceType: 'application',
    resourceId: app.id,
    details: 'Citizen resubmitted corrected documents',
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: 'Application re-submitted for officer verification' });
});

export default router;
