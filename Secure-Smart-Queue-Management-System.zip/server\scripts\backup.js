// Secure Smart Queue Management System — Automated Database Backup Script
// Safely checkpoints WAL journal, verifies integrity, copies database, and computes SHA-256 checksum.

import { DatabaseSync } from 'node:sqlite';
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, basename } from 'node:path';
import { createHash } from 'node:crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, '..', 'data');
const BACKUP_DIR = join(__dirname, '..', 'backups');
const DEFAULT_DB_PATH = join(DATA_DIR, 'sqms.db');

export function performBackup(customDbPath = null) {
  const dbPath = customDbPath || process.env.DB_PATH || DEFAULT_DB_PATH;

  if (!existsSync(dbPath)) {
    throw new Error(`Source database file does not exist at ${dbPath}`);
  }

  if (!existsSync(BACKUP_DIR)) {
    mkdirSync(BACKUP_DIR, { recursive: true });
  }

  console.log(`[SQMS-BACKUP] Initiating database backup for: ${dbPath}`);

  // 1. Check integrity and checkpoint WAL
  const db = new DatabaseSync(dbPath);
  try {
    const integrityRow = db.prepare('PRAGMA integrity_check;').get();
    const integrityStatus = integrityRow ? Object.values(integrityRow)[0] : 'unknown';

    if (integrityStatus !== 'ok') {
      throw new Error(`Database integrity check failed: ${integrityStatus}`);
    }

    // Flush WAL log into main DB file
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    console.log(`[SQMS-BACKUP] WAL checkpoint truncated and integrity verified (ok).`);
  } finally {
    db.close();
  }

  // 2. Generate destination filename
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const timestamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  const backupFileName = `sqms_backup_${timestamp}.db`;
  const backupDestPath = join(BACKUP_DIR, backupFileName);
  const metadataDestPath = join(BACKUP_DIR, `sqms_backup_${timestamp}.meta.json`);

  // 3. Copy file
  copyFileSync(dbPath, backupDestPath);

  // 4. Calculate SHA-256 checksum
  const fileBytes = readFileSync(backupDestPath);
  const sha256 = createHash('sha256').update(fileBytes).digest('hex');
  const stats = statSync(backupDestPath);

  const metadata = {
    version: '1.0.0',
    createdAt: now.toISOString(),
    timestamp,
    sourceDatabase: dbPath,
    backupFile: backupFileName,
    bytes: stats.size,
    sha256,
    integrityCheck: 'ok',
  };

  writeFileSync(metadataDestPath, JSON.stringify(metadata, null, 2), 'utf-8');

  console.log(`[SQMS-BACKUP] SUCCESS: Backup created: ${backupFileName} (${stats.size} bytes)`);
  console.log(`[SQMS-BACKUP] Checksum (SHA-256): ${sha256}`);
  console.log(`[SQMS-BACKUP] Metadata: ${basename(metadataDestPath)}`);

  return { backupDestPath, metadataDestPath, metadata };
}

// Standalone execution
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    performBackup();
  } catch (err) {
    console.error(`[SQMS-BACKUP] FAILED:`, err.message);
    process.exit(1);
  }
}
