import React from 'react';

/**
 * Maps arbitrary status keywords to official index.css badge classes.
 * @param {string} status
 * @returns {string}
 */
const getBadgeClass = (status) => {
  if (!status) return 'badge-gray';
  const s = String(status).toLowerCase().trim();

  switch (s) {
    case 'verified':
    case 'completed':
    case 'approved':
    case 'available':
    case 'issued':
    case 'active':
      return 'badge-success';

    case 'missing':
    case 'pending':
    case 'submitted':
    case 'standby':
      return 'badge-warning';

    case 'invalid':
    case 'failed':
    case 'expired':
    case 'rejected':
    case 'error':
      return 'badge-error';

    case 'processing':
    case 'serving':
    case 'in progress':
    case 'busy':
    case 'document verification':
      return 'badge-info';

    case 'break':
      return 'badge-gray';

    default:
      return 'badge-gray';
  }
};

/**
 * Capitalizes each word in the status text.
 * E.g., "in progress" -> "In Progress"
 * @param {string} status
 * @returns {string}
 */
const formatStatus = (status) => {
  if (!status) return '';
  return String(status)
    .trim()
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
};

/**
 * Reusable StatusBadge component.
 * Displays a color-coded pill badge according to standard government portal status design.
 *
 * @param {{ status: string, className?: string }} props
 */
export default function StatusBadge({ status, className = '' }) {
  if (!status) return null;

  const badgeClass = getBadgeClass(status);
  const formattedText = formatStatus(status);

  return (
    <span className={`badge ${badgeClass} ${className}`.trim()}>
      {formattedText}
    </span>
  );
}
