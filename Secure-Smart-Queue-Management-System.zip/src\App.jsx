import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';

// Core entry pages loaded eagerly for instant first paint
import Home from './pages/Home';
import Login from './pages/Login';

// Subpages code-split and loaded on demand for ultra-fast startup
const Services = lazy(() => import('./pages/Services'));
const Booking = lazy(() => import('./pages/Booking'));
const MyToken = lazy(() => import('./pages/MyToken'));
const CheckIn = lazy(() => import('./pages/CheckIn'));
const Queue = lazy(() => import('./pages/Queue'));
const DocumentVerification = lazy(() => import('./pages/DocumentVerification'));
const CounterRouting = lazy(() => import('./pages/CounterRouting'));
const ApplicationStatus = lazy(() => import('./pages/ApplicationStatus'));
const MyDocuments = lazy(() => import('./pages/MyDocuments'));
const Grievance = lazy(() => import('./pages/Grievance'));
const UrgentRequest = lazy(() => import('./pages/UrgentRequest'));
const OfficerDashboard = lazy(() => import('./pages/OfficerDashboard'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));

import RoleSimulatorDock from './components/RoleSimulatorDock';
import Toast from './components/Toast';
import { useAppContext } from './context/AppContext';

const PageLoader = () => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '35vh',
      color: 'var(--primary-800)',
      fontSize: '0.9rem',
      fontWeight: 600,
      gap: '8px',
    }}
  >
    <div
      style={{
        width: '18px',
        height: '18px',
        border: '2px solid #e2e8f0',
        borderTopColor: '#0284c7',
        borderRadius: '50%',
        animation: 'spin 0.6s linear infinite',
      }}
    />
    <span>Loading portal...</span>
  </div>
);

function App() {
  const { toasts = [], removeToast } = useAppContext();

  return (
    <div className="app-layout">
      <Header />
      <Toast toasts={toasts} onDismiss={removeToast} />
      <main className="main-content">
        <Suspense fallback={<PageLoader />}>
          <Routes>
            {/* Public Authentication Route */}
            <Route path="/login" element={<Login />} />

            {/* Citizen Protected Routes */}
            <Route
              path="/"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <Home />
                </ProtectedRoute>
              }
            />
            <Route
              path="/services"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <Services />
                </ProtectedRoute>
              }
            />
            <Route
              path="/booking"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <Booking />
                </ProtectedRoute>
              }
            />
            <Route path="/token" element={<Navigate to="/my-token" replace />} />
            <Route
              path="/my-token"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <MyToken />
                </ProtectedRoute>
              }
            />
            <Route
              path="/check-in"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <CheckIn />
                </ProtectedRoute>
              }
            />
            <Route
              path="/queue"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <Queue />
                </ProtectedRoute>
              }
            />
            <Route
              path="/documents-verification"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <DocumentVerification />
                </ProtectedRoute>
              }
            />
            <Route
              path="/counter"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <CounterRouting />
                </ProtectedRoute>
              }
            />
            <Route
              path="/application-status"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <ApplicationStatus />
                </ProtectedRoute>
              }
            />
            <Route
              path="/my-documents"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <MyDocuments />
                </ProtectedRoute>
              }
            />
            <Route
              path="/grievance"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <Grievance />
                </ProtectedRoute>
              }
            />
            <Route
              path="/urgent-request"
              element={
                <ProtectedRoute allowedRoles={['citizen']}>
                  <UrgentRequest />
                </ProtectedRoute>
              }
            />

            {/* Officer Protected Route */}
            <Route
              path="/officer"
              element={
                <ProtectedRoute allowedRoles={['officer']}>
                  <OfficerDashboard />
                </ProtectedRoute>
              }
            />

            {/* Admin Protected Route */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <AdminDashboard />
                </ProtectedRoute>
              }
            />

            {/* Catch-all redirect to Login */}
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </Suspense>
      </main>
      <RoleSimulatorDock />
      <Footer />
    </div>
  );
}

export default App;
