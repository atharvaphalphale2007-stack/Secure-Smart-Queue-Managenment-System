import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Send, Upload, CheckCircle, Circle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import { ERROR_TYPES } from '../data/mockData';

const Grievance = () => {
  const { grievance, submitGrievance } = useAppContext();
  const [isSubmitted, setIsSubmitted] = useState(!!grievance);
  
  const [appId, setAppId] = useState('APP-2026-0925-0042');
  const [docType, setDocType] = useState('Income Certificate');
  const [errorType, setErrorType] = useState('');
  const [correctInfo, setCorrectInfo] = useState('');
  const [description, setDescription] = useState('');
  
  const [toastMessage, setToastMessage] = useState('');

  const handleUploadClick = () => {
    setToastMessage('File upload simulated for demo');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!errorType || !description) {
      setToastMessage('Please fill all required fields');
      setTimeout(() => setToastMessage(''), 3000);
      return;
    }
    
    submitGrievance({
      id: 'GRV-2026-0042',
      appId,
      docType,
      errorType,
      correctInfo,
      description,
      status: 'submitted'
    });
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setErrorType('');
    setCorrectInfo('');
    setDescription('');
  };

  return (
    <div className="main-content">
      <Breadcrumb items={[{ label: 'Home', path: '/' }, { label: 'Raise Grievance' }]} />
      <div className="section">
        <h1 className="page-title">Raise Grievance / Request Correction</h1>
        <p className="page-subtitle">Submit a correction request for any errors in your issued documents.</p>

        {!isSubmitted ? (
          <div className="card">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="grid-2">
                  <div className="form-group">
                    <label>Application ID</label>
                    <input type="text" className="form-control" value={appId} onChange={(e) => setAppId(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label>Document Type</label>
                    <select className="form-control" value={docType} onChange={(e) => setDocType(e.target.value)}>
                      <option value="Income Certificate">Income Certificate</option>
                      <option value="Caste Certificate">Caste Certificate</option>
                      <option value="Residence Certificate">Residence Certificate</option>
                      <option value="Birth Certificate">Birth Certificate</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label>Error Type *</label>
                  <select className="form-control" value={errorType} onChange={(e) => setErrorType(e.target.value)} required>
                    <option value="">Select error type...</option>
                    {ERROR_TYPES.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Correct Information</label>
                  <input type="text" className="form-control" value={correctInfo} onChange={(e) => setCorrectInfo(e.target.value)} placeholder="Enter the correct information" />
                </div>

                <div className="form-group">
                  <label>Description *</label>
                  <textarea 
                    className="form-control" 
                    rows="4" 
                    value={description} 
                    onChange={(e) => setDescription(e.target.value)} 
                    placeholder="Describe the error and what correction is needed..."
                    required
                  ></textarea>
                </div>

                <div className="form-group">
                  <label>Upload Supporting Proof</label>
                  <div className="upload-area" onClick={handleUploadClick} style={{ cursor: 'pointer', border: '2px dashed #cbd5e1', padding: '2rem', textAlign: 'center', borderRadius: '0.5rem' }}>
                    <Upload size={32} color="#94a3b8" style={{ margin: '0 auto 0.5rem' }} />
                    <p style={{ margin: 0, fontWeight: '500' }}>Drag & drop file or choose file</p>
                    <p style={{ margin: '0.25rem 0 0', fontSize: '0.8rem', color: '#64748b' }}>PDF, JPG, PNG (Max 5MB)</p>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary btn-lg" style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Send size={18} /> Submit Correction Request
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="grid-2">
            <div className="card">
              <div className="card-body" style={{ textAlign: 'center', padding: '3rem 1rem' }}>
                <CheckCircle size={64} color="#10b981" style={{ margin: '0 auto 1rem' }} />
                <h3 style={{ color: '#10b981', marginBottom: '0.5rem' }}>✓ Grievance Submitted</h3>
                <p>Your correction request has been successfully registered.</p>
                <div style={{ marginTop: '1rem', padding: '0.75rem', backgroundColor: '#f1f5f9', borderRadius: '0.5rem', display: 'inline-block' }}>
                  <strong>Grievance ID:</strong> GRV-2026-0042
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header">
                <h3>Tracking Timeline</h3>
              </div>
              <div className="card-body">
                <div className="timeline">
                  <div className="timeline-step">
                    <div className="timeline-marker"><CheckCircle size={20} color="#10b981" /></div>
                    <div className="step-content">
                      <h4 style={{ margin: '0 0 0.25rem' }}>Submitted</h4>
                      <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b' }}>Your grievance has been registered</p>
                    </div>
                  </div>
                  <div className="timeline-step">
                    <div className="timeline-marker"><Circle size={20} color="#3b82f6" fill="#3b82f6" /></div>
                    <div className="step-content">
                      <h4 style={{ margin: '0 0 0.25rem' }}>Under Verification</h4>
                      <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b' }}>Being reviewed by the concerned officer</p>
                    </div>
                  </div>
                  <div className="timeline-step" style={{ opacity: 0.5 }}>
                    <div className="timeline-marker"><Circle size={20} color="#cbd5e1" /></div>
                    <div className="step-content">
                      <h4 style={{ margin: '0 0 0.25rem' }}>Approved / Rejected</h4>
                      <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b' }}>Pending decision</p>
                    </div>
                  </div>
                  <div className="timeline-step" style={{ opacity: 0.5 }}>
                    <div className="timeline-marker"><Circle size={20} color="#cbd5e1" /></div>
                    <div className="step-content">
                      <h4 style={{ margin: '0 0 0.25rem' }}>Corrected Document</h4>
                      <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b' }}>Pending issuance</p>
                    </div>
                  </div>
                </div>

                <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem' }}>
                  <button className="btn btn-secondary" onClick={handleReset}>Submit Another Grievance</button>
                  <Link to="/" className="btn btn-outline">Go to Home</Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {toastMessage && (
        <div className="toast-container">
          <div className="toast toast-success">{toastMessage}</div>
        </div>
      )}
    </div>
  );
};

export default Grievance;
