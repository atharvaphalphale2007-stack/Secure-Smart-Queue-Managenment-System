// Secure Smart Queue Management System — Appointments & Booking Engine
// Atomic slot booking, capacity enforcement, double-booking prevention, cancellation & rescheduling.

import { Router } from 'express';
import { getDb } from '../db.js';
import { logAuditEvent } from '../utils/auditLogger.js';
import { generateQrPayload } from '../utils/qrCrypto.js';

const router = Router();
const COUNTER_PREFIX = { 1: 'B', 2: 'R', 3: 'A', 4: 'C', 5: 'S' };

function uid(len = 6) {
  return Math.random().toString(36).slice(2, 2 + len).toUpperCase();
}

function nextTokenNumber(db, prefix) {
  const row = db.prepare(
    "SELECT MAX(CAST(SUBSTR(token_number, 3) AS INTEGER)) AS m FROM tokens WHERE token_number LIKE ?"
  ).get(`${prefix}-%`);
  const n = (row && row.m) ? row.m : 0;
  return `${prefix}-${String(n + 1).padStart(3, '0')}`;
}

function isWeekend(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDay();
  return day === 0 || day === 6; // Sunday or Saturday
}

// GET /api/booking/slots — Calculate real slot availability and remaining capacity
router.get('/slots', (req, res) => {
  const { date, serviceId, officeId = 'OFFICE-PUNE-01' } = req.query;
  if (!date) {
    return res.status(400).json({ error: 'date query parameter is required (YYYY-MM-DD)' });
  }

  const db = getDb();

  // 1. Check if office is closed on weekend
  if (isWeekend(date)) {
    return res.json({
      date,
      closed: true,
      reason: 'Government offices are closed on weekends (Saturday & Sunday)',
      slots: [],
    });
  }

  // 2. Check if date is an official holiday
  const holiday = db.prepare('SELECT title, description FROM holidays WHERE office_id = ? AND date = ?')
    .get(officeId, date);
  if (holiday) {
    return res.json({
      date,
      closed: true,
      reason: `Official Holiday: ${holiday.title}`,
      slots: [],
    });
  }

  // 3. Get counter for service
  let counterId = 3;
  if (serviceId) {
    const map = db.prepare('SELECT counter_id FROM service_counter_map WHERE service_id = ?').get(serviceId);
    if (map) counterId = map.counter_id;
  }

  // 4. Fetch all active time slots with their configured capacity
  const timeSlots = db.prepare('SELECT * FROM time_slots WHERE is_active = 1 ORDER BY id').all();

  // 5. Count active bookings per slot on this date
  const bookedCounts = db.prepare(`
    SELECT slot_time, COUNT(*) AS count
    FROM bookings
    WHERE slot_date = ? AND counter_id = ? AND status = 'booked'
    GROUP BY slot_time
  `).all(date, counterId);

  const bookedMap = new Map(bookedCounts.map((r) => [r.slot_time, r.count]));

  const slots = timeSlots.map((slot) => {
    const booked = bookedMap.get(slot.time) || 0;
    const capacity = slot.max_capacity || 3;
    const remaining = Math.max(0, capacity - booked);

    return {
      id: slot.id,
      time: slot.time,
      label: slot.label,
      capacity,
      bookedCount: booked,
      remainingSeats: remaining,
      available: remaining > 0,
      status: remaining === 0 ? 'unavailable' : remaining === 1 ? 'limited' : 'available',
    };
  });

  res.json({
    date,
    closed: false,
    counterId,
    slots,
  });
});

// POST /api/booking — Create booking + token (Atomic Transaction)
router.post('/', (req, res) => {
  const serviceId = req.body?.serviceId || req.body?.service_id;
  const slotDate = req.body?.slotDate || req.body?.appointment_date || req.body?.slot_date;
  const slotTime = req.body?.slotTime || req.body?.time_slot || req.body?.slot_time;
  const slotLabel = req.body?.slotLabel || req.body?.slot_label || slotTime;
  const officeId = req.body?.officeId || req.body?.office_id || 'OFFICE-PUNE-01';
  const citizenId = req.user.id;

  if (!serviceId || !slotDate || !slotTime) {
    return res.status(400).json({ error: 'serviceId, slotDate, and slotTime are required' });
  }

  // Validation: Check past date
  const today = new Date().toISOString().slice(0, 10);
  if (slotDate < today) {
    return res.status(400).json({ error: 'Cannot book appointments in the past' });
  }

  // Validation: Weekend check
  if (isWeekend(slotDate)) {
    return res.status(400).json({ error: 'Cannot book on weekends. Office operates Monday through Friday.' });
  }

  const db = getDb();

  // Validation: Holiday check
  const holiday = db.prepare('SELECT title FROM holidays WHERE office_id = ? AND date = ?').get(officeId, slotDate);
  if (holiday) {
    return res.status(400).json({ error: `Selected date is a government holiday: ${holiday.title}` });
  }

  // Validation: Service check
  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(serviceId);
  if (!service) return res.status(404).json({ error: 'Government service not found' });

  // Determine Counter
  const mapping = db.prepare('SELECT counter_id FROM service_counter_map WHERE service_id = ?').get(serviceId);
  const counterId = mapping ? mapping.counter_id : 3;
  const prefix = COUNTER_PREFIX[counterId] || 'A';

  // ATOMIC TRANSACTION: Check slot capacity & insert booking + token + application
  let bookingRecord;
  let tokenRecord;
  let applicationRecord;

  try {
    db.transaction(() => {
      // 1. Prevent duplicate active booking by same citizen for same service on same day
      const existingCitizenBooking = db.prepare(`
        SELECT id FROM bookings
        WHERE citizen_id = ? AND service_id = ? AND slot_date = ? AND status = 'booked'
      `).get(citizenId, serviceId, slotDate);

      if (existingCitizenBooking) {
        throw new Error('DUPLICATE_BOOKING: You already have an active appointment for this service on this date.');
      }

      // 2. Check slot capacity lock
      const slotDef = db.prepare('SELECT max_capacity FROM time_slots WHERE time = ?').get(slotTime);
      const maxCapacity = slotDef?.max_capacity || 3;

      const currentBookings = db.prepare(`
        SELECT COUNT(*) AS c FROM bookings
        WHERE slot_date = ? AND slot_time = ? AND counter_id = ? AND status = 'booked'
      `).get(slotDate, slotTime, counterId)?.c || 0;

      if (currentBookings >= maxCapacity) {
        throw new Error('SLOT_FULL: Selected time slot is fully booked. Please select another slot.');
      }

      // 3. Generate Unique References
      const bookingId = `BK-${new Date().getFullYear()}-${uid(6)}`;
      const tokenId = `TK-${new Date().getFullYear()}-${uid(6)}`;
      const tokenNumber = nextTokenNumber(db, prefix);
      const appId = `APP-${new Date().getFullYear()}-${slotDate.replace(/-/g, '')}-${tokenNumber.replace('-', '')}`;

      // 4. Generate Cryptographic QR Payload with HMAC-SHA256 signature
      const qrData = generateQrPayload({
        tokenId,
        tokenNumber,
        officeId,
        serviceId,
        expiryMinutes: 1440, // 24 hours
      });

      // 5. Insert Booking
      db.prepare(`
        INSERT INTO bookings (
          id, citizen_id, service_id, office_id, slot_date, slot_time, slot_label, counter_id, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'booked')
      `).run(bookingId, citizenId, serviceId, officeId, slotDate, slotTime, slotLabel || slotTime, counterId);

      // 6. Insert Token
      db.prepare(`
        INSERT INTO tokens (
          id, token_number, booking_id, citizen_id, service_id, office_id, counter_id,
          qr_payload, qr_signature, queue_status, priority_type
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', 'normal')
      `).run(tokenId, tokenNumber, bookingId, citizenId, serviceId, officeId, counterId, qrData.qrString, qrData.signature);

      // 7. Insert Token Reminders tracking row
      db.prepare('INSERT OR IGNORE INTO token_reminders (token_number) VALUES (?)').run(tokenNumber);

      // 8. Insert Citizen Application
      db.prepare(`
        INSERT INTO applications (
          id, citizen_id, service_id, booking_id, token_id, status, officer_notes
        ) VALUES (?, ?, ?, ?, ?, 'submitted', 'Appointment booked by citizen')
      `).run(appId, citizenId, serviceId, bookingId, tokenId);

      // 9. Insert Application History Audit
      db.prepare(`
        INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
        VALUES (?, ?, 'citizen', 'none', 'submitted', 'Appointment confirmed and token allocated')
      `).run(appId, citizenId);

      // 10. Create In-App Notification
      const notifId = `NOTIF-${uid(8)}`;
      db.prepare(`
        INSERT INTO notifications (id, user_id, message, time, read, type)
        VALUES (?, ?, ?, ?, 0, 'success')
      `).run(
        notifId,
        citizenId,
        `Token ${tokenNumber} confirmed for ${service.name} at Counter ${counterId} on ${slotDate} (${slotTime}).`,
        new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
      );

      bookingRecord = db.prepare('SELECT * FROM bookings WHERE id = ?').get(bookingId);
      tokenRecord = db.prepare('SELECT * FROM tokens WHERE id = ?').get(tokenId);
      applicationRecord = db.prepare('SELECT * FROM applications WHERE id = ?').get(appId);
    });

    logAuditEvent({
      actorId: citizenId,
      actorRole: req.user.role,
      action: 'BOOKING_CREATED',
      resourceType: 'booking',
      resourceId: bookingRecord.id,
      details: `Booked ${service.name} for ${slotDate} at slot ${slotTime}. Token: ${tokenRecord.token_number}`,
      ipAddress: req.ip || '127.0.0.1',
      status: 'SUCCESS',
    });

    const enrichedBooking = {
      ...bookingRecord,
      appointment_date: bookingRecord.slot_date,
      time_slot: bookingRecord.slot_time,
      token_number: tokenRecord.token_number,
    };

    res.status(201).json({
      success: true,
      booking: enrichedBooking,
      token: tokenRecord,
      application: applicationRecord,
    });
  } catch (err) {
    if (err.message?.includes('DUPLICATE_BOOKING')) {
      return res.status(409).json({ error: err.message.replace('DUPLICATE_BOOKING: ', '') });
    }
    if (err.message?.includes('SLOT_FULL')) {
      return res.status(409).json({ error: err.message.replace('SLOT_FULL: ', '') });
    }
    res.status(500).json({ error: 'Failed to process booking: ' + err.message });
  }
});

// GET /api/booking/me — Return current citizen's bookings and allocated tokens
router.get('/me', (req, res) => {
  const db = getDb();
  const rows = db.prepare(`
    SELECT
      b.*,
      s.name AS service_name,
      s.icon AS service_icon,
      s.fee AS service_fee,
      t.id AS token_id,
      t.token_number,
      t.qr_payload,
      t.queue_status,
      t.priority_type,
      t.stage1_verified_at,
      t.stage2_verified_at,
      c.name AS counter_name,
      a.id AS application_id,
      a.status AS application_status
    FROM bookings b
    JOIN services s ON s.id = b.service_id
    JOIN counters c ON c.id = b.counter_id
    LEFT JOIN tokens t ON t.booking_id = b.id
    LEFT JOIN applications a ON a.booking_id = b.id
    WHERE b.citizen_id = ?
    ORDER BY b.created_at DESC
  `).all(req.user.id);

  res.json(rows);
});

// POST /api/booking/:id/cancel — Cancel an appointment and release capacity
router.post('/:id/cancel', (req, res) => {
  const { reason = 'Cancelled by citizen' } = req.body || {};
  const db = getDb();

  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  // Ownership verification
  if (req.user.role === 'citizen' && booking.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized to cancel another citizen\'s appointment' });
  }

  if (booking.status === 'cancelled') {
    return res.status(400).json({ error: 'Appointment is already cancelled' });
  }
  if (booking.status === 'completed') {
    return res.status(400).json({ error: 'Cannot cancel a completed service appointment' });
  }

  db.transaction(() => {
    db.prepare(`
      UPDATE bookings
      SET status = 'cancelled', cancel_reason = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(reason, req.params.id);

    db.prepare(`
      UPDATE tokens
      SET queue_status = 'cancelled'
      WHERE booking_id = ?
    `).run(req.params.id);

    // Update application if present
    db.prepare(`
      UPDATE applications
      SET status = 'rejected', officer_notes = ?, updated_at = datetime('now')
      WHERE booking_id = ?
    `).run(`Booking cancelled: ${reason}`, req.params.id);
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'BOOKING_CANCELLED',
    resourceType: 'booking',
    resourceId: req.params.id,
    details: `Cancelled appointment ${req.params.id}. Reason: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: 'Appointment successfully cancelled' });
});

// POST /api/booking/:id/reschedule — Reschedule appointment to a new date/slot
router.post('/:id/reschedule', (req, res) => {
  const newDate = req.body?.newDate || req.body?.new_date;
  const newSlotTime = req.body?.newSlotTime || req.body?.new_slot || req.body?.new_slot_time;
  if (!newDate || !newSlotTime) {
    return res.status(400).json({ error: 'newDate and newSlotTime are required' });
  }

  const db = getDb();
  const oldBooking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!oldBooking) return res.status(404).json({ error: 'Existing booking not found' });

  if (req.user.role === 'citizen' && oldBooking.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized to reschedule another citizen\'s appointment' });
  }

  let newBooking;
  try {
    db.transaction(() => {
      // Check capacity of new slot
      const currentBookings = db.prepare(`
        SELECT COUNT(*) AS c FROM bookings
        WHERE slot_date = ? AND slot_time = ? AND counter_id = ? AND status = 'booked'
      `).get(newDate, newSlotTime, oldBooking.counter_id)?.c || 0;

      const slotDef = db.prepare('SELECT max_capacity FROM time_slots WHERE time = ?').get(newSlotTime);
      const maxCapacity = slotDef?.max_capacity || 3;

      if (currentBookings >= maxCapacity) {
        throw new Error('Target time slot is fully booked. Please select another slot.');
      }

      // Mark old booking rescheduled
      db.prepare(`
        UPDATE bookings SET status = 'rescheduled', updated_at = datetime('now') WHERE id = ?
      `).run(oldBooking.id);

      db.prepare(`
        UPDATE tokens SET queue_status = 'rescheduled' WHERE booking_id = ?
      `).run(oldBooking.id);

      // Create new booking
      const newBookingId = `BK-${new Date().getFullYear()}-${uid(6)}`;
      const newTokenId = `TK-${new Date().getFullYear()}-${uid(6)}`;
      const prefix = COUNTER_PREFIX[oldBooking.counter_id] || 'A';
      const newTokenNumber = nextTokenNumber(db, prefix);

      const qr = generateQrPayload({
        tokenId: newTokenId,
        tokenNumber: newTokenNumber,
        officeId: oldBooking.office_id,
        serviceId: oldBooking.service_id,
      });

      db.prepare(`
        INSERT INTO bookings (
          id, citizen_id, service_id, office_id, slot_date, slot_time, slot_label, counter_id,
          status, rescheduled_from_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'booked', ?)
      `).run(
        newBookingId, oldBooking.citizen_id, oldBooking.service_id, oldBooking.office_id,
        newDate, newSlotTime, newSlotTime, oldBooking.counter_id, oldBooking.id
      );

      db.prepare(`
        INSERT INTO tokens (
          id, token_number, booking_id, citizen_id, service_id, office_id, counter_id,
          qr_payload, qr_signature, queue_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
      `).run(
        newTokenId, newTokenNumber, newBookingId, oldBooking.citizen_id, oldBooking.service_id,
        oldBooking.office_id, oldBooking.counter_id, qr.qrString, qr.signature
      );

      newBooking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(newBookingId);
    });

    logAuditEvent({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: 'BOOKING_RESCHEDULED',
      resourceType: 'booking',
      resourceId: newBooking.id,
      details: `Rescheduled from ${oldBooking.slot_date} (${oldBooking.slot_time}) to ${newDate} (${newSlotTime})`,
      ipAddress: req.ip || '127.0.0.1',
      status: 'SUCCESS',
    });

    res.json({
      success: true,
      booking: {
        ...newBooking,
        appointment_date: newBooking.slot_date,
        time_slot: newBooking.slot_time,
      },
    });
  } catch (err) {
    res.status(409).json({ error: err.message });
  }
});

export default router;