import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { Ticket, Download, Radio, ScanLine } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import Toast from '../components/Toast';
import { generateTokenId, buildQRString } from '../utils/helpers';

const Token = () => {
  const { booking, token, setToken } = useAppContext();
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    if (booking && !token) {
      const tokenNumber = 'A-042';
      const tokenId = generateTokenId();
      
      const newToken = {
        tokenId,
        tokenNumber,
        service: booking.serviceName,
        date: booking.date,
        time: booking.timeSlot.split(' - ')[0],
        counter: 3,
        counterName: 'Counter 3',
        qrString: buildQRString(tokenNumber, booking.dateISO, booking.serviceId)
      };
      
      setToken(newToken);
    }
  }, [booking, token, setToken]);

  const handleDownload = () => {
    setToasts([...toasts, { id: Date.now(), message: 'Token download simulated', type: 'info' }]);
  };

  if (!booking) {
    return (
      <div className="page">
        <div className="alert alert-warning">
          You haven't booked any service. <Link to="/services">Book a Service</Link>
        </div>
      </div>
    );
  }

  if (!token) return null; // loading state essentially

  return (
    <div className="page">
      <Breadcrumb paths={[{ name: 'Home', url: '/' }, { name: 'Token' }]} />
      
      <div className="alert alert-success" style={{ marginBottom: '20px' }}>
        ✓ Booking Confirmed! Your token has been generated.
      </div>

      <div className="card token-card" style={{ maxWidth: '600px', margin: '0 auto' }}>
        <div className="card-body">
          <div className="token-label">YOUR TOKEN</div>
          <div className="token-number">{token.tokenNumber}</div>
          
          <div className="token-details" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', margin: '20px 0' }}>
            <div className="token-detail-item">
              <small>Token ID</small><br />
              <strong>{token.tokenId}</strong>
            </div>
            <div className="token-detail-item">
              <small>Service</small><br />
              <strong>{token.service}</strong>
            </div>
            <div className="token-detail-item">
              <small>Date</small><br />
              <strong>{token.date}</strong>
            </div>
            <div className="token-detail-item">
              <small>Time</small><br />
              <strong>{token.time}</strong>
            </div>
            <div className="token-detail-item">
              <small>Counter</small><br />
              <strong>{token.counterName}</strong>
            </div>
            <div className="token-detail-item">
              <small>Office</small><br />
              <strong>Government Citizen Service Centre</strong>
            </div>
          </div>

          <div className="qr-card" style={{ textAlign: 'center', margin: '20px 0' }}>
            <QRCodeSVG value={token.qrString} size={180} />
            <div className="qr-demo-label" style={{ marginTop: '10px', color: '#666' }}>Demo QR Code — Prototype Only</div>
            <p style={{ fontSize: '14px', marginTop: '5px' }}>Show this QR code at the office check-in counter.</p>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', justifyContent: 'center', marginTop: '20px' }}>
            <Link to="/my-token" className="btn btn-primary">
              <Ticket size={18} /> View My Token
            </Link>
            <button className="btn btn-secondary" onClick={handleDownload}>
              <Download size={18} /> Download Token
            </button>
            <Link to="/queue" className="btn btn-outline">
              <Radio size={18} /> Track Queue
            </Link>
            <Link to="/check-in" className="btn btn-success">
              <ScanLine size={18} /> Check-in
            </Link>
          </div>
        </div>
      </div>

      <Toast toasts={toasts} onDismiss={(id) => setToasts(prev => prev.filter(t => t.id !== id))} />
    </div>
  );
};

export default Token;
