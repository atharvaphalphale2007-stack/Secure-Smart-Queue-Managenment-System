// ---------- Government Office Location & Details ----------
export const OFFICE_DETAILS = {
  name: 'Tehsildar & Sub-Divisional Administrative Complex',
  address: 'District Revenue Office, Main Administrative Building, Near Central Railway Station, Pune, Maharashtra — 411001',
  counterLocation: 'Building B, Ground Floor, Counters 1 to 5',
  landmark: 'Opposite District Court, Near Railway Station Metro Station',
  workingHours: 'Monday to Friday: 09:00 AM – 05:00 PM (Saturday & Sunday Closed)',
  helpline: '020-2612XXXX / Toll-Free Helpline: 1800-233-4567',
  email: 'helpdesk.tehsildar@mah.gov.in',
};

// ---------- Citizen Profile ----------
export const CITIZEN = {
  name: 'Rahul Patil',
  mobile: '98XXXXXX42',
  email: 'rahul.patil@example.com',
  address: 'Pune, Maharashtra',
  aadhaar: 'XXXX-XXXX-4242',
};

// ---------- Government Services Catalog ----------
export const SERVICES = [
  {
    id: 'income',
    name: 'Income Certificate',
    description: 'Certificate of annual income issued by the Tehsildar office.',
    officeAddress: 'Tehsildar Office, Building B, Ground Floor, Counter 3, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    icon: 'IndianRupee',
    processingTime: '3-5 working days',
    counterHandlingTime: '10 - 12 mins at counter',
    fee: '₹25',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'Address Proof', xerox: 1 },
      { name: 'Income Proof (Salary Slip / Form 16 / Affidavit)', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
      { name: 'Application Form', xerox: 0 },
    ],
    guidelines: [
      'Bring original documents for verification.',
      'Carry required Xerox copies.',
      'Ensure documents are clearly readable.',
      'Reach the office before the assigned time.',
      'Keep your token QR code ready on phone or printout.',
    ],
  },
  {
    id: 'caste',
    name: 'Caste Certificate',
    description: 'Certificate confirming the caste category of the applicant.',
    icon: 'Users',
    processingTime: '5-7 working days',
    counterHandlingTime: '12 - 15 mins at counter',
    fee: '₹25',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'School Leaving Certificate', xerox: 1 },
      { name: "Father's Caste Certificate", xerox: 1 },
      { name: 'Ration Card', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
    ],
    guidelines: [
      'Bring original documents for verification.',
      'Father\'s or family caste certificate is mandatory.',
      'Carry required Xerox copies.',
      'Reach the office before the assigned time.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'residence',
    name: 'Residence Certificate',
    description: 'Certificate verifying permanent residence in the district.',
    icon: 'Home',
    processingTime: '3-5 working days',
    counterHandlingTime: '8 - 10 mins at counter',
    fee: '₹25',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'Electricity Bill / Gas Bill', xerox: 1 },
      { name: 'Ration Card', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
    ],
    guidelines: [
      'Address proof must be of the current residence.',
      'Bring original documents.',
      'Carry required Xerox copies.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'domicile',
    name: 'Domicile Certificate',
    description: 'Certificate proving domicile status in the state of Maharashtra.',
    icon: 'MapPin',
    processingTime: '7-10 working days',
    counterHandlingTime: '15 - 20 mins at counter',
    fee: '₹50',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'School Leaving Certificate', xerox: 1 },
      { name: 'Residence Proof (15 years)', xerox: 1 },
      { name: 'Birth Certificate', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
    ],
    guidelines: [
      'Proof of 15 years of continuous residence is required.',
      'Bring original documents.',
      'Carry required Xerox copies.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'birth',
    name: 'Birth Certificate',
    description: 'Official certificate recording date and place of birth.',
    icon: 'Baby',
    processingTime: '5-7 working days',
    counterHandlingTime: '8 - 10 mins at counter',
    fee: '₹10',
    requiredDocs: [
      { name: 'Hospital Birth Record', xerox: 1 },
      { name: "Parent's Aadhaar Card", xerox: 1 },
      { name: 'Marriage Certificate of Parents', xerox: 1 },
      { name: 'Application Form', xerox: 0 },
    ],
    guidelines: [
      'Hospital record is mandatory for recent births.',
      'Affidavit required for delayed registration.',
      'Bring original documents.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'death',
    name: 'Death Certificate',
    description: 'Official certificate recording date and cause of death.',
    icon: 'FileX',
    processingTime: '5-7 working days',
    counterHandlingTime: '8 - 10 mins at counter',
    fee: '₹10',
    requiredDocs: [
      { name: 'Hospital Death Record', xerox: 1 },
      { name: "Deceased's Aadhaar Card", xerox: 1 },
      { name: "Applicant's Aadhaar Card", xerox: 1 },
      { name: 'Application Form', xerox: 0 },
    ],
    guidelines: [
      'Hospital death record is mandatory.',
      'Affidavit required for delayed registration.',
      'Bring original documents.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'senior',
    name: 'Senior Citizen Certificate',
    description: 'Identity certificate for citizens aged 60 years and above.',
    icon: 'UserCheck',
    processingTime: '3-5 working days',
    counterHandlingTime: '5 - 8 mins at counter',
    fee: 'Free',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'Age Proof (Birth Certificate / School LC)', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
    ],
    guidelines: [
      'Applicant must be 60 years of age or older.',
      'Bring original documents.',
      'Keep your token QR code ready.',
    ],
  },
  {
    id: 'ncl',
    name: 'Non-Creamy Layer Certificate',
    description: 'Certificate confirming non-creamy layer status for OBC category.',
    icon: 'FileCheck',
    processingTime: '7-10 working days',
    counterHandlingTime: '12 - 15 mins at counter',
    fee: '₹50',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1 },
      { name: 'Caste Certificate', xerox: 1 },
      { name: 'Income Proof of Parents', xerox: 1 },
      { name: 'Ration Card', xerox: 1 },
      { name: 'Passport Size Photo', xerox: 0 },
    ],
    guidelines: [
      'Parent\'s income proof is mandatory.',
      'Valid caste certificate required.',
      'Bring original documents.',
      'Keep your token QR code ready.',
    ],
  },
];


// ---------- Counters & Officers ----------
export const COUNTERS = [
  { id: 1, name: 'Counter 1', service: 'Birth Certificate', serviceId: 'birth', officer: 'Amit Joshi', currentToken: 'B-023', status: 'Serving' },
  { id: 2, name: 'Counter 2', service: 'Residence Certificate', serviceId: 'residence', officer: 'Neha Patil', currentToken: null, status: 'Available' },
  { id: 3, name: 'Counter 3', service: 'Income Certificate', serviceId: 'income', officer: 'Ms. Priya Sharma', currentToken: 'A-035', status: 'Serving' },
  { id: 4, name: 'Counter 4', service: 'Caste Certificate', serviceId: 'caste', officer: 'Rahul Deshmukh', currentToken: 'C-018', status: 'Busy' },
  { id: 5, name: 'Counter 5', service: 'General Services', serviceId: 'general', officer: 'Sneha Kulkarni', currentToken: null, status: 'Available' },
];

// ---------- Service → Counter Mapping ----------
export const SERVICE_COUNTER_MAP = {
  income: 3,
  caste: 4,
  birth: 1,
  residence: 2,
  domicile: 4,
  death: 1,
  senior: 5,
  ncl: 4,
  general: 5,
};

// ---------- Time Slots ----------
export const TIME_SLOTS = [
  { time: '09:00 AM - 09:30 AM', label: '09:00 AM' },
  { time: '09:30 AM - 10:00 AM', label: '09:30 AM' },
  { time: '10:00 AM - 10:30 AM', label: '10:00 AM' },
  { time: '10:30 AM - 11:00 AM', label: '10:30 AM' },
  { time: '11:00 AM - 11:30 AM', label: '11:00 AM' },
  { time: '11:30 AM - 12:00 PM', label: '11:30 AM' },
  { time: '12:00 PM - 12:30 PM', label: '12:00 PM' },
  { time: '02:00 PM - 02:30 PM', label: '02:00 PM' },
  { time: '02:30 PM - 03:00 PM', label: '02:30 PM' },
  { time: '03:00 PM - 03:30 PM', label: '03:00 PM' },
];

// ---------- Queue Data ----------
export const QUEUE_TOKENS = ['A-036', 'A-037', 'A-038', 'A-039', 'A-040', 'A-041', 'A-042'];

// ---------- Notifications ----------
export const INITIAL_NOTIFICATIONS = [
  { id: 1, message: 'Your token A-042 is approaching.', time: '2 min ago', read: false, type: 'info' },
  { id: 2, message: 'Document verification completed.', time: '15 min ago', read: false, type: 'success' },
  { id: 3, message: 'Your application is currently being processed.', time: '1 hour ago', read: true, type: 'info' },
  { id: 4, message: 'Your Income Certificate has been issued.', time: '2 hours ago', read: true, type: 'success' },
  { id: 5, message: 'Grievance GRV-2026-0042 is under verification.', time: '3 hours ago', read: true, type: 'warning' },
];

// ---------- Admin Dashboard Statistics ----------
export const ADMIN_STATS = {
  totalBookings: 248,
  activeQueue: 42,
  availableCounters: 5,
  completedServices: 186,
  pendingApplications: 31,
  urgentRequests: 8,
  grievances: 12,
};

// ---------- Admin Charts Data ----------
export const DAILY_BOOKINGS = [
  { day: 'Mon', bookings: 32 },
  { day: 'Tue', bookings: 41 },
  { day: 'Wed', bookings: 36 },
  { day: 'Thu', bookings: 48 },
  { day: 'Fri', bookings: 52 },
  { day: 'Sat', bookings: 39 },
];

export const SERVICE_DISTRIBUTION = [
  { name: 'Income Certificate', value: 35, color: '#134074' },
  { name: 'Caste Certificate', value: 25, color: '#0b2545' },
  { name: 'Residence Certificate', value: 20, color: '#1282a2' },
  { name: 'Birth Certificate', value: 12, color: '#ffc857' },
  { name: 'Other', value: 8, color: '#e8e8e8' },
];

export const QUEUE_STATUS_DATA = [
  { name: 'Waiting', value: 18, color: '#d97706' },
  { name: 'Serving', value: 5, color: '#0284c7' },
  { name: 'Completed', value: 42, color: '#16a34a' },
];

// ---------- Recent Applications (Admin) ----------
export const RECENT_APPLICATIONS = [
  { id: 'APP-2026-0925-0042', citizen: 'Rahul Patil', service: 'Income Certificate', date: '25 Sep 2026', status: 'Processing' },
  { id: 'APP-2026-0925-0038', citizen: 'Sneha Jadhav', service: 'Caste Certificate', date: '25 Sep 2026', status: 'Approved' },
  { id: 'APP-2026-0924-0035', citizen: 'Amit Kumar', service: 'Birth Certificate', date: '24 Sep 2026', status: 'Completed' },
  { id: 'APP-2026-0924-0031', citizen: 'Priya Deshmukh', service: 'Residence Certificate', date: '24 Sep 2026', status: 'Document Verification' },
  { id: 'APP-2026-0923-0028', citizen: 'Vikram Singh', service: 'Domicile Certificate', date: '23 Sep 2026', status: 'Pending' },
  { id: 'APP-2026-0923-0025', citizen: 'Meena Kulkarni', service: 'Senior Citizen Certificate', date: '23 Sep 2026', status: 'Completed' },
];

// ---------- Grievance Error Types ----------
export const ERROR_TYPES = [
  'Name Incorrect',
  'Date of Birth Incorrect',
  'Address Incorrect',
  'Document Information Incorrect',
  'Other',
];

// ---------- Urgency Types ----------
export const URGENCY_TYPES = [
  'Medical Emergency',
  'Education Deadline',
  'Job Joining',
  'Legal Requirement',
  'Travel Urgency',
  'Other',
];
