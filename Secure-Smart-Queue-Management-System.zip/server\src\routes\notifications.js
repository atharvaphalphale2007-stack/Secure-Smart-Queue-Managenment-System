// Secure Smart Queue Management System — Reminders & Notification Engine
import { Router } from 'express';
import { getDb } from '../db.js';
import { logAuditEvent } from '../utils/auditLogger.js';

const router = Router();

// GET /api/notifications — Retrieve user's in-app notifications & SMS log
router.get('/', (req, res) => {
  const db = getDb();
  const notifs = db.prepare(`
    SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50
  `).all(req.user.id);

  const sms = db.prepare(`
    SELECT * FROM sms_inbox WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
  `).all(req.user.id);

  res.json({
    notifications: notifs,
    smsInbox: sms,
  });
});

// PATCH /api/notifications/:id/read — Mark notification read
router.patch('/:id/read', (req, res) => {
  const db = getDb();
  db.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ success: true });
});

// POST /api/notifications/mark-all-read — Mark all notifications read
router.post('/mark-all-read', (req, res) => {
  const db = getDb();
  db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(req.user.id);
  res.json({ success: true });
});

// POST /api/notifications/send-reminder — Trigger 30m or 15m Turn Reminder
router.post('/send-reminder', (req, res) => {
  const { tokenNumber, minutes = 30 } = req.body || {};
  if (!tokenNumber) return res.status(400).json({ error: 'tokenNumber is required' });

  const db = getDb();
  const token = db.prepare(`
    SELECT t.*, u.name AS citizen_name, u.mobile, s.name AS service_name, c.name AS counter_name
    FROM tokens t
    JOIN users u ON u.id = t.citizen_id
    JOIN services s ON s.id = t.service_id
    JOIN counters c ON c.id = t.counter_id
    WHERE t.token_number = ?
  `).get(tokenNumber.toUpperCase());

  if (!token) return res.status(404).json({ error: 'Token not found' });

  const is30 = Number(minutes) === 30;
  const nowStr = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const notifId = `NOTIF-${Date.now()}`;
  const smsId = `SMS-${Date.now()}`;

  const notifMsg = is30
    ? `⏰ 30-Minute Turn Reminder: Token #${token.token_number} will be called in approximately 30 minutes at ${token.counter_name}! Please proceed to the service complex lounge.`
    : `🚨 15-Minute Final Call: Token #${token.token_number} is next in line at ${token.counter_name}! Please report to the counter with original documents.`;

  const smsText = is30
    ? `Govt SQMS Alert: Token ${token.token_number} for ${token.service_name} will arrive in ~30 mins at ${token.counter_name}. Please head to waiting lounge.`
    : `URGENT GOVT SQMS: Token ${token.token_number} is next in line! Reach ${token.counter_name} within 15 minutes with original documents.`;

  // Fetch SMS configuration status
  const smsConfig = db.prepare("SELECT value FROM system_configs WHERE key = 'sms_delivery_enabled'").get()?.value;
  const deliveryStatus = smsConfig === 'true' ? 'delivered' : 'provider_unconfigured (Demo gateway ready)';

  db.transaction(() => {
    // 1. Update token reminders table
    if (is30) {
      db.prepare(`
        INSERT INTO token_reminders (token_number, reminder30_min, reminder30_min_time)
        VALUES (?, 1, ?)
        ON CONFLICT(token_number) DO UPDATE SET reminder30_min = 1, reminder30_min_time = excluded.reminder30_min_time
      `).run(token.token_number, nowStr);
    } else {
      db.prepare(`
        INSERT INTO token_reminders (token_number, reminder15_min, reminder15_min_time)
        VALUES (?, 1, ?)
        ON CONFLICT(token_number) DO UPDATE SET reminder15_min = 1, reminder15_min_time = excluded.reminder15_min_time
      `).run(token.token_number, nowStr);
    }

    // 2. Insert notification
    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, ?)
    `).run(notifId, token.citizen_id, notifMsg, nowStr, is30 ? 'warning' : 'danger');

    // 3. Insert into SMS inbox / delivery log
    db.prepare(`
      INSERT INTO sms_inbox (id, user_id, sender, time, type, text, delivery_status)
      VALUES (?, ?, 'GOV-SQMS', ?, ?, ?, ?)
    `).run(smsId, token.citizen_id, nowStr, is30 ? 'reminder30' : 'reminder15', smsText, deliveryStatus);
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: is30 ? 'REMINDER_30MIN_SENT' : 'REMINDER_15MIN_SENT',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Sent ${minutes}-min reminder to ${token.citizen_name} (${token.mobile || 'In-App'}). Gateway status: ${deliveryStatus}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({
    success: true,
    tokenNumber: token.token_number,
    minutes,
    time: nowStr,
    message: notifMsg,
    sms: smsText,
    deliveryStatus,
  });
});

export default router;
