// Secure Smart Queue Management System — Database Seeder
// Seeds production-ready reference data, office policies, demo accounts, and services.

import bcrypt from 'bcryptjs';
import { getDb } from './db.js';
import { logAuditEvent } from './utils/auditLogger.js';
import { generateQrPayload } from './utils/qrCrypto.js';

const OFFICE_PUNE = {
  id: 'OFFICE-PUNE-01',
  name: 'Tehsildar Office Pune Central',
  district: 'Pune',
  state: 'Maharashtra',
  address: 'Building B, Ground Floor, Administrative Complex, Pune — 411001',
  contact_email: 'tehsildar.pune@gov.in',
  contact_phone: '+91 20 2612 3456',
  opening_time: '09:00',
  closing_time: '17:30',
  grace_period_mins: 15,
};

const SERVICES = [
  {
    id: 'income',
    name: 'Income Certificate',
    description: 'Certificate of annual family income issued by the Tehsildar office for educational and scholarship benefits.',
    icon: 'IndianRupee',
    processing_time: '3-5 working days',
    counter_handling_time_min: 10,
    fee: '₹25',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 3, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Citizen residing in Maharashtra with documented proof of annual household earnings.',
    official_source: 'Revenue & Forest Department, Government of Maharashtra (Official Rulebook 2024)',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'Address Proof', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'Income Proof (Salary Slip / Form 16 / Affidavit)', xerox: 1, mandatory: 1, maxSize: 10, formats: 'application/pdf' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
      { name: 'Self Declaration / Application Form', xerox: 0, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
    ],
    guidelines: [
      'Bring original documents along with required Xerox copies for verification.',
      'Affidavit must be notarized if salary slip or Form 16 is not available.',
      'Ensure scanned uploads are legible and under permitted file sizes.',
      'Arrive at the office kiosk within your 15-minute grace window.',
      'Keep your cryptographic QR token ready on phone or printed pass.',
    ],
  },
  {
    id: 'caste',
    name: 'Caste Certificate',
    description: 'Official certificate verifying caste category under SC/ST/VJNT/OBC categories.',
    icon: 'Users',
    processing_time: '5-7 working days',
    counter_handling_time_min: 12,
    fee: '₹25',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 4, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Applicant or paternal ancestors must have domicile in Maharashtra prior to designated presidential cut-off dates.',
    official_source: 'Social Justice and Special Assistance Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'School Leaving Certificate', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: "Father's Caste Certificate", xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Ration Card', xerox: 1, mandatory: 0, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
    ],
    guidelines: [
      "Father's or direct paternal relative's caste certificate is mandatory.",
      'Carry original school leaving certificate showing caste entry.',
      'In case of lineage change, family genealogical tree affidavit is required.',
    ],
  },
  {
    id: 'residence',
    name: 'Residence Certificate',
    description: 'Certificate confirming continuous residence within the jurisdiction.',
    icon: 'Home',
    processing_time: '3-5 working days',
    counter_handling_time_min: 8,
    fee: '₹25',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 2, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Residents residing within the Taluka for a minimum of 1 year.',
    official_source: 'Revenue Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'Electricity Bill / Gas Bill', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: 'Ration Card / Rent Agreement', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
    ],
    guidelines: [
      'Utility bill must be from within the last 3 months.',
      'Registered rent agreement acceptable if residing in rented premises.',
    ],
  },
  {
    id: 'domicile',
    name: 'Domicile Certificate',
    description: 'State domicile certificate establishing permanent resident rights in Maharashtra.',
    icon: 'MapPin',
    processing_time: '7-10 working days',
    counter_handling_time_min: 15,
    fee: '₹50',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 4, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Continuous residence in the State of Maharashtra for 15 years or more.',
    official_source: 'Home Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'School Leaving Certificate', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Residence Proof (15 Years continuous record)', xerox: 1, mandatory: 1, maxSize: 10, formats: 'application/pdf' },
      { name: 'Birth Certificate', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
    ],
    guidelines: [
      'Proof of 15 years residence can include schooling certificates, electricity bills, or land records.',
      'Verification officer may conduct field verification if records are incomplete.',
    ],
  },
  {
    id: 'birth',
    name: 'Birth Certificate',
    description: 'Official vital record certifying birth registration under Registration of Births and Deaths Act.',
    icon: 'Baby',
    processing_time: '5-7 working days',
    counter_handling_time_min: 8,
    fee: '₹10',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 1, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Birth event occurred within the registered local administrative area.',
    official_source: 'Public Health Department, Municipal & Revenue Administration',
    requiredDocs: [
      { name: 'Hospital Birth Record', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: "Parent's Aadhaar Card", xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: 'Marriage Certificate of Parents', xerox: 1, mandatory: 0, maxSize: 5, formats: 'application/pdf' },
      { name: 'Application Form', xerox: 0, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
    ],
    guidelines: [
      'Hospital discharge summary / birth memo is required for births within 1 year.',
      'Delayed registrations beyond 1 year require SDM court order.',
    ],
  },
  {
    id: 'death',
    name: 'Death Certificate',
    description: 'Vital registration document certifying recorded death.',
    icon: 'FileX',
    processing_time: '5-7 working days',
    counter_handling_time_min: 8,
    fee: '₹10',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 1, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Immediate family or authorized legal representative of the deceased.',
    official_source: 'Public Health Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Hospital Death Record / Crematorium Receipt', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: "Deceased's Aadhaar Card", xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: "Applicant's Aadhaar Card", xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: 'Application Form', xerox: 0, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
    ],
    guidelines: [
      'Medical certification of cause of death or doctor report required.',
    ],
  },
  {
    id: 'senior',
    name: 'Senior Citizen Certificate',
    description: 'Special identity card and certificate for citizens aged 60 and above.',
    icon: 'UserCheck',
    processing_time: '3-5 working days',
    counter_handling_time_min: 6,
    fee: 'Free',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 5, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'Citizen aged 60 years or above on the date of application.',
    official_source: 'Social Justice Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'Age Proof (Birth Certificate / School LC / Passport)', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
    ],
    guidelines: [
      'Priority queue processing available at Counter 5.',
    ],
  },
  {
    id: 'ncl',
    name: 'Non-Creamy Layer Certificate',
    description: 'Certificate establishing OBC Non-Creamy Layer status under central and state guidelines.',
    icon: 'FileCheck',
    processing_time: '7-10 working days',
    counter_handling_time_min: 12,
    fee: '₹50',
    office_address: 'Tehsildar Office, Building B, Ground Floor, Counter 4, Administrative Complex, Pune — 411001',
    landmark: 'Opposite District Court, Near Railway Station',
    eligibility_info: 'OBC category applicants whose parents annual income does not exceed 8 Lakhs for 3 consecutive years.',
    official_source: 'Social Welfare Department, Govt of Maharashtra',
    requiredDocs: [
      { name: 'Aadhaar Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg,image/png' },
      { name: 'Caste Certificate', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf' },
      { name: 'Income Proof of Parents (Last 3 Financial Years)', xerox: 1, mandatory: 1, maxSize: 10, formats: 'application/pdf' },
      { name: 'Ration Card', xerox: 1, mandatory: 1, maxSize: 5, formats: 'application/pdf,image/jpeg' },
      { name: 'Passport Size Photo', xerox: 0, mandatory: 1, maxSize: 2, formats: 'image/jpeg,image/png' },
    ],
    guidelines: [
      'Income records of previous 3 consecutive financial years are compulsory.',
    ],
  },
];

const COUNTERS = [
  { id: 1, name: 'Counter 1', serviceId: 'birth', officerId: null, currentToken: 'B-012', status: 'Available' },
  { id: 2, name: 'Counter 2', serviceId: 'residence', officerId: null, currentToken: 'R-018', status: 'Available' },
  { id: 3, name: 'Counter 3', serviceId: 'income', officerId: 'OFF-402', currentToken: 'A-035', status: 'Serving' },
  { id: 4, name: 'Counter 4', serviceId: 'caste', officerId: null, currentToken: 'C-021', status: 'Available' },
  { id: 5, name: 'Counter 5', serviceId: 'senior', officerId: null, currentToken: 'S-009', status: 'Available' },
];

const SERVICE_COUNTER_MAP = {
  birth: 1,
  death: 1,
  residence: 2,
  income: 3,
  caste: 4,
  domicile: 4,
  ncl: 4,
  senior: 5,
};

const TIME_SLOTS = [
  '09:00 AM - 09:30 AM',
  '09:30 AM - 10:00 AM',
  '10:00 AM - 10:30 AM',
  '10:30 AM - 11:00 AM',
  '11:00 AM - 11:30 AM',
  '11:30 AM - 12:00 PM',
  '12:00 PM - 12:30 PM',
  '02:00 PM - 02:30 PM',
  '02:30 PM - 03:00 PM',
  '03:00 PM - 03:30 PM',
];

const HOLIDAYS = [
  { date: '2026-01-26', title: 'Republic Day', description: 'National Holiday' },
  { date: '2026-05-01', title: 'Maharashtra Day', description: 'State Holiday' },
  { date: '2026-08-15', title: 'Independence Day', description: 'National Holiday' },
  { date: '2026-10-02', title: 'Mahatma Gandhi Jayanti', description: 'National Holiday' },
  { date: '2026-12-25', title: 'Christmas', description: 'National Holiday' },
  { date: '2027-01-26', title: 'Republic Day 2027', description: 'National Holiday' },
];

const SYSTEM_CONFIGS = [
  { key: 'arrival_grace_period_mins', value: '15', description: 'Minutes after slot start within which arrival must be verified' },
  { key: 'default_slot_capacity', value: '3', description: 'Maximum citizens bookable in a single counter time slot' },
  { key: 'turn_reminder_window_1_mins', value: '30', description: 'First stage turn notification window (30 mins before)' },
  { key: 'turn_reminder_window_2_mins', value: '15', description: 'Urgent final call reminder window (15 mins before)' },
  { key: 'allow_emergency_tatkal', value: 'true', description: 'Enable urgent express processing with officer sign-off' },
  { key: 'sms_gateway_provider', value: 'GOV_SMS_NIC_GATEWAY_STAGING', description: 'Current SMS provider configuration' },
  { key: 'sms_delivery_enabled', value: 'false', description: 'Flag whether external SMS delivery credentials are live' },
];

export async function runSeed() {
  const db = getDb();

  // Check if already seeded
  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get()?.c;
  if (userCount && userCount > 0) {
    return;
  }

  // Passwords: Support both standard and demo inputs
  const citizenHash = await bcrypt.hash('demo123', 10);
  const officerHash = await bcrypt.hash('officer@123', 10);
  const adminHash = await bcrypt.hash('admin@123', 10);

  db.transaction(() => {
    // 1. Offices
    db.prepare(`
      INSERT INTO offices (
        id, name, district, state, address, contact_email,
        contact_phone, opening_time, closing_time, grace_period_mins
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      OFFICE_PUNE.id, OFFICE_PUNE.name, OFFICE_PUNE.district, OFFICE_PUNE.state,
      OFFICE_PUNE.address, OFFICE_PUNE.contact_email, OFFICE_PUNE.contact_phone,
      OFFICE_PUNE.opening_time, OFFICE_PUNE.closing_time, OFFICE_PUNE.grace_period_mins
    );

    // 2. Users (Citizen, Officer, Admin)
    const insertUser = db.prepare(`
      INSERT INTO users (
        id, role, name, mobile, email, aadhaar, address,
        password_hash, designation, department, office_id, counter, counter_name
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertUser.run(
      'CIT-101', 'citizen', 'Rahul Patil', '9876543210', 'rahul.patil@example.com',
      'XXXX-XXXX-4242', 'Pune, Maharashtra', citizenHash, null, null,
      OFFICE_PUNE.id, null, null
    );

    insertUser.run(
      'OFF-402', 'officer', 'Ms. Priya Sharma', '9876543211', 'priya.sharma@gov.in',
      null, null, officerHash, 'Senior Tehsildar & Verification Officer',
      'Revenue & Public Administration Department', OFFICE_PUNE.id, 3, 'Counter 3 - Income Certificate'
    );

    insertUser.run(
      'ADM-101', 'admin', 'System Administrator', '9876543212', 'admin.sqms@gov.in',
      null, null, adminHash, 'Director of Public Service IT Systems',
      'Directorate of Information Technology', OFFICE_PUNE.id, null, null
    );

    // 3. Services & Checklist
    const insertService = db.prepare(`
      INSERT INTO services (
        id, office_id, name, description, icon, processing_time,
        counter_handling_time_min, fee, office_address, landmark,
        eligibility_info, official_source
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertDoc = db.prepare(`
      INSERT INTO service_required_docs (service_id, doc_name, xerox, is_mandatory, max_size_mb, allowed_formats)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const insertGuideline = db.prepare(`
      INSERT INTO service_guidelines (service_id, guideline) VALUES (?, ?)
    `);

    for (const svc of SERVICES) {
      insertService.run(
        svc.id, OFFICE_PUNE.id, svc.name, svc.description, svc.icon, svc.processing_time,
        svc.counter_handling_time_min, svc.fee, svc.office_address, svc.landmark,
        svc.eligibility_info, svc.official_source
      );
      for (const d of svc.requiredDocs) {
        insertDoc.run(svc.id, d.name, d.xerox, d.mandatory, d.maxSize, d.formats);
      }
      for (const g of svc.guidelines) {
        insertGuideline.run(svc.id, g);
      }
    }

    // 4. Counters
    const insertCounter = db.prepare(`
      INSERT INTO counters (id, office_id, name, service_id, officer_id, current_token, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const c of COUNTERS) {
      insertCounter.run(c.id, OFFICE_PUNE.id, c.name, c.serviceId, c.officerId, c.currentToken, c.status);
    }

    // 5. Service-Counter Maps
    const insertMap = db.prepare('INSERT INTO service_counter_map (service_id, counter_id) VALUES (?, ?)');
    for (const [sid, cid] of Object.entries(SERVICE_COUNTER_MAP)) {
      insertMap.run(sid, cid);
    }

    // 6. Time Slots
    const insertSlot = db.prepare('INSERT INTO time_slots (time, label, max_capacity) VALUES (?, ?, ?)');
    for (const t of TIME_SLOTS) {
      insertSlot.run(t, t, 3);
    }

    // 7. Holidays
    const insertHoliday = db.prepare('INSERT INTO holidays (office_id, date, title, description) VALUES (?, ?, ?, ?)');
    for (const h of HOLIDAYS) {
      insertHoliday.run(OFFICE_PUNE.id, h.date, h.title, h.description);
    }

    // 8. System Configs
    const insertConfig = db.prepare('INSERT INTO system_configs (key, value, description) VALUES (?, ?, ?)');
    for (const cfg of SYSTEM_CONFIGS) {
      insertConfig.run(cfg.key, cfg.value, cfg.description);
    }

    // 9. Initial Booking + Active Token (A-042) for Rahul Patil
    const bookingId = 'BK-2026-0042';
    const tokenId = 'TK-2026-0042';
    const tokenNumber = 'A-042';
    const slotDate = new Date().toISOString().slice(0, 10);
    const slotTime = '10:30 AM - 11:00 AM';

    db.prepare(`
      INSERT INTO bookings (
        id, citizen_id, service_id, office_id, slot_date, slot_time, slot_label, counter_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(bookingId, 'CIT-101', 'income', OFFICE_PUNE.id, slotDate, slotTime, slotTime, 3, 'booked');

    const qr = generateQrPayload({
      tokenId,
      tokenNumber,
      officeId: OFFICE_PUNE.id,
      serviceId: 'income',
      expiryMinutes: 1440,
    });

    db.prepare(`
      INSERT INTO tokens (
        id, token_number, booking_id, citizen_id, service_id, office_id, counter_id,
        qr_payload, qr_signature, queue_status, priority_type, stage1_verified_at, stage1_officer_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      tokenId, tokenNumber, bookingId, 'CIT-101', 'income', OFFICE_PUNE.id, 3,
      qr.qrString, qr.signature, 'waiting', 'normal', new Date().toISOString(), 'OFF-402'
    );

    db.prepare('INSERT INTO token_reminders (token_number) VALUES (?)').run(tokenNumber);

    // Initial Application & History
    const appId = 'APP-2026-0925-0042';
    db.prepare(`
      INSERT INTO applications (
        id, citizen_id, service_id, booking_id, token_id, status, officer_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(appId, 'CIT-101', 'income', bookingId, tokenId, 'under_verification', 'Application checked in at Counter 3');

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(appId, 'CIT-101', 'citizen', 'none', 'submitted', 'Citizen submitted application and confirmed booking slot');

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(appId, 'OFF-402', 'officer', 'submitted', 'under_verification', 'Citizen arrival verified at entrance kiosk; token queued at Counter 3');

    // Notifications
    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      'NOTIF-INIT-1', 'CIT-101',
      'Govt of Maharashtra: Token A-042 generated for Income Certificate. Counter 3, Tehsildar Complex Pune.',
      '09:15 AM', 0, 'info'
    );

    // Initial Audit Genesis
    logAuditEvent({
      actorId: 'ADM-101',
      actorRole: 'admin',
      action: 'SYSTEM_GENESIS_SEED',
      resourceType: 'system',
      resourceId: OFFICE_PUNE.id,
      details: 'Initial production database seed executed with multi-office policies, catalog and audit chaining.',
      status: 'SUCCESS',
    });
  });
}

export default runSeed;
