// Secure Smart Queue Management System — Citizen Grievance Redressal
import { Router } from 'express';
import { getDb } from '../db.js';
import { logAuditEvent } from '../utils/auditLogger.js';
import { requireRole } from '../middleware/auth.js';

const router = Router();

function uid() {
  return Math.random().toString(36).slice(2, 6).toUpperCase();
}

// GET /api/grievance — List grievances (Citizen sees own, Officers/Admins see all)
router.get('/', (req, res) => {
  const db = getDb();
  let rows;
  if (req.user.role === 'citizen') {
    rows = db.prepare(`
      SELECT g.*, u.name AS citizen_name
      FROM grievances g
      JOIN users u ON u.id = g.citizen_id
      WHERE g.citizen_id = ?
      ORDER BY g.created_at DESC
    `).all(req.user.id);
  } else {
    rows = db.prepare(`
      SELECT g.*, u.name AS citizen_name, u.mobile AS citizen_mobile
      FROM grievances g
      JOIN users u ON u.id = g.citizen_id
      ORDER BY g.created_at DESC
    `).all();
  }
  res.json(rows);
});

// POST /api/grievance — Citizen submits grievance
router.post('/', (req, res) => {
  const { appId, docType, errorType, correctInfo, description } = req.body || {};
  if (!docType || !errorType || !description) {
    return res.status(400).json({ error: 'docType, errorType, and description are required' });
  }

  const db = getDb();
  const id = `GRV-${new Date().getFullYear()}-${uid()}`;
  const dateStr = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  db.prepare(`
    INSERT INTO grievances (id, citizen_id, app_id, doc_type, error_type, correct_info, description, date, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'submitted')
  `).run(id, req.user.id, appId || null, docType, errorType, correctInfo || null, description, dateStr);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'citizen',
    action: 'GRIEVANCE_SUBMITTED',
    resourceType: 'grievance',
    resourceId: id,
    details: `Grievance submitted for ${docType} (${errorType})`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  const created = db.prepare('SELECT * FROM grievances WHERE id = ?').get(id);
  res.status(201).json(created);
});

// PATCH /api/grievance/:id/status — Officer resolves grievance
router.patch('/:id/status', requireRole('officer', 'admin'), (req, res) => {
  const { status, resolutionNotes } = req.body || {};
  if (!status || !['submitted', 'in_review', 'resolved', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Valid status is required' });
  }

  const db = getDb();
  const grv = db.prepare('SELECT * FROM grievances WHERE id = ?').get(req.params.id);
  if (!grv) return res.status(404).json({ error: 'Grievance ticket not found' });

  db.transaction(() => {
    db.prepare(`
      UPDATE grievances SET
        status = ?,
        resolution_notes = ?,
        assigned_officer_id = ?,
        updated_at = datetime('now')
      WHERE id = ?
    `).run(status, resolutionNotes || null, req.user.id, grv.id);

    // Notify citizen
    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, ?)
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      grv.citizen_id,
      `Grievance #${grv.id} status updated to ${status.toUpperCase()}. Notes: ${resolutionNotes || 'Reviewed by officer'}`,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      status === 'resolved' ? 'success' : 'info'
    );
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'GRIEVANCE_STATUS_UPDATED',
    resourceType: 'grievance',
    resourceId: grv.id,
    details: `Grievance updated to ${status}. Notes: ${resolutionNotes || 'None'}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, grievance: db.prepare('SELECT * FROM grievances WHERE id = ?').get(grv.id) });
});

export default router;