// Secure Smart Queue Management System — Server Entry Point
// Production-Ready Express API with Security Headers, Route Registrations & Centralized Error Handling

import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { initDb } from './db.js';
import { authMiddleware, optionalAuth } from './middleware/auth.js';
import { runSeed } from './seed.js';

import authRoutes from './routes/auth.js';
import serviceRoutes from './routes/services.js';
import bookingRoutes from './routes/booking.js';
import queueRoutes from './routes/queue.js';
import applicationRoutes from './routes/applications.js';
import documentRoutes from './routes/documents.js';
import grievanceRoutes from './routes/grievance.js';
import urgentRoutes from './routes/urgent.js';
import notificationRoutes from './routes/notifications.js';
import adminRoutes from './routes/admin.js';
import chatbotRoutes from './routes/chatbot.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;

// Security Headers Middleware
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  next();
});

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));

// Health Check & System Status Endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'sqms-server',
    version: '2.0.0-production',
    time: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    database: 'persistent-sqlite-wal',
  });
});

// Mount API Routes
app.use('/api/auth', authRoutes);
app.use('/api/services', optionalAuth, serviceRoutes);
app.use('/api/booking', authMiddleware, bookingRoutes);
app.use('/api/queue', authMiddleware, queueRoutes);
app.use('/api/applications', authMiddleware, applicationRoutes);
app.use('/api/documents', authMiddleware, documentRoutes);
app.use('/api/grievance', authMiddleware, grievanceRoutes);
app.use('/api/urgent', authMiddleware, urgentRoutes);
app.use('/api/notifications', authMiddleware, notificationRoutes);
app.use('/api/admin', authMiddleware, adminRoutes);
app.use('/api/chatbot', chatbotRoutes);

// 404 Handler
app.use((_req, res) => res.status(404).json({ error: 'Endpoint not found' }));

// Centralized Error Handler
app.use((err, req, res, _next) => {
  const status = err.status || 500;
  console.error(`[SQMS-ERROR] ${req.method} ${req.url} —`, err.message || err);
  res.status(status).json({
    error: err.message || 'Internal server error',
    timestamp: new Date().toISOString(),
  });
});

// Database Initialization & Startup
export async function startServer(port = PORT) {
  initDb();
  await runSeed();

  return new Promise((resolve) => {
    const server = app.listen(port, () => {
      console.log(`\n======================================================`);
      console.log(`  Secure Smart Queue Management System (SQMS) API`);
      console.log(`  Status: Running on http://localhost:${port}`);
      console.log(`  Health Check: http://localhost:${port}/api/health`);
      console.log(`======================================================\n`);
      resolve(server);
    });
  });
}

// Auto-run if executed directly
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  startServer();
}

export default app;