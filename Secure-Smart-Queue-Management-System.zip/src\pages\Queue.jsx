import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Radio,
  Ticket,
  Hash,
  Clock,
  BarChart3,
  ArrowRight,
  RefreshCw,
  Zap,
  Volume2,
  Tv,
} from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import StatusBadge from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';
import { QUEUE_TOKENS } from '../data/mockData';
import { speakAnnouncement, playCounterChime } from '../utils/audioAnnouncer';

const Queue = () => {
  const {
    token,
    tokenReminders = {},
    currentServing,
    queuePosition,
    estimatedWait,
    counters,
    addToast,
    language,
    callNextCitizen,
  } = useAppContext();

  const [tvDisplayMode, setTvDisplayMode] = useState(false);

  const tokenReminderInfo = tokenReminders[token?.tokenNumber] || token?.reminders || {};
  const has30MinReminder = tokenReminderInfo.reminder30Min;
  const has15MinReminder = tokenReminderInfo.reminder15Min;

  const handleRefresh = () => {
    addToast('Live queue synchronized with central server', 'info');
  };

  const handleAnnounceServing = () => {
    playCounterChime();
    speakAnnouncement(`Now serving, Token number ${currentServing}, at Counter number 3`, language);
    addToast(`📢 Audio Announcement: Now serving ${currentServing} at Counter 3`, 'info');
  };

  return (
    <div className="page-container">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Queue' }
        ]}
      />

      <div className="section">
        {/* Title Header with Audio & Display Board Toggles */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
          <div>
            <h1 className="page-title" style={{ margin: 0 }}>Live Queue Status & Display Board</h1>
            <p className="page-subtitle" style={{ margin: '4px 0 0' }}>
              Real-time multi-counter tracking, turn reminders, and public audio callouts.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
            <button
              type="button"
              className="btn btn-outline"
              onClick={handleAnnounceServing}
              style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
            >
              <Volume2 size={16} /> Announce {currentServing}
            </button>

            <button
              type="button"
              className={`btn ${tvDisplayMode ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setTvDisplayMode(!tvDisplayMode)}
              style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
            >
              <Tv size={16} /> {tvDisplayMode ? 'Exit TV Mode' : 'Public Display Board (TV)'}
            </button>

            <button
              type="button"
              className="btn btn-outline"
              onClick={handleRefresh}
              style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}
            >
              <RefreshCw size={15} /> Refresh
            </button>
          </div>
        </div>

        {/* FULLSCREEN PUBLIC LED DISPLAY BOARD (TV SIMULATOR) */}
        {tvDisplayMode && (
          <div
            style={{
              background: '#090d16',
              color: '#ffffff',
              borderRadius: '16px',
              padding: '2rem',
              marginBottom: '2rem',
              border: '2px solid #1e293b',
              boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #1e293b', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <span style={{ fontSize: '0.8rem', color: '#38bdf8', letterSpacing: '0.08em', fontWeight: 800 }}>
                  GOVERNMENT CITIZEN SERVICE COMPLEX • LIVE QUEUE DISPLAY
                </span>
                <h2 style={{ margin: '4px 0 0', color: '#ffffff', fontSize: '1.6rem' }}>
                  Central Counter Status Board
                </h2>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '1.8rem', fontFamily: 'monospace', fontWeight: 800, color: '#22c55e' }}>
                  {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
                <span style={{ fontSize: '0.78rem', color: '#94a3b8' }}>Live Broadcast Active</span>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
              {counters.map((c) => {
                const isMain = c.id === 3;

                return (
                  <div
                    key={c.id}
                    style={{
                      background: isMain ? 'rgba(2, 132, 199, 0.15)' : '#1e293b',
                      border: `2px solid ${isMain ? '#0284c7' : '#334155'}`,
                      borderRadius: '10px',
                      padding: '1.25rem',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '0.85rem', color: '#94a3b8', fontWeight: 700 }}>{c.name}</div>
                    <div style={{ fontSize: '0.75rem', color: '#cbd5e1', marginBottom: '8px' }}>{c.service}</div>
                    <div style={{ fontSize: '2.2rem', fontWeight: 900, color: isMain ? '#38bdf8' : c.currentToken ? '#22c55e' : '#64748b' }}>
                      {isMain ? currentServing : c.currentToken || '—'}
                    </div>
                    <div style={{ marginTop: '6px' }}>
                      <span style={{ fontSize: '0.75rem', padding: '2px 8px', borderRadius: '10px', background: isMain ? '#0284c7' : '#334155', color: '#ffffff', fontWeight: 600 }}>
                        {isMain ? 'SERVING NOW' : c.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', background: '#1e293b', padding: '12px 18px', borderRadius: '8px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.9rem' }}>
                <span style={{ color: '#facc15', fontWeight: 800 }}>⚡ INCOMING NEXT:</span>
                <span>Token <strong>{token?.tokenNumber || 'A-042'}</strong> (Rahul Patil) — Counter 3</span>
              </div>
              <button
                type="button"
                className="btn btn-sm btn-primary"
                onClick={callNextCitizen}
                style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
              >
                Advance Counter 3 Serving
              </button>
            </div>
          </div>
        )}

        {/* 15-MINUTE HIGH PRIORITY FINAL CALL ALERT BANNER */}
        {has15MinReminder && (
          <div
            style={{
              background: '#fef2f2',
              border: '2px solid #ef4444',
              borderRadius: '12px',
              padding: '1.25rem 1.5rem',
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              boxShadow: '0 4px 15px rgba(239, 68, 68, 0.15)',
            }}
          >
            <div style={{ background: '#ef4444', color: '#fff', padding: '8px', borderRadius: '50%' }}>
              <Zap size={24} />
            </div>
            <div style={{ flexGrow: 1 }}>
              <h4 style={{ margin: 0, color: '#b91c1c', fontSize: '1.05rem', fontWeight: 800 }}>
                🚨 Final Call Alert: Token #{token?.tokenNumber} is arriving in ~15 minutes at Counter 3!
              </h4>
              <p style={{ margin: '4px 0 0', color: '#991b1b', fontSize: '0.88rem' }}>
                Officer Ms. Priya Sharma has issued a direct approach call. Please take your seat directly near Counter 3 now.
              </p>
            </div>
            <Link to="/my-token" className="btn btn-sm" style={{ background: '#ef4444', color: '#fff', fontWeight: 700 }}>
              View My Token Slip
            </Link>
          </div>
        )}

        {/* 30-MINUTE TURN REMINDER ALERT BANNER */}
        {has30MinReminder && !has15MinReminder && (
          <div
            style={{
              background: '#fffbeb',
              border: '2px solid #f59e0b',
              borderRadius: '12px',
              padding: '1.25rem 1.5rem',
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              boxShadow: '0 4px 15px rgba(245, 158, 11, 0.12)',
            }}
          >
            <div style={{ background: '#f59e0b', color: '#fff', padding: '8px', borderRadius: '50%' }}>
              <Clock size={24} />
            </div>
            <div style={{ flexGrow: 1 }}>
              <h4 style={{ margin: 0, color: '#b45309', fontSize: '1.05rem', fontWeight: 800 }}>
                ⏰ 30-Minute Turn Reminder Received from Officer Priya Sharma
              </h4>
              <p style={{ margin: '4px 0 0', color: '#92400e', fontSize: '0.88rem' }}>
                Your turn for Token #{token?.tokenNumber} is approximately 30 minutes away. Please ensure you have arrived at the Administrative Complex.
              </p>
            </div>
            <Link to="/my-token" className="btn btn-sm" style={{ background: '#f59e0b', color: '#fff', fontWeight: 700 }}>
              View Details
            </Link>
          </div>
        )}

        {/* 4 Metrics Cards */}
        <div className="grid-4" style={{ marginBottom: '2rem' }}>
          <div className="stat-card">
            <div className="stat-icon" style={{ backgroundColor: '#eff6ff', color: '#2563eb' }}>
              <Radio size={24} />
            </div>
            <div className="stat-info">
              <h3>Currently Serving</h3>
              <p className="text-xl font-bold">{currentServing}</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ backgroundColor: '#fff7ed', color: '#ea580c' }}>
              <Ticket size={24} />
            </div>
            <div className="stat-info">
              <h3>Your Token</h3>
              <p className="text-xl font-bold">{token?.tokenNumber || 'A-042'}</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ backgroundColor: '#f0fdf4', color: '#16a34a' }}>
              <Hash size={24} />
            </div>
            <div className="stat-info">
              <h3>Queue Position</h3>
              <p className="text-xl font-bold">{queuePosition}</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ backgroundColor: '#eff6ff', color: '#2563eb' }}>
              <Clock size={24} />
            </div>
            <div className="stat-info">
              <h3>Est. Waiting</h3>
              <p className="text-xl font-bold">{estimatedWait} min</p>
            </div>
          </div>
        </div>

        {/* Queue Progress Visual Pipeline */}
        <div className="card" style={{ marginBottom: '2rem' }}>
          <div className="card-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <BarChart3 size={20} />
              <h2 style={{ margin: 0 }}>Queue Progress Pipeline (Counter 3 Desk)</h2>
            </div>
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={callNextCitizen}
              style={{ display: 'flex', alignItems: 'center', gap: '4px' }}
            >
              Simulate Queue Advance &rarr;
            </button>
          </div>
          <div className="card-body">
            <div className="queue-pipeline" style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
              <div className="queue-chip serving" style={{ padding: '0.65rem 1.25rem', backgroundColor: '#22c55e', color: '#fff', borderRadius: '20px', fontWeight: 'bold' }}>
                {currentServing} (Serving)
              </div>
              
              {QUEUE_TOKENS.map((qt) => {
                const isYourToken = qt === (token?.tokenNumber || 'A-042');

                return (
                  <React.Fragment key={qt}>
                    <ArrowRight className="queue-arrow" size={16} color="#94a3b8" />
                    <div
                      className={`queue-chip ${isYourToken ? 'you' : 'waiting'}`}
                      style={{
                        padding: '0.65rem 1.25rem',
                        backgroundColor: isYourToken ? '#3b82f6' : 'var(--gray-200)',
                        color: isYourToken ? '#fff' : 'var(--gray-700)',
                        borderRadius: '20px',
                        fontWeight: isYourToken ? 'bold' : 'normal',
                        boxShadow: isYourToken ? '0 4px 12px rgba(59, 130, 246, 0.35)' : 'none',
                      }}
                    >
                      {qt} {isYourToken ? '(You)' : ''}
                    </div>
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>

        {/* Counter Overview */}
        <div className="card">
          <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ margin: 0 }}>Active Counters Overview</h2>
            <span className="badge badge-success">5 Counters Online</span>
          </div>
          <div className="card-body">
            <div className="grid-3">
              {counters.map((c) => {
                const isCounter3 = c.id === 3;

                return (
                  <div
                    key={c.id}
                    className="counter-card"
                    style={{
                      padding: '1.25rem',
                      border: `1px solid ${isCounter3 ? '#bae6fd' : 'var(--gray-200)'}`,
                      borderRadius: '8px',
                      background: isCounter3 ? 'rgba(2, 132, 199, 0.04)' : 'var(--white)',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <h3 style={{ margin: 0, fontSize: '1.1rem' }}>{c.name}</h3>
                      <StatusBadge status={c.status} />
                    </div>
                    <p style={{ margin: '4px 0', fontSize: '0.9rem', color: 'var(--gray-500)' }}>{c.service}</p>
                    <p style={{ margin: '4px 0', fontSize: '0.85rem' }}>Officer: <strong>{c.officer}</strong></p>
                    <p style={{ margin: '4px 0', fontSize: '0.85rem' }}>
                      Serving Token: <strong style={{ color: '#0284c7' }}>{isCounter3 ? currentServing : c.currentToken || 'None'}</strong>
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Queue;
