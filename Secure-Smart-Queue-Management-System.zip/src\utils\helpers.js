// ============================================================
// SMART QUEUE MANAGEMENT SYSTEM — Helper Utilities
// ============================================================

/**
 * Generate a token ID in the format SQMS-YYYY-MMDD-HHMM
 */
export function generateTokenId() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `SQMS-${y}-${m}${d}-${h}${min}`;
}

/**
 * Generate an application ID
 */
export function generateApplicationId() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const seq = String(Math.floor(Math.random() * 90) + 10).padStart(4, '0');
  return `APP-${y}-${m}${d}-${seq}`;
}

/**
 * Generate a grievance ID
 */
export function generateGrievanceId() {
  const now = new Date();
  const y = now.getFullYear();
  const seq = String(Math.floor(Math.random() * 90) + 10).padStart(4, '0');
  return `GRV-${y}-${seq}`;
}

/**
 * Format a date object into readable string like "25 September 2026"
 */
export function formatDateLong(date) {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];
  const d = date instanceof Date ? date : new Date(date);
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

/**
 * Format a date into short display like "25 Sep"
 */
export function formatDateShort(date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const d = date instanceof Date ? date : new Date(date);
  return `${d.getDate()} ${months[d.getMonth()]}`;
}

/**
 * Format date as YYYY-MM-DD
 */
export function formatDateISO(date) {
  const d = date instanceof Date ? date : new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/**
 * Get the day name like "Mon", "Tue" etc.
 */
export function getDayName(date) {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const d = date instanceof Date ? date : new Date(date);
  return days[d.getDay()];
}

/**
 * Check if a date is a weekend (Saturday or Sunday - Government Holiday)
 */
export function isWeekend(date) {
  const d = date instanceof Date ? date : new Date(date);
  const day = d.getDay();
  return day === 0 || day === 6; // 0 = Sunday, 6 = Saturday
}

/**
 * Get the next N days starting from today
 */
export function getNextDays(count = 7) {
  const days = [];
  const today = new Date();
  for (let i = 0; i < count; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    days.push(d);
  }
  return days;
}

/**
 * Generate a mock slot availability status
 */
export function getSlotAvailability(dateIndex, slotIndex) {
  // Deterministic pseudo-random availability based on date and slot index
  const seed = (dateIndex * 7 + slotIndex * 3) % 10;
  if (seed < 6) return 'available';
  if (seed < 8) return 'limited';
  return 'unavailable';
}

/**
 * Build a QR code string for a token
 */
export function buildQRString(tokenNumber, date, serviceId) {
  const verify = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `SQMS|TOKEN=${tokenNumber}|DATE=${date}|SERVICE=${serviceId.toUpperCase()}|VERIFY=${verify}`;
}

/**
 * Load state from localStorage
 */
export function loadState(key, defaultValue) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch {
    return defaultValue;
  }
}

/**
 * Save state to localStorage
 */
export function saveState(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // localStorage may be full or unavailable
  }
}

/**
 * Clear all SQMS data from localStorage
 */
export function clearAllState() {
  const keys = [
    'sqms_booking', 'sqms_token', 'sqms_checkin',
    'sqms_application', 'sqms_grievance', 'sqms_urgent',
    'sqms_documents', 'sqms_notifications', 'sqms_doc_verification',
  ];
  keys.forEach((k) => localStorage.removeItem(k));
}
