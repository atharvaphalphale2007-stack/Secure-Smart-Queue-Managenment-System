import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, AlertTriangle, Clock, Calendar } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Breadcrumb from '../components/Breadcrumb';
import { SERVICES, URGENCY_TYPES } from '../data/mockData';

const UrgentRequest = () => {
  const { urgentRequest, submitUrgentRequest, booking } = useAppContext();
  const [isSubmitted, setIsSubmitted] = useState(!!urgentRequest);

  const [service, setService] = useState('Income Certificate');
  const [preferredDate, setPreferredDate] = useState('');
  const [reason, setReason] = useState('');
  const [urgencyType, setUrgencyType] = useState(URGENCY_TYPES[0] || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    submitUrgentRequest({
      service,
      preferredDate,
      reason,
      urgencyType,
      status: 'submitted'
    });
    setIsSubmitted(true);
  };

  return (
    <div className="main-content">
      <Breadcrumb items={[{ label: 'Home', path: '/' }, { label: 'Urgent Request' }]} />
      <div className="section">
        <h1 className="page-title">Urgent / Standby Service Request</h1>
        <p className="page-subtitle">Request priority service when urgent circumstances arise.</p>

        <div className="alert alert-warning" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem' }}>
          <AlertTriangle size={20} />
          <span>Urgent requests are accepted only when office capacity and available time permit. A standby request does not cancel or replace an existing regular appointment.</span>
        </div>

        {!isSubmitted ? (
          <div className="card">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="grid-2">
                  <div className="form-group">
                    <label>Application/Service</label>
                    <select className="form-control" value={service} onChange={(e) => setService(e.target.value)}>
                      {SERVICES.map(s => (
                        <option key={s.id} value={s.name}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Urgency Type</label>
                    <select className="form-control" value={urgencyType} onChange={(e) => setUrgencyType(e.target.value)}>
                      {URGENCY_TYPES.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label>Preferred Date</label>
                  <input type="date" className="form-control" value={preferredDate} onChange={(e) => setPreferredDate(e.target.value)} required />
                </div>

                <div className="form-group">
                  <label>Reason for Urgency</label>
                  <textarea 
                    className="form-control" 
                    rows="4" 
                    value={reason} 
                    onChange={(e) => setReason(e.target.value)} 
                    placeholder="Provide a valid reason for the urgent request..."
                    required
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-warning btn-lg" style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Zap size={18} /> Request Urgent Slot
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="grid-2">
            <div className="card">
              <div className="card-body" style={{ textAlign: 'center', padding: '3rem 1rem' }}>
                <span className="badge badge-warning" style={{ marginBottom: '1rem', fontSize: '1rem', padding: '0.5rem 1rem' }}>Standby Request Submitted</span>
                <p>Your request will be considered based on available office capacity.</p>
                <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem', justifyContent: 'center' }}>
                  <Link to="/" className="btn btn-primary">Back to Home</Link>
                  <Link to="/my-token" className="btn btn-secondary">View My Token</Link>
                </div>
              </div>
            </div>

            <div>
              {booking && (
                <div className="alert alert-info" style={{ marginBottom: '1rem' }}>
                  <h4 style={{ margin: '0 0 0.5rem' }}>Regular Appointment: Still Scheduled</h4>
                  <div style={{ display: 'flex', gap: '1rem', marginBottom: '0.5rem' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}><Calendar size={16}/> {booking.date}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}><Clock size={16}/> {booking.timeSlot}</span>
                  </div>
                  <p style={{ margin: 0, fontWeight: 'bold' }}>Your regular appointment has NOT been cancelled.</p>
                </div>
              )}
              <div className="alert alert-warning">
                <AlertTriangle size={20} style={{ marginBottom: '0.5rem' }} />
                <p style={{ margin: 0 }}>Urgent requests are processed on a best-effort basis.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrgentRequest;
