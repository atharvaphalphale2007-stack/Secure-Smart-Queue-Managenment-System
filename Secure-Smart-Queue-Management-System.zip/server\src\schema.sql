-- Secure Smart Queue Management System (SQMS)
-- Persistent Relational Schema for SQLite with node:sqlite (Node 24)
-- Enforces Foreign Keys, Check Constraints, Unique Constraints, and Audit Chaining

PRAGMA foreign_keys = ON;

-- 1. Schema Migration History
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 2. Government Offices (Multi-Office Architecture)
CREATE TABLE IF NOT EXISTS offices (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  district TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'Maharashtra',
  address TEXT NOT NULL,
  contact_email TEXT,
  contact_phone TEXT,
  opening_time TEXT NOT NULL DEFAULT '09:00',
  closing_time TEXT NOT NULL DEFAULT '17:30',
  grace_period_mins INTEGER NOT NULL DEFAULT 15,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 3. User Accounts with Role-Based Access Control
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('citizen','officer','admin')),
  name TEXT NOT NULL,
  mobile TEXT,
  email TEXT,
  aadhaar TEXT,
  address TEXT,
  password_hash TEXT NOT NULL,
  designation TEXT,
  department TEXT,
  office_id TEXT REFERENCES offices(id),
  counter INTEGER,
  counter_name TEXT,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- 4. Government Services Catalog
CREATE TABLE IF NOT EXISTS services (
  id TEXT PRIMARY KEY,
  office_id TEXT NOT NULL REFERENCES offices(id),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  processing_time TEXT,
  counter_handling_time_min INTEGER NOT NULL DEFAULT 10,
  fee TEXT NOT NULL DEFAULT '₹0',
  office_address TEXT,
  landmark TEXT,
  eligibility_info TEXT,
  official_source TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  last_updated TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_services_office ON services(office_id);

-- 5. Service Required Documents Checklist
CREATE TABLE IF NOT EXISTS service_required_docs (
  service_id TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  doc_name TEXT NOT NULL,
  xerox INTEGER NOT NULL DEFAULT 0,
  is_mandatory INTEGER NOT NULL DEFAULT 1,
  max_size_mb INTEGER NOT NULL DEFAULT 5,
  allowed_formats TEXT NOT NULL DEFAULT 'application/pdf,image/jpeg,image/png',
  PRIMARY KEY (service_id, doc_name)
);

-- 6. Service Guidelines & Citizen Instructions
CREATE TABLE IF NOT EXISTS service_guidelines (
  service_id TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  guideline TEXT NOT NULL,
  PRIMARY KEY (service_id, guideline)
);

-- 7. Service Counters
CREATE TABLE IF NOT EXISTS counters (
  id INTEGER PRIMARY KEY,
  office_id TEXT NOT NULL REFERENCES offices(id),
  name TEXT NOT NULL,
  service_id TEXT REFERENCES services(id),
  officer_id TEXT REFERENCES users(id),
  current_token TEXT,
  status TEXT NOT NULL DEFAULT 'Available' CHECK (status IN ('Available','Serving','Paused','Closed')),
  is_active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_counters_office ON counters(office_id);

-- 8. Service to Counter Mapping
CREATE TABLE IF NOT EXISTS service_counter_map (
  service_id TEXT PRIMARY KEY REFERENCES services(id) ON DELETE CASCADE,
  counter_id INTEGER NOT NULL REFERENCES counters(id)
);

-- 9. Configurable Time Slots with Max Capacity
CREATE TABLE IF NOT EXISTS time_slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  time TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  max_capacity INTEGER NOT NULL DEFAULT 3,
  is_active INTEGER NOT NULL DEFAULT 1
);

-- 10. Official Holidays & Office Closures
CREATE TABLE IF NOT EXISTS holidays (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  office_id TEXT NOT NULL REFERENCES offices(id),
  date TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  UNIQUE (office_id, date)
);
CREATE INDEX IF NOT EXISTS idx_holidays_date ON holidays(date);

-- 11. Appointments / Bookings
CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  citizen_id TEXT NOT NULL REFERENCES users(id),
  service_id TEXT NOT NULL REFERENCES services(id),
  office_id TEXT NOT NULL REFERENCES offices(id),
  slot_date TEXT NOT NULL,
  slot_time TEXT NOT NULL,
  slot_label TEXT NOT NULL,
  counter_id INTEGER NOT NULL REFERENCES counters(id),
  status TEXT NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','cancelled','rescheduled','completed')),
  cancel_reason TEXT,
  rescheduled_from_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_citizen ON bookings(citizen_id);
CREATE INDEX IF NOT EXISTS idx_bookings_slot ON bookings(slot_date, slot_time, counter_id, status);

-- 12. Digital Queue Tokens & Cryptographic Verification
CREATE TABLE IF NOT EXISTS tokens (
  id TEXT PRIMARY KEY,
  token_number TEXT NOT NULL UNIQUE,
  booking_id TEXT NOT NULL REFERENCES bookings(id),
  citizen_id TEXT NOT NULL REFERENCES users(id),
  service_id TEXT NOT NULL REFERENCES services(id),
  office_id TEXT NOT NULL REFERENCES offices(id),
  counter_id INTEGER NOT NULL REFERENCES counters(id),
  qr_payload TEXT NOT NULL,
  qr_signature TEXT NOT NULL,
  queue_status TEXT NOT NULL DEFAULT 'scheduled' CHECK (queue_status IN ('scheduled','arrived','waiting','serving','completed','absent','cancelled','rescheduled')),
  priority_type TEXT NOT NULL DEFAULT 'normal' CHECK (priority_type IN ('normal','urgent','senior','pwd','medical')),
  priority_reason TEXT,
  priority_authorized_by TEXT REFERENCES users(id),
  stage1_verified_at TEXT,
  stage1_officer_id TEXT REFERENCES users(id),
  stage2_verified_at TEXT,
  stage2_officer_id TEXT REFERENCES users(id),
  called_at TEXT,
  completed_at TEXT,
  arrival_grace_expiry TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tokens_booking ON tokens(booking_id);
CREATE INDEX IF NOT EXISTS idx_tokens_citizen ON tokens(citizen_id);
CREATE INDEX IF NOT EXISTS idx_tokens_counter_status ON tokens(counter_id, queue_status);

-- 13. Turn Reminders (30-Minute & 15-Minute Calls)
CREATE TABLE IF NOT EXISTS token_reminders (
  token_number TEXT PRIMARY KEY REFERENCES tokens(token_number) ON DELETE CASCADE,
  reminder30_min INTEGER NOT NULL DEFAULT 0,
  reminder30_min_time TEXT,
  reminder15_min INTEGER NOT NULL DEFAULT 0,
  reminder15_min_time TEXT,
  channel TEXT NOT NULL DEFAULT 'in_app'
);

-- 14. Citizen Applications
CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  citizen_id TEXT NOT NULL REFERENCES users(id),
  service_id TEXT NOT NULL REFERENCES services(id),
  booking_id TEXT REFERENCES bookings(id),
  token_id TEXT REFERENCES tokens(id),
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','under_verification','correction_required','resubmitted','approved','rejected','completed')),
  officer_notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_applications_citizen ON applications(citizen_id);

-- 15. Immutable Application Transition History
CREATE TABLE IF NOT EXISTS application_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  actor_id TEXT NOT NULL REFERENCES users(id),
  actor_role TEXT NOT NULL,
  from_status TEXT NOT NULL,
  to_status TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_app_history_app ON application_history(application_id);

-- 16. Uploaded Documents & Corrections
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  application_id TEXT REFERENCES applications(id),
  citizen_id TEXT NOT NULL REFERENCES users(id),
  doc_name TEXT NOT NULL,
  original_name TEXT NOT NULL,
  stored_filename TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  mime_type TEXT NOT NULL,
  verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending','verified','rejected','correction_needed')),
  rejection_reason TEXT,
  verified_by TEXT REFERENCES users(id),
  verified_at TEXT,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_documents_app ON documents(application_id);
CREATE INDEX IF NOT EXISTS idx_documents_citizen ON documents(citizen_id);

-- 17. Citizen Grievances
CREATE TABLE IF NOT EXISTS grievances (
  id TEXT PRIMARY KEY,
  citizen_id TEXT NOT NULL REFERENCES users(id),
  app_id TEXT,
  doc_type TEXT,
  error_type TEXT,
  correct_info TEXT,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','in_review','resolved','rejected')),
  resolution_notes TEXT,
  assigned_officer_id TEXT REFERENCES users(id),
  date TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_grievances_citizen ON grievances(citizen_id);

-- 18. Urgent / Tatkal Requests
CREATE TABLE IF NOT EXISTS urgent_requests (
  id TEXT PRIMARY KEY,
  citizen_id TEXT NOT NULL REFERENCES users(id),
  service_id TEXT NOT NULL REFERENCES services(id),
  date TEXT NOT NULL,
  reason TEXT,
  urgency_type TEXT NOT NULL CHECK (urgency_type IN ('medical','education','job','legal','travel','other')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by TEXT REFERENCES users(id),
  decision_notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_urgent_citizen ON urgent_requests(citizen_id);

-- 19. In-App Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  time TEXT NOT NULL,
  read INTEGER NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'info',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);

-- 20. SMS Delivery Log & Gateway Inbox
CREATE TABLE IF NOT EXISTS sms_inbox (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  sender TEXT NOT NULL DEFAULT 'GOV-SQMS',
  time TEXT NOT NULL,
  type TEXT NOT NULL,
  text TEXT NOT NULL,
  delivery_status TEXT NOT NULL DEFAULT 'provider_unconfigured',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sms_user ON sms_inbox(user_id);

-- 21. Tamper-Evident SHA-256 Chained Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL DEFAULT (datetime('now')),
  actor_id TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  details TEXT,
  ip_address TEXT,
  status TEXT NOT NULL DEFAULT 'SUCCESS',
  previous_hash TEXT NOT NULL,
  entry_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs(actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);

-- 22. Cybersecurity & Fraud Alerts
CREATE TABLE IF NOT EXISTS security_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL DEFAULT (datetime('now')),
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  details TEXT NOT NULL,
  ip_address TEXT,
  user_id TEXT REFERENCES users(id),
  resolved INTEGER NOT NULL DEFAULT 0,
  resolved_at TEXT,
  resolved_by TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_sec_alerts_severity ON security_alerts(severity);

-- 23. Centralized System Configuration Table
CREATE TABLE IF NOT EXISTS system_configs (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  description TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by TEXT
);