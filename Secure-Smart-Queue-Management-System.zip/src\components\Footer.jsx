import React from 'react';

/**
 * Footer component for the Smart Queue Management System.
 * Displays portal name, project prototype badge, and demo disclaimer.
 */
export default function Footer() {
  return (
    <footer className="footer">
      <strong>Smart Queue Management System</strong>
      <span>College Project Prototype</span>
      <span>Demo Version — Not an Official Government Portal</span>
    </footer>
  );
}
