import React from 'react';
import { Navigate, useLocation, Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, LogIn } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export default function ProtectedRoute({ children, allowedRoles = [] }) {
  const { user, t } = useAppContext();
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const hasPermission = allowedRoles.includes(user.role);

  if (!hasPermission) {
    return (
      <div style={{ maxWidth: '640px', margin: '3rem auto', padding: '0 1rem', textAlign: 'center' }}>
        <div className="card" style={{ padding: '2.5rem', borderRadius: '1rem', borderTop: '5px solid #dc2626' }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '72px',
              height: '72px',
              borderRadius: '50%',
              background: '#fee2e2',
              color: '#dc2626',
              marginBottom: '1.25rem',
            }}
          >
            <ShieldAlert size={40} />
          </div>

          <h2 style={{ color: '#dc2626', marginBottom: '0.5rem', fontSize: '1.4rem' }}>
            {t('accessDenied') || 'Access Denied — Insufficient Permissions'}
          </h2>

          <p style={{ color: '#64748b', fontSize: '0.95rem', marginBottom: '1.5rem', lineHeight: '1.6' }}>
            {t('accessDeniedMsg') ||
              `Citizens are strictly prohibited from viewing Officer or Admin portals. You are currently logged in as a ${user.role.toUpperCase()}.`}
          </p>

          <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0', marginBottom: '1.75rem', fontSize: '0.85rem', color: '#475569' }}>
            <div><strong>Active Account:</strong> {user.name} ({user.email || user.mobile})</div>
            <div><strong>Role Level:</strong> <span style={{ textTransform: 'uppercase', color: '#dc2626', fontWeight: 700 }}>{user.role}</span></div>
            <div><strong>Required Level:</strong> <span style={{ textTransform: 'uppercase', color: '#0284c7', fontWeight: 700 }}>{allowedRoles.join(' / ')}</span></div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <Link to="/" className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <ArrowLeft size={18} /> Return to Citizen Portal
            </Link>
            <Link to="/login" className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#dc2626', borderColor: '#dc2626' }}>
              <LogIn size={18} /> Switch / Re-authenticate Account
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return children;
}
