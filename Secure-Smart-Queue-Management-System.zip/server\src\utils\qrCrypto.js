// Secure Smart Queue Management System — Cryptographic QR Token Utility
// Generates unguessable, HMAC-SHA256 signed QR payloads without exposing PII.

import crypto from 'node:crypto';

const QR_SECRET = Buffer.from(
  process.env.QR_HMAC_SECRET || 'sqms-qr-hmac-secret-kiosk-counter-2026-secure',
  'utf-8'
);

export function generateQrPayload({ tokenId, tokenNumber, officeId, serviceId, expiryMinutes = 720 }) {
  const nonce = crypto.randomBytes(8).toString('hex');
  const now = Math.floor(Date.now() / 1000);
  const exp = now + (expiryMinutes * 60);

  const payload = {
    v: 1,
    tid: tokenId,
    tnum: tokenNumber,
    off: officeId,
    sid: serviceId,
    exp,
    nce: nonce,
  };

  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', QR_SECRET)
    .update(payloadB64)
    .digest('base64url');

  const qrString = `SQMS.v1.${payloadB64}.${signature}`;

  return {
    qrString,
    signature,
    payloadString: JSON.stringify(payload),
    expiresAt: new Date(exp * 1000).toISOString(),
  };
}

export function verifyQrSignature(qrString) {
  if (!qrString || typeof qrString !== 'string') {
    return { valid: false, reason: 'Empty or invalid QR code format' };
  }

  // Handle standard SQMS.v1 format or fallback legacy format
  const parts = qrString.trim().split('.');
  if (parts.length !== 4 || parts[0] !== 'SQMS' || parts[1] !== 'v1') {
    return { valid: false, reason: 'Invalid QR token envelope' };
  }

  const [, , payloadB64, providedSig] = parts;

  // Verify HMAC signature in constant time
  const expectedSig = crypto
    .createHmac('sha256', QR_SECRET)
    .update(payloadB64)
    .digest('base64url');

  const providedBuf = Buffer.from(providedSig);
  const expectedBuf = Buffer.from(expectedSig);

  if (providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) {
    return { valid: false, reason: 'Cryptographic signature verification failed (Tampered QR)' };
  }

  let payload;
  try {
    const jsonStr = Buffer.from(payloadB64, 'base64url').toString('utf-8');
    payload = JSON.parse(jsonStr);
  } catch {
    return { valid: false, reason: 'Malformed QR payload' };
  }

  // Check expiration
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    return { valid: false, reason: 'QR token has expired', expired: true, payload };
  }

  return {
    valid: true,
    payload,
  };
}

export default { generateQrPayload, verifyQrSignature };
