// Secure Smart Queue Management System — Authentication & RBAC Middleware
import { jwtVerify, SignJWT } from 'jose';
import { getDb } from '../db.js';
import { logAuditEvent } from '../utils/auditLogger.js';

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'sqms-super-secure-production-jwt-key-2026-government-standard'
);
const JWT_ISS = 'sqms-server';
const JWT_AUD = 'sqms-client';
const EXPIRES_IN = '12h';

// In-memory rate-limiter for sensitive endpoints like login & QR verification
const rateLimits = new Map();

export function rateLimiter({ windowMs = 60000, maxRequests = 10, keyPrefix = 'ip' }) {
  return (req, res, next) => {
    const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
    const key = `${keyPrefix}:${ip}`;
    const now = Date.now();

    const record = rateLimits.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > record.resetAt) {
      record.count = 0;
      record.resetAt = now + windowMs;
    }

    record.count++;
    rateLimits.set(key, record);

    if (record.count > maxRequests) {
      const retryAfterSec = Math.ceil((record.resetAt - now) / 1000);
      res.setHeader('Retry-After', retryAfterSec);

      logAuditEvent({
        actorId: 'ANONYMOUS',
        actorRole: 'anonymous',
        action: 'RATE_LIMIT_EXCEEDED',
        resourceType: 'endpoint',
        resourceId: req.originalUrl,
        details: `Exceeded ${maxRequests} requests per ${windowMs / 1000}s`,
        ipAddress: ip,
        status: 'BLOCKED',
      });

      return res.status(429).json({
        error: 'Too many requests. Please wait before retrying.',
        retryAfter: retryAfterSec,
      });
    }

    next();
  };
}

export async function verifyJwt(token) {
  const { payload } = await jwtVerify(token, JWT_SECRET, {
    issuer: JWT_ISS,
    audience: JWT_AUD,
  });
  return payload;
}

export async function signJwt(user) {
  return new SignJWT({
    sub: user.id,
    role: user.role,
    name: user.name,
    email: user.email,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(JWT_ISS)
    .setAudience(JWT_AUD)
    .setExpirationTime(EXPIRES_IN)
    .sign(JWT_SECRET);
}

export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'Missing authorization token' });
  }

  verifyJwt(token)
    .then((payload) => {
      const db = getDb();
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
      if (!user) {
        return res.status(401).json({ error: 'User not found or deactivated' });
      }

      // Check account lockout
      if (user.locked_until && new Date(user.locked_until) > new Date()) {
        return res.status(403).json({ error: 'Account temporarily locked due to security policy' });
      }

      req.user = user;
      next();
    })
    .catch(() => res.status(401).json({ error: 'Invalid or expired token' }));
}

export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      logAuditEvent({
        actorId: req.user.id,
        actorRole: req.user.role,
        action: 'UNAUTHORIZED_ACCESS_ATTEMPT',
        resourceType: 'route',
        resourceId: req.originalUrl,
        details: `User role '${req.user.role}' attempted to access endpoint restricted to [${allowedRoles.join(', ')}]`,
        ipAddress: req.ip || '127.0.0.1',
        status: 'DENIED',
      });

      return res.status(403).json({
        error: `Access denied. Requires one of roles: ${allowedRoles.join(', ')}`,
      });
    }

    next();
  };
}

export function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next();

  verifyJwt(token)
    .then((payload) => {
      const db = getDb();
      req.user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
      next();
    })
    .catch(() => next());
}

export default {
  authMiddleware,
  requireRole,
  optionalAuth,
  rateLimiter,
  verifyJwt,
  signJwt,
};