import React from 'react';
import { useAppContext } from '../context/AppContext';
import { CheckCheck, BellOff, X } from 'lucide-react';

/**
 * Notification Dropdown component displayed when the header notification bell is clicked.
 * Lists notifications with read/unread statuses and lets users mark individual or all as read.
 *
 * @param {{ isOpen: boolean, onClose: () => void }} props
 */
export default function NotificationDropdown({ isOpen, onClose }) {
  const { notifications = [], markNotificationRead, markAllNotificationsRead } = useAppContext();

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div
      className="notification-dropdown"
      role="region"
      aria-label="Citizen Notifications"
    >
      <div className="notification-dropdown-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <h3>Notifications {unreadCount > 0 ? `(${unreadCount})` : ''}</h3>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          {unreadCount > 0 && (
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={markAllNotificationsRead}
              style={{
                padding: '3px 8px',
                fontSize: '0.72rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
              }}
              title="Mark all notifications as read"
            >
              <CheckCheck size={13} />
              <span>Mark read</span>
            </button>
          )}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--gray-400)',
                cursor: 'pointer',
                padding: '2px',
                display: 'flex',
                alignItems: 'center',
                borderRadius: '4px',
              }}
              aria-label="Close notification panel"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      <div style={{ maxHeight: '380px', overflowY: 'auto' }}>
        {notifications.length === 0 ? (
          <div
            style={{
              padding: '32px 16px',
              textAlign: 'center',
              color: 'var(--gray-500)',
              fontSize: '0.85rem',
            }}
          >
            <BellOff size={28} style={{ margin: '0 auto 8px', opacity: 0.5, display: 'block' }} />
            <p>No notifications yet</p>
          </div>
        ) : (
          notifications.map((notification) => {
            const dotType = notification.type ? notification.type.toLowerCase() : 'info';

            return (
              <div
                key={notification.id}
                className={`notification-item ${!notification.read ? 'unread' : ''}`}
                onClick={() => {
                  if (!notification.read && markNotificationRead) {
                    markNotificationRead(notification.id);
                  }
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    if (!notification.read && markNotificationRead) {
                      markNotificationRead(notification.id);
                    }
                  }
                }}
              >
                <span className={`notification-dot ${dotType}`} aria-hidden="true" />
                <div className="notification-text">
                  <p>{notification.message}</p>
                  <small>{notification.time}</small>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
