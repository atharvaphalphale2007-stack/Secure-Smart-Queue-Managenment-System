import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ScanLine, CheckCircle, XCircle, ArrowRight, ShieldCheck, ShieldAlert } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';
import { useAppContext } from '../context/AppContext';
import { api } from '../utils/api';

const CheckIn = () => {
  const [scanState, setScanState] = useState('scanning'); // scanning | success | error
  const [errorMessage, setErrorMessage] = useState('');
  const [verifiedDetails, setVerifiedDetails] = useState(null);
  const [manualToken, setManualToken] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { token, setCheckedIn, addToast } = useAppContext();

  const handleVerify = async (qrPayload, tokenNum) => {
    setIsLoading(true);
    setErrorMessage('');
    try {
      const res = await api.verifyStage1Arrival(qrPayload, tokenNum);
      if (res?.success) {
        setVerifiedDetails(res);
        setScanState('success');
        setCheckedIn(true);
        addToast(`Stage 1 Verified: ${res.tokenNumber} queued at ${res.counter}`, 'success');
      }
    } catch (err) {
      setErrorMessage(err.message || 'Verification rejected by security server');
      setScanState('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleActiveTokenScan = () => {
    const targetToken = token?.tokenNumber || 'A-042';
    const targetQr = token?.qrString || '';
    handleVerify(targetQr, targetToken);
  };

  const handleTamperedTokenTest = () => {
    // Deliberately forged signature to demonstrate cryptographic rejection
    const forgedQr = 'SQMS.v1.eyJ2IjoxLCJ0aWQiOiJUT0stRkFLRSIsInRudW0iOiJBLTk5OSJ9.bad_forged_signature_attack';
    handleVerify(forgedQr, 'A-999');
  };

  return (
    <div className="page-container">
      <Breadcrumb
        items={[
          { label: 'Home', path: '/' },
          { label: 'Check-in' }
        ]}
      />

      <div className="section">
        <h1 className="page-title">Office Check-in Kiosk (Stage 1)</h1>
        <p className="page-subtitle">
          Entrance physical arrival verification with cryptographic HMAC-SHA256 signature validation.
        </p>

        {scanState === 'scanning' && (
          <div className="card" style={{ maxWidth: '520px', margin: '0 auto' }}>
            <div className="card-body" style={{ textAlign: 'center' }}>
              <div
                className="scanner-frame"
                style={{
                  margin: '1.5rem auto',
                  width: '240px',
                  height: '240px',
                  position: 'relative',
                  border: '2px solid #ddd',
                  borderRadius: '12px',
                  overflow: 'hidden',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: '#f8fafc',
                }}
              >
                <div
                  className="scanner-line"
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '2px',
                    backgroundColor: '#2563eb',
                    boxShadow: '0 0 10px #2563eb',
                    animation: 'scan 2s infinite linear',
                  }}
                />
                <div className="scanner-corners" />
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', color: '#64748b' }}>
                  <ScanLine size={48} style={{ marginBottom: '0.75rem', color: '#0284c7' }} />
                  <span style={{ fontWeight: 600 }}>Optical QR Scanner Ready</span>
                  <span style={{ fontSize: '0.78rem', color: '#94a3b8', marginTop: '4px' }}>
                    Present appointment QR pass
                  </span>
                </div>
              </div>

              {/* Manual Token Number Input */}
              <div style={{ marginBottom: '1.5rem', textAlign: 'left' }}>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '6px' }}>
                  Or enter Token Number manually:
                </label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input
                    type="text"
                    value={manualToken}
                    onChange={(e) => setManualToken(e.target.value.toUpperCase())}
                    placeholder="e.g. A-042"
                    style={{
                      flex: 1,
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: '1px solid #cbd5e1',
                      fontSize: '0.9rem',
                    }}
                  />
                  <button
                    className="btn btn-primary"
                    disabled={!manualToken || isLoading}
                    onClick={() => handleVerify(null, manualToken)}
                    style={{ padding: '8px 16px' }}
                  >
                    Check-in
                  </button>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
                <button
                  className="btn btn-primary"
                  onClick={handleActiveTokenScan}
                  disabled={isLoading}
                  style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
                >
                  <ShieldCheck size={16} /> Scan Active Token ({token?.tokenNumber || 'A-042'})
                </button>
                <button
                  className="btn btn-outline"
                  style={{ color: '#ef4444', borderColor: '#ef4444', display: 'flex', alignItems: 'center', gap: '6px' }}
                  onClick={handleTamperedTokenTest}
                  disabled={isLoading}
                >
                  <ShieldAlert size={16} /> Test Tampered / Forged QR
                </button>
              </div>
            </div>
          </div>
        )}

        {scanState === 'success' && (
          <div className="card" style={{ maxWidth: '580px', margin: '0 auto', borderColor: '#22c55e' }}>
            <div className="card-body" style={{ textAlign: 'center' }}>
              <CheckCircle size={64} color="#22c55e" style={{ margin: '0 auto 1rem auto' }} />
              <h2 style={{ color: '#166534', marginBottom: '0.5rem' }}>✓ Stage 1 Arrival Verified</h2>
              <p style={{ color: '#475569', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
                Cryptographic authentication successful. Citizen arrival timestamp officially logged in central queue registry.
              </p>

              <div style={{ backgroundColor: '#f0fdf4', padding: '1.25rem', borderRadius: '8px', marginBottom: '1.5rem', textAlign: 'left', border: '1px solid #bbf7d0' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', fontSize: '0.9rem' }}>
                  <p style={{ margin: 0 }}><strong>Token:</strong> {verifiedDetails?.tokenNumber || token?.tokenNumber || 'A-042'}</p>
                  <p style={{ margin: 0 }}><strong>Service:</strong> {verifiedDetails?.service || token?.service || 'Income Certificate'}</p>
                  <p style={{ margin: 0 }}><strong>Assigned Counter:</strong> {verifiedDetails?.counter || 'Counter 3'}</p>
                  <p style={{ margin: 0 }}><strong>Queue Status:</strong> <span style={{ color: '#16a34a', fontWeight: 600 }}>QUEUED & WAITING</span></p>
                  <p style={{ margin: 0, gridColumn: 'span 2' }}>
                    <strong>Verified At:</strong> {verifiedDetails?.verifiedAt ? new Date(verifiedDetails.verifiedAt).toLocaleTimeString('en-IN') : 'Just now'}
                  </p>
                </div>
              </div>

              <div className="alert alert-success" style={{ marginBottom: '1.5rem', fontSize: '0.88rem' }}>
                Please proceed to the Waiting Lounge. Your token will be called on the Public Audio Display Board.
              </div>

              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
                <Link to="/queue" className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  Track Live Queue <ArrowRight size={16} />
                </Link>
                <Link to="/my-token" className="btn btn-secondary">
                  View My Token Pass
                </Link>
              </div>
            </div>
          </div>
        )}

        {scanState === 'error' && (
          <div className="card" style={{ maxWidth: '520px', margin: '0 auto', borderColor: '#ef4444' }}>
            <div className="card-body" style={{ textAlign: 'center' }}>
              <XCircle size={64} color="#ef4444" style={{ margin: '0 auto 1rem auto' }} />
              <h2 style={{ color: '#991b1b', marginBottom: '0.5rem' }}>✕ Security Verification Failed</h2>

              <div className="alert alert-error" style={{ marginBottom: '1.5rem', textAlign: 'left' }}>
                <strong>Rejection Reason:</strong>
                <p style={{ margin: '4px 0 0', fontSize: '0.88rem' }}>
                  {errorMessage || 'Token signature mismatch or already used. Incident has been flagged for audit review.'}
                </p>
              </div>

              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
                <button className="btn btn-primary" onClick={() => setScanState('scanning')}>
                  Scan Again
                </button>
                <Link to="/" className="btn btn-outline">
                  Return to Portal Home
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CheckIn;
