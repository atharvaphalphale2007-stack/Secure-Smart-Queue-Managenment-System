// Secure Smart Queue Management System — Automated Database Restore Script
// Validates SHA-256 checksum against metadata, preserves active DB snapshot, and verifies integrity.

import { DatabaseSync } from 'node:sqlite';
import { copyFileSync, existsSync, readdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, basename } from 'node:path';
import { createHash } from 'node:crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, '..', 'data');
const BACKUP_DIR = join(__dirname, '..', 'backups');
const DEFAULT_DB_PATH = join(DATA_DIR, 'sqms.db');

export function performRestore(specificBackupFile = null, customDbPath = null) {
  const dbPath = customDbPath || process.env.DB_PATH || DEFAULT_DB_PATH;

  if (!existsSync(BACKUP_DIR)) {
    throw new Error(`Backup directory does not exist: ${BACKUP_DIR}`);
  }

  let selectedBackup = specificBackupFile;

  // If no specific file provided, find the latest backup
  if (!selectedBackup) {
    const files = readdirSync(BACKUP_DIR)
      .filter((f) => f.startsWith('sqms_backup_') && f.endsWith('.db'))
      .sort()
      .reverse();

    if (files.length === 0) {
      throw new Error(`No database backups found in ${BACKUP_DIR}`);
    }
    selectedBackup = files[0];
  }

  const backupFilePath = selectedBackup.includes('/') || selectedBackup.includes('\\')
    ? selectedBackup
    : join(BACKUP_DIR, selectedBackup);

  if (!existsSync(backupFilePath)) {
    throw new Error(`Backup file does not exist: ${backupFilePath}`);
  }

  console.log(`[SQMS-RESTORE] Initiating database restore from: ${basename(backupFilePath)}`);

  // 1. Check metadata and verify SHA-256 checksum
  const metaFilePath = backupFilePath.replace(/\.db$/, '.meta.json');
  if (existsSync(metaFilePath)) {
    const meta = JSON.parse(readFileSync(metaFilePath, 'utf-8'));
    const fileBytes = readFileSync(backupFilePath);
    const calculatedSha256 = createHash('sha256').update(fileBytes).digest('hex');

    if (calculatedSha256 !== meta.sha256) {
      throw new Error(
        `CRITICAL CHECKSUM MISMATCH! Expected ${meta.sha256}, got ${calculatedSha256}. Backup may be corrupted or tampered.`
      );
    }
    console.log(`[SQMS-RESTORE] Checksum verified successfully against metadata.`);
  } else {
    console.warn(`[SQMS-RESTORE] Notice: No metadata file found at ${basename(metaFilePath)}. Proceeding with direct restore.`);
  }

  // 2. Safety snapshot of current active DB (if exists)
  if (existsSync(dbPath)) {
    const preRestoreSnapshot = `${dbPath}.pre-restore.${Date.now()}`;
    copyFileSync(dbPath, preRestoreSnapshot);
    console.log(`[SQMS-RESTORE] Active database preserved to: ${basename(preRestoreSnapshot)}`);
  }

  // 3. Restore backup
  copyFileSync(backupFilePath, dbPath);

  // 4. Validate integrity of restored DB
  const db = new DatabaseSync(dbPath);
  try {
    const integrityRow = db.prepare('PRAGMA integrity_check;').get();
    const integrityStatus = integrityRow ? Object.values(integrityRow)[0] : 'unknown';

    if (integrityStatus !== 'ok') {
      throw new Error(`Restored database failed integrity check: ${integrityStatus}`);
    }

    const userCount = db.prepare('SELECT COUNT(*) as count FROM users;').get().count;
    const tokenCount = db.prepare('SELECT COUNT(*) as count FROM tokens;').get().count;

    console.log(`[SQMS-RESTORE] SUCCESS: Database restored successfully.`);
    console.log(`[SQMS-RESTORE] Verified integrity: ok | Users: ${userCount} | Tokens: ${tokenCount}`);
  } finally {
    db.close();
  }

  return { success: true, restoredFrom: backupFilePath, targetDatabase: dbPath };
}

// Standalone execution
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    const backupArg = process.argv[2] || null;
    performRestore(backupArg);
  } catch (err) {
    console.error(`[SQMS-RESTORE] FAILED:`, err.message);
    process.exit(1);
  }
}
