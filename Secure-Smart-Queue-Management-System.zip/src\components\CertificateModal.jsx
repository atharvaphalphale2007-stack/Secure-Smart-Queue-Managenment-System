import React, { useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Award, CheckCircle2 } from 'lucide-react';

/**
 * CertificateModal displays an authentic-looking Indian Government Certificate
 * in a modal preview dialog with watermarking, digital signature verification,
 * and a clear prototype demo disclaimer.
 *
 * @param {{
 *   isOpen: boolean,
 *   onClose: () => void,
 *   document?: {
 *     id?: string,
 *     type?: string,
 *     name?: string,
 *     address?: string,
 *     income?: string,
 *     issueDate?: string,
 *     officer?: string
 *   }
 * }} props
 */
export default function CertificateModal({ isOpen, onClose, document: doc }) {
  // Listen for Escape key to close modal
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose?.();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Fallback defaults for missing fields
  const certData = {
    id: doc?.id || 'INC-MH-2026-0042',
    type: doc?.type || 'Income Certificate',
    name: doc?.name || 'Rahul Patil',
    address: doc?.address || 'Pune, Maharashtra',
    income: doc?.income || '₹2,50,000',
    issueDate: doc?.issueDate || '25 September 2026',
    officer: doc?.officer || 'Priya Sharma (Tehsildar)',
  };

  const qrValue = certData.id ? `DEMO-CERT-VERIFY:${certData.id}` : 'DEMO-CERT-VERIFY';

  return (
    <div
      className="modal-overlay"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="cert-modal-title"
    >
      <div
        className="modal-content"
        style={{ maxWidth: '680px', width: '100%' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Award size={20} color="var(--primary-800)" />
            <h2 id="cert-modal-title">Official Certificate Preview</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--gray-500)',
              display: 'flex',
              alignItems: 'center',
              padding: '4px',
              borderRadius: '4px',
            }}
            aria-label="Close certificate modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body containing Government Certificate */}
        <div className="modal-body" style={{ background: 'var(--gray-50)', padding: '24px' }}>
          <div className="certificate">
            {/* Watermark */}
            <div className="certificate-watermark">DEMO DOCUMENT</div>

            {/* Certificate Header */}
            <div className="certificate-header">
              <h2>Government of Maharashtra</h2>
              <p style={{ fontSize: '0.84rem', color: 'var(--gray-600)', margin: '4px 0 8px 0' }}>
                Government Citizen Service Centre
              </p>
              <h1>{certData.type ? certData.type.toUpperCase() : 'INCOME CERTIFICATE'}</h1>
            </div>

            {/* Certificate Body Fields */}
            <div className="certificate-body">
              <div className="field">
                <span className="field-label">Certificate No:</span>
                <span style={{ fontWeight: 600, color: 'var(--primary-900)' }}>{certData.id}</span>
              </div>
              <div className="field">
                <span className="field-label">Name:</span>
                <span>{certData.name}</span>
              </div>
              <div className="field">
                <span className="field-label">Address:</span>
                <span>{certData.address}</span>
              </div>
              <div className="field">
                <span className="field-label">Annual Income:</span>
                <span style={{ fontWeight: 600 }}>{certData.income}</span>
              </div>
              <div className="field">
                <span className="field-label">Issue Date:</span>
                <span>{certData.issueDate}</span>
              </div>
              <div className="field">
                <span className="field-label">Authorized Officer:</span>
                <span>{certData.officer}</span>
              </div>
            </div>

            {/* Certificate Footer with QR Code and Digital Signature */}
            <div className="certificate-footer">
              <div style={{ textAlign: 'left' }}>
                <QRCodeSVG value={qrValue} size={64} level="M" />
                <div style={{ fontSize: '0.68rem', color: 'var(--gray-500)', marginTop: '4px' }}>
                  Scan to Verify
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    gap: '4px',
                    color: 'var(--success)',
                    fontWeight: 600,
                    fontSize: '0.85rem',
                  }}
                >
                  <CheckCircle2 size={16} />
                  <span>Digital Signature</span>
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--gray-700)', fontWeight: 500, marginTop: '2px' }}>
                  {certData.officer}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--gray-500)' }}>
                  Authorized Signatory, Govt. of Maharashtra
                </div>
              </div>
            </div>

            {/* Demo Watermark Banner */}
            <div className="certificate-demo-banner">
              DEMO DOCUMENT — NOT AN OFFICIAL GOVERNMENT CERTIFICATE
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="modal-footer">
          <button type="button" className="btn btn-primary" onClick={onClose}>
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
}
