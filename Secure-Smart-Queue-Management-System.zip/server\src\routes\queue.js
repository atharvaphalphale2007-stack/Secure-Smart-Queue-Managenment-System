// Secure Smart Queue Management System — Two-Stage QR Verification & Queue Engine
// Stage 1 (Arrival Kiosk) & Stage 2 (Service Counter) + Multi-Counter Queue State Machine

import { Router } from 'express';
import { getDb } from '../db.js';
import { requireRole, rateLimiter } from '../middleware/auth.js';
import { logAuditEvent } from '../utils/auditLogger.js';
import { verifyQrSignature, generateQrPayload } from '../utils/qrCrypto.js';

const router = Router();
const qrLimiter = rateLimiter({ windowMs: 60000, maxRequests: 20, keyPrefix: 'qr-verify' });

// Helper: Calculate waiting time for a token
function calculateEstimatedWait(db, tokenRow) {
  if (tokenRow.queue_status === 'serving') return 0;
  if (['completed', 'absent', 'cancelled'].includes(tokenRow.queue_status)) return null;

  // 1. Get position ahead in this counter's queue
  const aheadCount = db.prepare(`
    SELECT COUNT(*) AS c
    FROM tokens
    WHERE counter_id = ?
      AND queue_status IN ('waiting', 'arrived')
      AND (
        (priority_type = 'urgent' AND ? != 'urgent')
        OR (priority_type = ? AND created_at < ?)
      )
  `).get(tokenRow.counter_id, tokenRow.priority_type, tokenRow.priority_type, tokenRow.created_at)?.c || 0;

  // 2. Fetch service average handling time
  const service = db.prepare('SELECT counter_handling_time_min FROM services WHERE id = ?').get(tokenRow.service_id);
  const avgMins = service?.counter_handling_time_min || 10;

  // 3. Check active counters for this service
  const activeCounters = db.prepare(`
    SELECT COUNT(*) AS c FROM counters
    WHERE (service_id = ? OR id = ?) AND status IN ('Available', 'Serving') AND is_active = 1
  `).get(tokenRow.service_id, tokenRow.counter_id)?.c || 1;

  const waitMinutes = Math.max(2, Math.round((aheadCount * avgMins) / Math.max(1, activeCounters)));

  return {
    aheadInQueue: aheadCount,
    estimatedMinutes: waitMinutes,
    lastCalculatedAt: new Date().toISOString(),
    counterId: tokenRow.counter_id,
  };
}

// GET /api/queue/counters — Status of all counters
router.get('/counters', (_req, res) => {
  const db = getDb();
  const counters = db.prepare(`
    SELECT c.*, s.name AS service_name, u.name AS officer_name
    FROM counters c
    LEFT JOIN services s ON s.id = c.service_id
    LEFT JOIN users u ON u.id = c.officer_id
    WHERE c.is_active = 1
    ORDER BY c.id ASC
  `).all();
  res.json(counters);
});

// GET /api/queue/live — Public Display Board and Active Queue State
router.get('/live', (req, res) => {
  const { counterId, officeId = 'OFFICE-PUNE-01' } = req.query;
  const db = getDb();

  let tokensQuery = `
    SELECT
      t.id, t.token_number, t.counter_id, t.queue_status, t.priority_type,
      t.stage1_verified_at, t.stage2_verified_at, t.called_at,
      s.name AS service_name,
      c.name AS counter_name,
      u.name AS citizen_name
    FROM tokens t
    JOIN services s ON s.id = t.service_id
    JOIN counters c ON c.id = t.counter_id
    JOIN users u ON u.id = t.citizen_id
    WHERE t.office_id = ? AND t.queue_status IN ('waiting', 'arrived', 'serving')
  `;
  const params = [officeId];

  if (counterId) {
    tokensQuery += ' AND t.counter_id = ?';
    params.push(counterId);
  }

  tokensQuery += " ORDER BY CASE WHEN t.priority_type = 'urgent' THEN 0 ELSE 1 END, t.created_at ASC";

  const activeTokens = db.prepare(tokensQuery).all(...params);

  // Counters summary
  const counters = db.prepare(`
    SELECT c.id, c.name, c.current_token, c.status, s.name AS service_name, u.name AS officer_name
    FROM counters c
    LEFT JOIN services s ON s.id = c.service_id
    LEFT JOIN users u ON u.id = c.officer_id
    WHERE c.office_id = ? AND c.is_active = 1
  `).all(officeId);

  res.json({
    officeId,
    timestamp: new Date().toISOString(),
    counters,
    queue: activeTokens,
  });
});

// GET /api/queue/token/:tokenNumber — Inspect specific token state and wait time
router.get('/token/:tokenNumber', (req, res) => {
  const db = getDb();
  const token = db.prepare(`
    SELECT
      t.*,
      b.slot_date, b.slot_time,
      s.name AS service_name, s.fee, s.counter_handling_time_min,
      c.name AS counter_name,
      u.name AS citizen_name, u.mobile AS citizen_mobile,
      o.name AS office_name, o.grace_period_mins
    FROM tokens t
    JOIN bookings b ON b.id = t.booking_id
    JOIN services s ON s.id = t.service_id
    JOIN counters c ON c.id = t.counter_id
    JOIN users u ON u.id = t.citizen_id
    JOIN offices o ON o.id = t.office_id
    WHERE t.token_number = ?
  `).get(req.params.tokenNumber.toUpperCase());

  if (!token) return res.status(404).json({ error: 'Token not found' });

  // Privacy check: citizens can only view their own token details (or officer/admin)
  if (req.user.role === 'citizen' && token.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized to view another citizen\'s token details' });
  }

  const waitPrediction = calculateEstimatedWait(db, token);
  const reminders = db.prepare('SELECT * FROM token_reminders WHERE token_number = ?').get(token.token_number);

  res.json({
    ...token,
    waitPrediction,
    reminders: reminders || {},
  });
});

// POST /api/queue/verify-stage1 — Stage 1: Entrance Physical Arrival QR Check-in
router.post('/verify-stage1', qrLimiter, (req, res) => {
  const { qrString, tokenNumber } = req.body || {};
  const db = getDb();
  const officerId = req.user?.id || 'KIOSK-SYSTEM';

  if (!qrString && !tokenNumber) {
    return res.status(400).json({ error: 'QR string or token number is required' });
  }

  let verifiedTokenNumber = tokenNumber;

  // 1. If QR string provided, verify cryptographic HMAC signature
  if (qrString) {
    const qrResult = verifyQrSignature(qrString);
    if (!qrResult.valid) {
      logAuditEvent({
        actorId: officerId,
        actorRole: req.user?.role || 'kiosk',
        action: 'QR_VERIFY_STAGE1_TAMPERED',
        resourceType: 'qr',
        resourceId: qrString.slice(0, 30),
        details: `Cryptographic rejection: ${qrResult.reason}`,
        ipAddress: req.ip || '127.0.0.1',
        status: 'TAMPER_DETECTED',
      });

      db.prepare('INSERT INTO security_alerts (alert_type, severity, details, ip_address, user_id) VALUES (?, ?, ?, ?, ?)')
        .run('TAMPERED_QR_SCAN', 'high', `Scan of invalid/tampered QR: ${qrResult.reason}`, req.ip || '127.0.0.1', req.user?.id || null);

      return res.status(400).json({
        error: 'Invalid or forged QR token: ' + qrResult.reason,
        stage: 'Stage 1 — Physical Arrival',
      });
    }

    verifiedTokenNumber = qrResult.payload.tnum;
  }

  // 2. Look up token in database
  const token = db.prepare(`
    SELECT t.*, b.slot_date, b.slot_time, b.status AS booking_status, s.name AS service_name, c.name AS counter_name
    FROM tokens t
    JOIN bookings b ON b.id = t.booking_id
    JOIN services s ON s.id = t.service_id
    JOIN counters c ON c.id = t.counter_id
    WHERE t.token_number = ?
  `).get(verifiedTokenNumber.toUpperCase());

  if (!token) {
    return res.status(404).json({ error: 'Token not found in official booking registry' });
  }

  // 3. Replay Protection: Check if already verified in Stage 1
  if (token.stage1_verified_at) {
    return res.status(409).json({
      error: `Physical arrival already verified on ${new Date(token.stage1_verified_at).toLocaleTimeString()}`,
      tokenNumber: token.token_number,
      queueStatus: token.queue_status,
      counterName: token.counter_name,
    });
  }

  // 4. Validate booking status
  if (token.booking_status === 'cancelled' || token.queue_status === 'cancelled') {
    return res.status(400).json({ error: 'Appointment has been cancelled and cannot be checked in' });
  }

  const nowIso = new Date().toISOString();

  // 5. Atomic state update to 'waiting'
  db.transaction(() => {
    db.prepare(`
      UPDATE tokens SET
        stage1_verified_at = ?,
        stage1_officer_id = ?,
        queue_status = 'waiting'
      WHERE id = ?
    `).run(nowIso, officerId, token.id);

    // Update application stage to 'under_verification'
    db.prepare(`
      UPDATE applications SET status = 'under_verification', updated_at = datetime('now') WHERE token_id = ?
    `).run(token.id);

    // Log history
    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      SELECT id, ?, 'officer', 'submitted', 'under_verification', 'Entrance kiosk physical QR arrival verified'
      FROM applications WHERE token_id = ?
    `).run(officerId, token.id);

    // Add in-app confirmation
    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, 'success')
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      token.citizen_id,
      `Physical check-in confirmed at entrance kiosk. You are now queued at ${token.counter_name}.`,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    );
  });

  logAuditEvent({
    actorId: officerId,
    actorRole: req.user?.role || 'kiosk',
    action: 'STAGE1_ARRIVAL_VERIFIED',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Physical arrival verified. Token queued at Counter ${token.counter_id}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({
    success: true,
    stage: 'Stage 1: Physical Arrival Verified',
    tokenNumber: token.token_number,
    service: token.service_name,
    counter: token.counter_name,
    counterId: token.counter_id,
    verifiedAt: nowIso,
    status: 'QUEUED_FOR_SERVICE',
  });
});

// POST /api/queue/verify-stage2 — Stage 2: Service-Counter Verification by Officer
router.post('/verify-stage2', requireRole('officer', 'admin'), (req, res) => {
  const { tokenNumber, counterId } = req.body || {};
  const officerId = req.user.id;

  if (!tokenNumber) {
    return res.status(400).json({ error: 'tokenNumber is required' });
  }

  const db = getDb();
  const token = db.prepare(`
    SELECT t.*, s.name AS service_name, c.name AS counter_name, u.name AS citizen_name
    FROM tokens t
    JOIN services s ON s.id = t.service_id
    JOIN counters c ON c.id = t.counter_id
    JOIN users u ON u.id = t.citizen_id
    WHERE t.token_number = ?
  `).get(tokenNumber.toUpperCase());

  if (!token) return res.status(404).json({ error: 'Token not found' });

  // Critical Gate: Stage 1 Physical Arrival MUST be completed before Stage 2
  if (!token.stage1_verified_at) {
    return res.status(400).json({
      error: 'Citizen has NOT completed Stage 1 physical arrival check-in at the entrance kiosk!',
      requiresStage1: true,
    });
  }

  // Cross-counter check: ensure token belongs to this counter or officer has clearance
  const assignedCounter = counterId || req.user.counter || token.counter_id;

  const nowIso = new Date().toISOString();

  db.transaction(() => {
    db.prepare(`
      UPDATE tokens SET
        stage2_verified_at = ?,
        stage2_officer_id = ?,
        called_at = ?,
        queue_status = 'serving',
        counter_id = ?
      WHERE id = ?
    `).run(nowIso, officerId, nowIso, assignedCounter, token.id);

    // Update Counter current token
    db.prepare(`
      UPDATE counters SET current_token = ?, status = 'Serving', officer_id = ? WHERE id = ?
    `).run(token.token_number, officerId, assignedCounter);
  });

  logAuditEvent({
    actorId: officerId,
    actorRole: 'officer',
    action: 'STAGE2_COUNTER_VERIFIED',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Officer ${req.user.name} initiated service for Token ${token.token_number} at Counter ${assignedCounter}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({
    success: true,
    stage: 'Stage 2: Counter Service Verification Complete',
    tokenNumber: token.token_number,
    citizenName: token.citizen_name,
    service: token.service_name,
    counterId: assignedCounter,
    status: 'SERVING',
    verifiedAt: nowIso,
  });
});

// POST /api/queue/call-next — Officer calls next waiting citizen at their counter
router.post('/call-next', requireRole('officer', 'admin'), (req, res) => {
  const counterId = req.body?.counterId || req.user.counter || 3;
  const db = getDb();

  // Find next waiting token that has completed Stage 1 physical arrival
  // Priority rule: Urgent first, then earliest created
  const nextToken = db.prepare(`
    SELECT t.*, u.name AS citizen_name, s.name AS service_name
    FROM tokens t
    JOIN users u ON u.id = t.citizen_id
    JOIN services s ON s.id = t.service_id
    WHERE t.counter_id = ?
      AND t.queue_status = 'waiting'
      AND t.stage1_verified_at IS NOT NULL
    ORDER BY CASE WHEN t.priority_type = 'urgent' THEN 0 ELSE 1 END, t.created_at ASC
    LIMIT 1
  `).get(counterId);

  if (!nextToken) {
    return res.json({
      empty: true,
      counterId,
      message: 'No waiting citizens in queue with verified physical arrival.',
    });
  }

  const nowIso = new Date().toISOString();

  db.transaction(() => {
    db.prepare(`
      UPDATE tokens SET
        queue_status = 'serving',
        called_at = ?,
        stage2_verified_at = ?,
        stage2_officer_id = ?
      WHERE id = ?
    `).run(nowIso, nowIso, req.user.id, nextToken.id);

    db.prepare(`
      UPDATE counters SET current_token = ?, status = 'Serving', officer_id = ? WHERE id = ?
    `).run(nextToken.token_number, req.user.id, counterId);
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'QUEUE_CALL_NEXT',
    resourceType: 'counter',
    resourceId: String(counterId),
    details: `Called Token ${nextToken.token_number} (${nextToken.citizen_name}) to Counter ${counterId}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({
    success: true,
    counterId,
    token: nextToken,
    currentToken: nextToken.token_number,
  });
});

// POST /api/queue/complete — Officer finishes serving current citizen
router.post('/complete', requireRole('officer', 'admin'), (req, res) => {
  const { tokenNumber, counterId = 3 } = req.body || {};
  if (!tokenNumber) return res.status(400).json({ error: 'tokenNumber is required' });

  const db = getDb();
  const token = db.prepare('SELECT * FROM tokens WHERE token_number = ?').get(tokenNumber.toUpperCase());
  if (!token) return res.status(404).json({ error: 'Token not found' });

  const nowIso = new Date().toISOString();

  db.transaction(() => {
    db.prepare(`
      UPDATE tokens SET
        queue_status = 'completed',
        completed_at = ?
      WHERE id = ?
    `).run(nowIso, token.id);

    db.prepare(`
      UPDATE counters SET status = 'Available' WHERE id = ?
    `).run(counterId);

    // Update application to completed
    db.prepare(`
      UPDATE applications SET status = 'completed', updated_at = datetime('now') WHERE token_id = ?
    `).run(token.id);

    db.prepare(`
      INSERT INTO application_history (application_id, actor_id, actor_role, from_status, to_status, reason)
      SELECT id, ?, 'officer', 'under_verification', 'completed', 'Counter service concluded and certificate authorized'
      FROM applications WHERE token_id = ?
    `).run(req.user.id, token.id);
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'QUEUE_SERVICE_COMPLETED',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Completed counter service for Token ${token.token_number}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Token ${token.token_number} marked completed` });
});

// POST /api/queue/mark-absent — Mark absent if citizen did not appear after grace period
router.post('/mark-absent', requireRole('officer', 'admin'), (req, res) => {
  const { tokenNumber, reason = 'Citizen did not report when called within grace period' } = req.body || {};
  if (!tokenNumber) return res.status(400).json({ error: 'tokenNumber is required' });

  const db = getDb();
  const token = db.prepare('SELECT * FROM tokens WHERE token_number = ?').get(tokenNumber.toUpperCase());
  if (!token) return res.status(404).json({ error: 'Token not found' });

  db.transaction(() => {
    db.prepare(`UPDATE tokens SET queue_status = 'absent' WHERE id = ?`).run(token.id);

    db.prepare(`
      INSERT INTO notifications (id, user_id, message, time, read, type)
      VALUES (?, ?, ?, ?, 0, 'warning')
    `).run(
      `NOTIF-${Math.random().toString(36).slice(2, 10)}`,
      token.citizen_id,
      `Token ${token.token_number} was called at Counter ${token.counter_id} but was marked absent. Please visit the helpdesk for arrival recovery.`,
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    );
  });

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'QUEUE_MARK_ABSENT',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Marked absent. Reason: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Token ${token.token_number} marked as absent` });
});

// POST /api/queue/restore-absent — Restore absent citizen back to queue with mandatory reason
router.post('/restore-absent', requireRole('officer', 'admin'), (req, res) => {
  const { tokenNumber, reason } = req.body || {};
  if (!tokenNumber || !reason) {
    return res.status(400).json({ error: 'tokenNumber and mandatory justification reason are required' });
  }

  const db = getDb();
  const token = db.prepare('SELECT * FROM tokens WHERE token_number = ?').get(tokenNumber.toUpperCase());
  if (!token) return res.status(404).json({ error: 'Token not found' });

  db.prepare(`
    UPDATE tokens SET queue_status = 'waiting', stage1_verified_at = datetime('now') WHERE id = ?
  `).run(token.id);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: 'officer',
    action: 'QUEUE_RESTORE_ABSENT',
    resourceType: 'token',
    resourceId: token.token_number,
    details: `Restored absent citizen to queue. Mandatory reason: ${reason}`,
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Token ${token.token_number} restored to active queue` });
});

// POST /api/queue/recover-token — Regenerate cryptographic QR token for lost token
router.post('/recover-token', (req, res) => {
  const { tokenNumber } = req.body || {};
  if (!tokenNumber) return res.status(400).json({ error: 'tokenNumber is required' });

  const db = getDb();
  const token = db.prepare('SELECT * FROM tokens WHERE token_number = ?').get(tokenNumber.toUpperCase());
  if (!token) return res.status(404).json({ error: 'Token not found' });

  // Ownership verification
  if (req.user.role === 'citizen' && token.citizen_id !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized to regenerate another citizen\'s token' });
  }

  const newQr = generateQrPayload({
    tokenId: token.id,
    tokenNumber: token.token_number,
    officeId: token.office_id,
    serviceId: token.service_id,
    expiryMinutes: 720,
  });

  db.prepare(`
    UPDATE tokens SET qr_payload = ?, qr_signature = ? WHERE id = ?
  `).run(newQr.qrString, newQr.signature, token.id);

  logAuditEvent({
    actorId: req.user.id,
    actorRole: req.user.role,
    action: 'TOKEN_QR_REGENERATED',
    resourceType: 'token',
    resourceId: token.token_number,
    details: 'Cryptographic QR token regenerated and old signature invalidated',
    ipAddress: req.ip || '127.0.0.1',
    status: 'SUCCESS',
  });

  res.json({
    success: true,
    tokenNumber: token.token_number,
    qrPayload: newQr.qrString,
    expiresAt: newQr.expiresAt,
  });
});

export default router;